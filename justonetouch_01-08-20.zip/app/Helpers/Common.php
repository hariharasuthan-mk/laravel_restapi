<?php
namespace App\Helpers;

class Common{
    public static function generateRand()
    {
        $rndno=rand(1000, 9999);
        return $rndno;
    }

    public static function sendSMS($mobile_number, $mess)
    {
		// $auth_key = "2f76ac6bcd2fb6b78cc92bb87426b86b";
		$api_id = "NzkwNDkyMDU4NA";
        $sender_id = "ADAAPT";
        $port = "TA"; 
        $message =urlencode("$mess");	
        $post_data = array(
            'api_id' => $api_id,
            'mobiles' => $mobile_number,
            'message' => $message,
            'sender' => $sender_id,
            'port' => $port
        ); 
		//API URL
		
		 $url="https://app.smsbits.in/api/user?id=NzkwNDkyMDU4NA&senderid=$sender_id&to=$mobile_number&msg=$message&port=TA";   
		//echo $url;die;
		 //$url="http://app.smsbits.in/api/unisms?id=$api_id&senderid=$sender_id&to=$mobile_number&msg=$message&port=$port";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        $data = curl_exec($ch);
        curl_close($ch);
		return $data;
    }
    public static function newSMS($mobile_number, $mess)
    {
         $curl = curl_init();
    
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://obligr.io/api_v2/message/send",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "sender_id=AIADMK&message=$mess&mobile_no=$mobile_number",
              CURLOPT_HTTPHEADER => array(
                "authorization: Bearer pehbyNg-QOJeZTIN_nFPRTkjuqUsE8pFNj-GOWS5OelCaFglW-pz9eaJaqmDc2l1",
                "cache-control: no-cache",
                "content-type: application/x-www-form-urlencoded"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              //echo $response;die;
              return $response;
            }
    }
    public static function encodeData($string) {
		if (isset($string) || !empty($string)) {
			$string = trim($string);
            $string = base64_encode(@serialize($string)); 
            $base64clean = str_replace(array('=','+','/'),'',$string);  
			return $base64clean;
		}
    }
    public static function base64clean($base64string){
		$base64string = str_replace(array('=','+','/'),'',$base64string);
		return $base64string;
    } 
    public static function decodeData($string) {
		if (isset($string) || !empty($string)) {
            $string = trim($string);
			return @unserialize(base64_decode($string));
		}
	}
}

    
?>
