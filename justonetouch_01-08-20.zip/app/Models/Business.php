<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;
class Business extends Model
{
    public function getAll(){

        $result = DB::table('tbl_business')->get();
        return $result;

    }
	public function getAllParent(){

        $result = DB::table('tbl_business')->where('parent_id',0)->get();
        return $result;

    }
    public function getsubcatBusiness($id){

        $result = DB::table('tbl_business')->where('sub_category_id',$id)->get();
        //dd($result);
        return $result;

    }
    /*public function getsubcategoryBusiness($input){

        $result = DB::table('tbl_business')
        ->select("*",DB::raw("6371 * acos(cos(radians(" . $input['lat'] . ")) 
        * cos(radians(lattutude)) 
        * cos(radians(longitude) - radians(" . $input['lng'] . ")) 
        + sin(radians(" .$input['lat']. ")) 
        * sin(radians(lattutude))) AS distance"))
        ->take($input['limit'])
        ->skip($input['offset'])
        ->where('sub_category_id',$input['subcategory_id'])->get();
        return $result;

    }*/
    
    public function getsubcategoryBusiness($input){

        $result = DB::table('tbl_business')
        ->take($input['limit'])
        ->skip($input['offset'])
        ->where('sub_category_id',$input['subcategory_id'])->get();
        //dd($result);
        return $result;

    }
    public function saveBusiness($input){
        $var  = Carbon::now('Asia/Kolkata');
        if($input['id']){
            
            $input['updated_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_business')->where('id',$input['id'])->update($input);
            return $input['id'];
        }
        else{
         
            $input['created_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_business')->insertGetId($input);
            return $result;
        }

    }
    public function getBusiness($id){
        $result=DB::table('tbl_business')->where('id',$id)->first();
        return $result;
    }
    public function getBusinessnew($input){
        $result=DB::table('tbl_business')
        ->where('id',$input['business_id'])->get();
        return $result;
    }
    public function getworkingDay($id){
        $result=DB::table('tbl_workingday')->where('business_id',$id)->get();
        return $result;
    }
    public function getgallery($id){
        $result=DB::table('tbl_gallery')->where('business_id',$id)->get();
        return $result;
    }
    public function deleteBusiness($id){
        $result=DB::table('tbl_business')->where('id',$id)->delete();
        return $result;
    }
}
