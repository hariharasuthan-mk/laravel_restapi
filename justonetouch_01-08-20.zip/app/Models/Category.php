<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;
class Category extends Model
{
    public function getAll(){

        $result = DB::table('tbl_category')->get();
        return $result;

    }
	public function getAllParent(){

        $result = DB::table('tbl_category')->where('parent_id',0)->orderBy('category_name', 'asc')->get();
        return $result;

    }
    public function getAllCategory($input){

        $result = DB::table('tbl_category')
        ->take($input['limit'])
        ->skip($input['offset'])
        ->where('parent_id',0)->get();
        return $result;

    }
    public function getAllsubcat($id){

        $result = DB::table('tbl_category')->where('parent_id',$id)->get();
        return $result;
    }
    public function getAllsubcategory($input){

        $result = DB::table('tbl_category')
        ->take($input['limit'])
        ->skip($input['offset'])
        ->where('parent_id',$input['category_id'])->get();
        return $result;

    }
    public function saveCategory($input){
        $var  = Carbon::now('Asia/Kolkata');
        if($input['id']){
            $input['updated_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_category')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_category')->insertGetId($input);
            return $result;
        }

    }
    public function getCategory($id){
        $result=DB::table('tbl_category')->where('id',$id)->first();
        return $result;
    }
    public function deleteCategory($id){
        $result=DB::table('tbl_category')->where('id',$id)->delete();
        return $result;
    }
}
