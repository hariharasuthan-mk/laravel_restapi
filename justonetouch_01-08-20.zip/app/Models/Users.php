<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use App\Helpers;
use Carbon\Carbon;

class Users extends Model
{
    public function saveUser($input){
        $var  = Carbon::now('Asia/Kolkata');
        if($input['id']){
            $input['modified_by']=1;
            $input['updated_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_user')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_by']=1;
            $input['created_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_user')->insertGetId($input);
            return $result;
        }

    }
    public function getUserByMobile($mobileno){
        $result=DB::table('tbl_user')->where('mobile_no',$mobileno)->first();
        return $result;
    }
    public function getUserById($userId){
        $result=DB::table('tbl_user')->where('id',$userId)->first();
        return $result;
    }

    public function checkToken($token)
    {
        if ($token) {
            
            try {

                $decrypttoken = Helpers\Common::decodeData($token);
                //echo "<pre>";print_r($decrypttoken);die;

                $getdata = explode('token', $decrypttoken);
                ///echo "<pre>";print_r($getdata);die;
              
                //echo "<pre>";print_r($gettoken);die;
                if(!empty($getdata['0'])) {
                    $id = $getdata['0'];
                    $mobileno = $getdata['1'];
                    $uuid = $getdata['2'];
                    //echo "<pre>";print_r($token);die;
                    $gettoken = DB::table('tbl_user')->where('id', $id)->first();
                    if ($gettoken->is_active == 0) {
                        $msg = array(
                            $this->status = '0',
                            $this->message = 'You are blocked by admin.For further details please contact admin.'
                        );
                        return $msg;
                    }
                    if ($gettoken->id == $id) {

                        return $getdata;
                    } else {
                        $msg = array($this->status = '0',
                            $this->message = 'Your session has expired. Please login model1');
                        return $msg;
                    }
                } else {
                    $msg = array($this->status = '0',
                        $this->message = 'Your session has expired. Please login model2');
                    return $msg;
                }

            } catch (DecryptException $e) {
                //
                $msg = array($this->status = '0',
                    $this->message = 'Your token is not valid');
                return $msg;

            }
        }

    }
}
