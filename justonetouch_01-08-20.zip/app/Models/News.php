<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;

class News extends Model
{
    public function getAll(){

        $result = DB::table('tbl_news')->orderBy('created_on', 'DESC')->orderBy('updated_on','DESC')->get();
        return $result;

    }
    public function saveNews($input){
        if($input['id']){
            $input['updated_on'] = Carbon::now()->toDateTimeString();
            $result=DB::table('tbl_news')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_on'] = Carbon::now()->toDateTimeString();
            $input['updated_on'] = Carbon::now()->toDateTimeString();
            $result=DB::table('tbl_news')->insertGetId($input);
            return $result;
        }

    }
    public function getNews($id){
        $result=DB::table('tbl_news')->where('id',$id)->first();
        return $result;
    }
    public function deleteNews($id){
        $result=DB::table('tbl_news')->where('id',$id)->delete();
        return $result;
    }
}
