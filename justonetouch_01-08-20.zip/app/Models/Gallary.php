<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;
class Gallary extends Model
{
    public function getAll(){

        $result = DB::table('tbl_gallery')->get();
        return $result;

    }
    public function getAllsubcat($id){

        $result = DB::table('tbl_gallery')->where('id',$id)->get();
        return $result;

    }
    public function saveGallary($input){
        $var  = Carbon::now('Asia/Kolkata');
        if($input['id']){
            $input['updated_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_gallery')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_gallery')->insertGetId($input);
            return $result;
        }

    }
    public function getBusiness($id){
        $result=DB::table('tbl_gallery')->where('id',$id)->first();
        return $result;
    }
    public function deleteBusiness($id){
        $result=DB::table('tbl_gallery')->where('id',$id)->delete();
        return $result;
    }
}
