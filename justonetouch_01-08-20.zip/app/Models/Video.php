<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;
class Video extends Model
{
    public function getAllVideo(){
        $result=DB::table('tbl_video')->get();
        return $result;
    }
    public function saveVideo($input){
        if($input['id']){
            $input['modified_date'] = Carbon::now()->toDateTimeString();
            $result=DB::table('tbl_video')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_date'] = Carbon::now()->toDateTimeString();
            $result=DB::table('tbl_video')->insertGetId($input);
            return $result;
        }

    }
    public function getVideo($id){
        $result=DB::table('tbl_video')->where('id',$id)->first();
        return $result;
    }
    public function deleteVideo($id){
        $result=DB::table('tbl_video')->where('id',$id)->delete();
        return $result;
    }
}
