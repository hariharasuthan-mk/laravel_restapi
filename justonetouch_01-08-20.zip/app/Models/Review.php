<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use DB;
class Review extends Model
{
    public function getAll(){

        $result = DB::table('tbl_reviews')->get();
        return $result;

    }
	public function getAllParent(){

        $result = DB::table('tbl_reviews')->get();
        return $result;

    }
    public function saveReview($input){
        $var  = Carbon::now('Asia/Kolkata');
        if($input['id']){
            $input['updated_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_reviews')->where('id',$input['id'])->update($input);
            return $result;
        }
        else{
            $input['created_at'] = $var->toDateTimeString();
            $result=DB::table('tbl_reviews')->insertGetId($input);
            return $result;
        }

    }
    public function getReview($id){
        $result=DB::table('tbl_reviews')->where('id',$id)->get();
        return $result;
    }
    public function deleteReview($id){
        $result=DB::table('tbl_reviews')->where('id',$id)->delete();
        return $result;
    }
}
