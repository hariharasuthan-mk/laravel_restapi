<?php

namespace App\Models;

use Illuminate\Database\QueryException as QueryException;
use App\Http\Controllers\Image;
use Carbon\Carbon;
use DB;
use Illuminate\Database\Eloquent\Model;

class ImageResizer {

    public $imagesize;
    public $imageName;
    public $imageType;
    public $path;

    public function imageUpload($image, $subpath, $image_name) {
//        print_r($image);print_r($subpath);print_r($image_name);

        $pathToFile = $image;

        $offset = strpos($pathToFile, ',');
        $tmp = base64_decode(substr($pathToFile, $offset));
//        check base64 or not
        $x = preg_match('/^[a-zA-Z0-9\/\r\n+]*={0,2}$/', $image);

        if ($x == 1) {
            $imagedetails = "Please provide image in base64_encode format";
            return $imagedetails;
        } else {
            try {
//                print_r($image);die;
                $imagesize = getimagesize($image);
//print_r($imagesize);die;
                $imgtype = explode('/', $imagesize['mime']);

                $img_type = $imgtype[1];
                if ($img_type == 'jpeg') {
                    $img_type = 'jpeg';
                    $this->imageType = $img_type;
                }
                if ($image_name) {

                    $imageName = $image_name;
                    $this->imageName = $imageName;
                } else {
                    mt_srand();
                    $filename = md5(uniqid(mt_rand()));
                    $imageName = $filename . '.' . $img_type;

                    $this->imageName = $imageName;
                }
                if ($subpath) {
                    $path = public_path() . "/" . $subpath . "/" . $imageName;
                    $this->path = $path;
                } else {
                    $path = public_path() . "/temp_path/" . $imageName;
                    $this->path = $path;
                }
                file_put_contents($path, $tmp);
                return;
            } catch (QueryException $e) {
                return false;
            }
        }
    }
}

?>