<?php

namespace App\Http\Controllers\web\businessadmin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

class DashboardController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    
    public function index(Request $request){

        $title = "Signup";
        $loginId = sentinel::getUser()->id;
        $businesscnt=DB::table('tbl_business')->where('user_id',$loginId)->count();
        $reviewscnt=DB::table('tbl_reviews')->where('user_id',$loginId)->count();
        $businessRs=DB::table('tbl_business')->where('user_id',$loginId)->get();
        //dd($businessRs);
        $reviewtemp=array();
        foreach($businessRs as $newkey=>$newval)
        {
            $reviewtemp[$newkey]=$newval;
            $businessid=$newval->id;
            $reviewtemp[$newkey]=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name',
            'tbl_business.business_title')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            ->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$businessid)->get();
        }
        
        $finalreview = collect($reviewtemp)->filter()->flatten()->all();
        $reviewscnt=count($finalreview);
        
        return view('frontend.businessadmin.pages.dashboard')->with('reviewscnt',$reviewscnt)->with('businesscnt',$businesscnt)->with('title', $title);
    }
    
	
}
