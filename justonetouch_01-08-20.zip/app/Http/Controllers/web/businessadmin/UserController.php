<?php

namespace App\Http\Controllers\web\businessadmin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Helpers\Common;
use Carbon\Carbon;
use App\Models\ImageResizer;

class UserController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->image = new ImageResizer();
    }
    public function index(Request $request){

        $title = "Signup";
        return view('frontend.businessadmin.pages.userbusinesslist')->with('title', $title);
    }
    public function profileview(Request $request){

        $title = "Profile View";
        $loginId = sentinel::getUser()->id;
        $profileRs=DB::table('tbl_user')->where('id',$loginId)->get();
        $temp=array();
            foreach($profileRs as $key=>$val)
            {
                $temp[$key]=$val;
                $pid=$val->id;
                $temp[$key]->id=Common::encodeData($pid);
            }
        	//dd($temp);
        	
        return view('frontend.businessadmin.pages.profileview')->with('profileList',$temp)->with('title', $title);
    }
    public function profileedit(Request $request,$id){

        $title = "Profile Edit";
        //dd($id);
        $pid=Common::decodeData($id);
        //dd($pid);
        $profileRs=DB::table('tbl_user')->where('id',$pid)->first();
        
        return view('frontend.businessadmin.pages.profileedit')->with('profileRs',$profileRs)->with('title', $title);
    }
    public function userprofileUpdate(Request $request)
    {
        $input =Input::all();
        $userId = sentinel::getUser()->id;
        //dd($input);
        $data = [
            'firstName' => isset($input['firstname']) ? $input['firstname'] : "",
            'password' => isset($input['password']) ? $input['password'] : "",
            'confirmpass' => isset($input['confirmpass']) ? $input['confirmpass'] : "",
            'email' => isset($input['email']) ? $input['email'] : "",
            'profile_image' => isset($input['profile_image']) ? $input['profile_image'] : "",
            'mobile' => isset($input['mobile']) ? $input['mobile'] : "",
            'address' => isset($input['address']) ? $input['address'] : "",
            'status' => isset($input['status']) ? $input['status'] : "",
        ];

//            echo "<pre>";print_r($data);die;
        $rules = [
            "firstName" => "required",
            "email" => "required|email",
            "mobile" => "required|digits:10"
        ];
        $error = array();
        $checkStatus = false;

        if ($request->isMethod('post')) {

            $checkValid = Validator::make($data, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
            if ($checkStatus) {
                return view('frontend.businessadmin.pages.profileedit')->with('input', $data)->with('errors', $error);
            }
        }

            $input =Input::all();

            if ($data['profile_image']) {

                 $truckpictures = $input['profile_image'];


                $imagesize = getimagesize($truckpictures);

                $width = $imagesize[0];
                $height = $imagesize[1];
                $image = $truckpictures->getClientOriginalExtension();

                $imageName = 'user' . '-' . uniqid() . '.' . $image;
                $image_name = $imageName;
                $imagePath = $truckpictures->move(base_path() . '/public/upload/user/original', $imageName);
                $img = Image::make($imagePath->getRealPath());

                $largeWidth = $width;
                $mediumWidth = $width;
                $smallWidth = $width;
                $extralargeWidth = $width;
                $iconWidth = $width;
                $thumbnailWidth = $width;

//thumbnail
                if ($width > 200) {
                    $thumbnailWidth = 200;
                }
                Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/thumbnail/' . $imageName);

                //small
                if ($width > 320) {
                    $smallWidth = 320;
                }
                Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/small/' . $imageName);

                //medium
                if ($width > 375) {
                    $mediumWidth = 375;
                }
                Image::make($imagePath)->resize($mediumWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/medium/' . $imageName);

                //extraLarge
                if ($width > 768) {
                    $extralargeWidth = 768;
                }
                Image::make($imagePath)->resize($extralargeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/extralarge/' . $imageName);

                //large
                if ($width > 425) {
                    $largeWidth = 425;
                }
                Image::make($imagePath)->resize($largeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/large/' . $imageName);

                //icon
                if ($width > 64) {
                    $iconWidth = 64;
                }
                Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/icon/' . $imageName);


            } else {

                $getUser = DB::table('tbl_user')->where('id',$userId)->first();
                //dd($getUser);
                if ($getUser) {
                    $imageName = $getUser->user_image;
                } else {
                    $imageName = '';
                }

            }
            $imagepath=url('/')."/public/upload/user/";
            $var  = Carbon::now('Asia/Kolkata');
            $userInput = [
                'id' => $userId,
                'first_name' => $data['firstName'],
                'password' => $data['password'],
                'password_str' => $data['confirmpass'],
                'email' => $data['email'],
                'user_image' => $imageName,
                'user_image_path' => $imagepath,
                'mobile' => $data['mobile'],
                'address' => $data['address'],
                'modified_by' => $userId,
                'profile_status'=>1,
                'updated_at' => $var->toDateTimeString(),
            ];
           // dd($userInput);
            $update = Sentinel::update($userId, $userInput);
            //dd($update);

            if ($update) {
                 return redirect('profileview')->with('message', 'User Updated successfully');
            }

    }
	
}
