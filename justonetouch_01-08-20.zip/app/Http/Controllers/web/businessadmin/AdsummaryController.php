<?php

namespace App\Http\Controllers\web\businessadmin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

class AdsummaryController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    public function adsummary(Request $request){

        $title = "Adsummary";
        return view('frontend.businessadmin.pages.adsummary')->with('title', $title);
    }
	
}
