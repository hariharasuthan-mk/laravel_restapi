<?php

namespace App\Http\Controllers\web\businessadmin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

class PaymentController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    public function checkout(Request $request){

        $title = "Payment";
        return view('frontend.businessadmin.pages.checkout')->with('title', $title);
    }
    public function invoiceall(Request $request){

        $title = "Payment";
        return view('frontend.businessadmin.pages.invoiceall')->with('title', $title);
    }
    public function invoiceview(Request $request){

        $title = "Payment";
        return view('frontend.businessadmin.pages.invoiceview')->with('title', $title);
    }
    public function invoiceprint(Request $request){

        $title = "Payment";
        return view('frontend.businessadmin.pages.invoiceprint')->with('title', $title);
    }
	
}
