<?php

namespace App\Http\Controllers\web\businessadmin;

use App\Models\Category;
use App\Models\Business;
use App\Models\Gallary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Helpers\Common;
use Illuminate\Pagination\LengthAwarePaginator;

class BusinessController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->business = new Business();
        $this->gallary = new Gallary();
    }
    public function index(Request $request){

        $title = "Business List";
        $loginId = sentinel::getUser()->id;
        $businessRs=DB::table('tbl_business')->where('user_id',$loginId)->get();
        $temp=array();
            foreach($businessRs as $key=>$val)
            {
                $temp[$key]=$val;
                $catid=$val->id;
                $getReview = DB::table('tbl_reviews')->where('business_id',$val->id)->avg('rating');    
               // $temp[$key]->view_count = DB::table('tbl_view_count')->where('business_id',$val->id)->sum('freqency');   
               $temp[$key]->view_count = 23;        
                $temp[$key]->id=Common::encodeData($catid);
               if($getReview) { 
                 $temp[$key]->review = round($getReview,1);
               }else {
                $temp[$key]->review = 0;
               }

                
            }
            
        	//dd($temp);
        	$currentPage = LengthAwarePaginator::resolveCurrentPage();
            $itemCollection = collect($temp);       
            $perPage = 10;      
            $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
            $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);
            $paginatedItems->setPath($request->url());
            
        return view('frontend.businessadmin.pages.userbusinesslist')->with('businessList',$paginatedItems)->with('title', $title);
    }
    public function businessadd(Request $request){

       
        $title = "Business Add";
        $loginId = sentinel::getUser()->mobile_no;
       
        $getall=$this->category->getAllParent();
        $getallcity=DB::table('cities')->where('state_id',21)->get();
        $working_days =[];
        $getGallaryimages = [];
        return view('frontend.businessadmin.pages.userbusinessadd')->with('getGallaryimages',$getGallaryimages)->with('working_days',$working_days)->with('getallcity',$getallcity)->with('getall',$getall)->with('title', $title);
    }

    public function editbusiness(Request $request, $id = false){

        $title = "Edit Bussiness";
        $id = Common::decodeData($id);
       
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->category->getAllParent();
            $getallcity=DB::table('cities')->where('state_id',21)->get();
            $data = DB::table('tbl_business')->where('id',$id)->first();
            if(!$data){
                return redirect('businesslist')->with('error','Data not found.');
            }
            $data = json_decode(json_encode($data),TRUE);
            if($data['lattutude']){
                $data['lattutude_lat'] = (float)$data['lattutude'];
            }else {
                $data['lattutude_lat'] =13.060422 ;
            }
            if($data['longitude']){
                $data['longitude_lng'] = (float)$data['longitude'];
            }else {
                $data['longitude_lng'] =80.249583;
            }
            $getSubAll = [];
            if($data['sub_category_id'] && $data['sub_category_id'] !=0) {
                $getSubAll = DB::table('tbl_category')->where('parent_id',$data['category_id'])->get(); 
            }

            $getWorkingDay = DB::table('tbl_workingday')->where('business_id',$id)->pluck('day','id')->toArray();
            $getGallaryimages = DB::table('tbl_gallery')->where('business_id',$id)->get();
            //dd($getGallaryimages);
           
           // dd($data);
          
            //'category_id' => $data['parent_id'],
            //'sub_category_id' => $data['subcat_id'],
           // dd($data['business_first_name']);
            return view('frontend.businessadmin.pages.userbusinessadd')->with('getGallaryimages',$getGallaryimages)->with('working_days',$getWorkingDay)->with('getallcity',$getallcity)->with('getall',$getall)->with('getSubAll',$getSubAll)->with('data',$data)->with('title', $title);
        //}
    }

    public function userpostbusiness(Request $request,$id = false)
    {
        $title = "Category";
        $loginUser=Sentinel::getUser();
        $input = Input::all();
      

        //echo "<pre>";print_r($input);die;
        
        $data = [
            'id' => isset($input['id']) ? $input['id'] : NULL,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'business_firstname' => isset($input['business_firstname']) ? $input['business_firstname'] : '',
            'business_lastname' => isset($input['business_lastname']) ? $input['business_lastname'] : '',
            'business_title' => isset($input['business_title']) ? $input['business_title'] : '',
            'business_email' => isset($input['business_email']) ? $input['business_email'] : '',
			'business_contactno' => isset($input['business_contactno']) ? $input['business_contactno'] : '',
            'business_website' => isset($input['business_website']) ? $input['business_website'] : '',
            'business_address' => isset($input['business_address']) ? $input['business_address'] : '',
            'business_street' => isset($input['business_street']) ? $input['business_street'] : '',
            'business_tags' => isset($input['business_tags']) ? $input['business_tags'] : '',
			'business_status' => isset($input['business_status']) ? $input['business_status'] : '',
            'business_desc' => isset($input['business_desc']) ? $input['business_desc'] : '',
            'business_image' => isset($input['business_image']) ? $input['business_image'] : '',
            'business_banner' => isset($input['business_banner']) ? $input['business_banner'] : '',
            'city_name' => isset($input['city_name']) ? $input['city_name'] : '',
            'filename' => isset($input['filename']) ? $input['filename'] : '',
            'pincode' => isset($input['pincode']) ? $input['pincode'] : '0',
            
            'cityLat' => isset($input['cityLat']) ? $input['cityLat'] : '',
            'cityLng' => isset($input['cityLng']) ? $input['cityLng'] : '',
            'category_type' => isset($input['category_type']) ? $input['category_type'] : '',
            'locationAddress' => isset($input['locationAddress']) ? $input['locationAddress'] : '',
            'about_business_img' => isset($input['about_business_img']) ? $input['about_business_img'] : '',
            
        ];
       

       
        $id = $data['id'];
		
		if ($data['business_image']) 
		{
            $truckpictures = $input['business_image'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $thumb_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/thumbnail/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/thumbnail/icon/' . $imageName);
        } 
        else 
        {
            if ($data['id']) {
                
                $getbusiness = $this->business->getBusiness($data['id']);
              
                if ($getbusiness) {
                    $thumb_image_name = $getbusiness->thumbnail_img;
                } else {
                    $thumb_image_name= '';
                }

            } else {
                $thumb_image_name = '';
            }

        }
        
        if ($data['business_banner']) 
		{
            $truckpictures = $input['business_banner'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $banner_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/banner/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
        } 
        else 
        {
            if ($data['id']) {
                
                $getbusiness = $this->business->getBusiness($data['id']);
                if ($getbusiness) {
                    $banner_image_name = $getbusiness->banner_img;
                } else {
                    $banner_image_name= '';
                }

            } else {
                $banner_image_name = '';
            }

        }

        /****** ABOUT BUSINESS IMAGE UPLOAD START ******/

        if ($data['about_business_img']) 
		{
            $truckpictures = $input['about_business_img'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $about_business_img	 = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/aboutbusiness/', $imageName);
            $img = Image::make($imagePath->getRealPath());

        } 
        else 
        {
            if ($data['id']) {
                
                $getbusiness = $this->business->getBusiness($data['id']);
                if ($getbusiness) {
                    $about_business_img	 = $getbusiness->about_business_img	;
                } else {
                    $about_business_img	= '';
                }

            } else {
                $about_business_img	 = '';
            }

        }

        /****** ABOUT BUSINESS IMAGE UPLOAD END ******/




        //$getallcity=DB::table('cities')->where('id',$data['city_id'])->first();
        //dd($getallcity);
        //$city_name=$getallcity->city;
        DB::beginTransaction();
       try {
        $userInput = array(
            'id' => $data['id'],
            'user_id' =>$loginUser->id,
			'business_first_name' => $data['business_firstname'],
            'business_last_name' => $data['business_lastname'],
            'business_title' => $data['business_title'],
            'business_desc' => $data['business_desc'],
            'business_email' => $data['business_email'],
            'business_website' => $data['business_website'],
            'business_address' => $data['business_address'],
            'business_street' => $data['business_street'],
            'address_route' => $data['locationAddress'],
            'business_contactno' => $data['business_contactno'],
            //'city_id' => $data['city_id'],
            'city_name' => $data['city_name'],
            'pincode' => $data['pincode'],
            'lattutude' => $data['cityLat'],
            'longitude' => $data['cityLng'],
            'category_id' => $data['parent_id'],
            'sub_category_id' => $data['subcat_id'],
            'business_tag' => $data['business_tags'],
            'thumbnail_img' => $thumb_image_name,
            'banner_img' => $banner_image_name,
            'modeofpay' => $data['category_type'],
            'status'=>$data['business_status'],
            'about_business_img' => $about_business_img,
            
            //'year_of_estd' => $data['year_of_estd'],
        );

       // dd($userInput);

        if(!$data['id']) {
          $userInput['status']=0;
        }

        
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
           // echo "<pre>";print_r($userInput);die;
            $business_id = $this->business->saveBusiness($userInput);
          


           
        
        if($request->hasfile('filename'))
            {
               // DB::table('tbl_gallery')->where('business_id',$id)->delete();
                foreach($data['filename'] as $images)
                {
                
                    if ($images) {

                        $truckpictures = $images;        
                        $imagesize = getimagesize($truckpictures);
        
                        $width = $imagesize[0];
                        $height = $imagesize[1];
                        $image = $truckpictures->getClientOriginalExtension();
        
                        $imageName = 'image' . '-' . uniqid() . '.' . $image;
                        $gimage_name = $imageName;
                        $imagePath = $truckpictures->move(base_path() . '/public/upload/business/gallary/original', $imageName);
                        $img = Image::make($imagePath->getRealPath());
        
                        $largeWidth = $width;
                        $mediumWidth = $width;
                        $smallWidth = $width;
                        $extralargeWidth = $width;
                        $iconWidth = $width;
                        $thumbnailWidth = $width;
                        //thumbnail
                        if ($width > 200) {
                            $thumbnailWidth = 200;
                        }
                        Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/thumbnail/' . $imageName);
        
                        //small
                        if ($width > 320) {
                            $smallWidth = 320;
                        }
                        Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/small/' . $imageName);
        
                        //medium
                        if ($width > 375) {
                            $mediumWidth = 375;
                        }
        
                        //icon
                        if ($width > 64) {
                            $iconWidth = 64;
                        }
                        Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/icon/' . $imageName);


            } else {

                if ($id) {

                    $getbusiness = $this->gallary->getGallary($id);
                    if ($getbusiness) {
                        $gimage_name = $getbusiness->image;
                    } else {
                        $gimage_name= '';
                    }


                } else {
                    $gimage_name = '';
                }

            }
                $userInput = array(                   
                    'business_id' => $business_id,
                    'image_name' => $gimage_name
    
                );
                if(!$data['id']){                    
                    $userInput['created_by']=Sentinel::getUser()->id;
                    $userInput['created_at']=date('Y-m-d h:i:s');                   
                }
                else{
                    $userInput['created_by']=Sentinel::getUser()->id;
                    $userInput['created_at']=date('Y-m-d h:i:s');
                    $userInput['updated_by']=Sentinel::getUser()->id;
                    $userInput['updated_at']=date('Y-m-d h:i:s');
                }

                //dd($userInput);
               
                $table = DB::table('tbl_gallery')->insert($userInput);
            
                }
            }

            if($data['id']) {
                DB::table('tbl_workingday')->where('business_id',$data['id'])->delete();
            }
            
        $working_day= [
            'id' => $id,
            'week_days' => isset($input['week_days']) ? $input['week_days'] : '',
            'starttime' => isset($input['starttime']) ? $input['starttime'] : '',
            'endtime' => isset($input['endtime']) ? $input['endtime'] : '',
            'open_close' => isset($input['open_close']) ? $input['open_close'] : '',
        ];
       
        
        $inputs =[];
        for ($i=0; $i <count($working_day['week_days']) ; $i++) {
            if($working_day['week_days'][$i] && $working_day['starttime'][$i] && $working_day['starttime'][$i]) {
                $inputs[$i]['day'] = $i;
                $inputs[$i]['week_days'] =$working_day['week_days'][$i];
                $inputs[$i]['starttime'] =$working_day['starttime'][$i];
                $inputs[$i]['endtime'] =$working_day['endtime'][$i]; 
                $inputs[$i]['open_close'] =$working_day['open_close'][$i]; 
                $inputs[$i]['business_id'] =$business_id;  
           }
    }
    
   if(!empty($inputs)){
        foreach($inputs as $key=>$value) {
            
            $draw[] = [
                'day' => $value['day'],
                'week_day' => $value['week_days'],
                'week_start_time' => $value['open_close'] == 'open' ? $value['starttime'] :"Close",
                'week_end_time' => $value['open_close'] == 'open' ? $value['endtime']:"Close",
                'open_close' => $value['open_close'],
                'business_id' => $value['business_id'],
            ];
        }
    }
    
  
   /*  dd($draw);
   

       
        
        $insert = [];
        for ($i=0; $i <count($working_day['week_days']) ; $i++)
        {
            $draw = [
                'week_day' => $working_day['week_days'][$i],
                'week_start_time' => $working_day['starttime'][$i],
                'week_end_time' => $working_day['endtime'][$i],
                'business_id' => $business_id,
            ];
            if(!empty($draw['week_day']))
            {
            $insert[] = $draw;
            }
        }
        dd($insert);*/
        
        $saveworking = DB::table('tbl_workingday')->insert($draw);
        DB::commit();
        } catch (\Exception $e){ 
            DB::rollback();

        }
        
        
            if ($data['id']) {
                return redirect('businesslist')->with('success', 'Business updated Successfully.');
            } else {
                return redirect('businesslist')->with('success', 'Business created Successfully.');
            }
    }
    
  /*  public function userpostbusiness(Request $request,$id = false)
    {
        $title = "Category";
        //$loginUser=Sentinel::getUser();
        $loginId = sentinel::getUser()->id;
        $input = Input::all();
       // dd($input);

        //echo "<pre>";print_r($input);die;
        
        $data = [
            'id' => $id,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'business_firstname' => isset($input['business_firstname']) ? $input['business_firstname'] : '',
            'business_lastname' => isset($input['business_lastname']) ? $input['business_lastname'] : '',
            'business_title' => isset($input['business_title']) ? $input['business_title'] : '',
            'business_email' => isset($input['business_email']) ? $input['business_email'] : '',
			'business_contactno' => isset($input['business_contactno']) ? $input['business_contactno'] : '',
            'business_website' => isset($input['business_website']) ? $input['business_website'] : '',
            'business_address' => isset($input['business_address']) ? $input['business_address'] : '',
            'business_tags' => isset($input['business_tags']) ? $input['business_tags'] : '',
			'business_status' => isset($input['business_status']) ? $input['business_status'] : '',
            'business_desc' => isset($input['business_desc']) ? $input['business_desc'] : '',
            'business_image' => isset($input['business_image']) ? $input['business_image'] : '',
            'business_banner' => isset($input['business_banner']) ? $input['business_banner'] : '',
            'city_id' => isset($input['city_id']) ? $input['city_id'] : '',
            'filename' => isset($input['filename']) ? $input['filename'] : '',
            'pincode' => isset($input['pincode']) ? $input['pincode'] : '0',
        ];
        
		
		if ($data['business_image']) 
		{
            $truckpictures = $input['business_image'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $thumb_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/thumbnail/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/thumbnail/icon/' . $imageName);
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $thumb_image_name = $getbusiness->thumbnail_img;
                } else {
                    $thumb_image_name= '';
                }

            } else {
                $thumb_image_name = '';
            }

        }
        
        if ($data['business_banner']) 
		{
            $truckpictures = $input['business_banner'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $banner_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/banner/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $banner_image_name = $getbusiness->banner_img;
                } else {
                    $banner_image_name= '';
                }

            } else {
                $banner_image_name = '';
            }

        }
        $getallcity=DB::table('cities')->where('id',$data['city_id'])->first();
        //dd($getallcity);
        if($getallcity)
        {
        $city_name=$getallcity->city;
        }
        else
        {
            $city_name="";
        }
        
        $userInput = array(
            'id' => $id,
            'user_id' =>$loginId,
			'business_first_name' => $data['business_firstname'],
            'business_last_name' => $data['business_lastname'],
            'business_title' => $data['business_title'],
            'business_desc' => $data['business_desc'],
            'business_email' => $data['business_email'],
            'business_website' => $data['business_website'],
            'business_address' => $data['business_address'],
            'business_contactno' => $data['business_contactno'],
            'city_id' => $data['city_id'],
            'city_name' => $city_name,
            'pincode' => $data['pincode'],
            'lattutude' => "65",
            'longitude' => "65",
            'category_id' => $data['parent_id'],
            'sub_category_id' => $data['subcat_id'],
            'business_tag' => $data['business_tags'],
            'thumbnail_img' => $thumb_image_name,
            'banner_img' => $banner_image_name,
            //'year_of_estd' => $data['year_of_estd'],
        );
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $business_id = $this->business->saveBusiness($userInput);
            
        
        if($request->hasfile('filename'))
            {
    
                foreach($request->file('filename') as $images)
                {
                
                    if ($images) {

                        $truckpictures = $images;
        
                        $imagesize = getimagesize($truckpictures);
        
                        $width = $imagesize[0];
                        $height = $imagesize[1];
                        $image = $truckpictures->getClientOriginalExtension();
        
                        $imageName = 'image' . '-' . uniqid() . '.' . $image;
                        $gimage_name = $imageName;
                        $imagePath = $truckpictures->move(base_path() . '/public/upload/business/gallary/original', $imageName);
                        $img = Image::make($imagePath->getRealPath());
        
                        $largeWidth = $width;
                        $mediumWidth = $width;
                        $smallWidth = $width;
                        $extralargeWidth = $width;
                        $iconWidth = $width;
                        $thumbnailWidth = $width;
                        //thumbnail
                        if ($width > 200) {
                            $thumbnailWidth = 200;
                        }
                        Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/thumbnail/' . $imageName);
        
                        //small
                        if ($width > 320) {
                            $smallWidth = 320;
                        }
                        Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/small/' . $imageName);
        
                        //medium
                        if ($width > 375) {
                            $mediumWidth = 375;
                        }
        
                        //icon
                        if ($width > 64) {
                            $iconWidth = 64;
                        }
                        Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/icon/' . $imageName);


            } else {

                if ($id) {

                    $getbusiness = $this->gallary->getGallary($id);
                    if ($getbusiness) {
                        $gimage_name = $getbusiness->image;
                    } else {
                        $gimage_name= '';
                    }


                } else {
                    $gimage_name = '';
                }

            }
                $userInput = array(
                    'id' => $id,
                    'business_id' => $business_id,
                    'image_name' => $gimage_name,
    
                );
                if($userInput['id']){
                    $userInput['created_by']=$loginId;
                }
                else{
                    $userInput['updated_by']=$loginId;
                }
                $table = $this->gallary->saveGallary($userInput);
            
                }
            }
            
        $working_day= [
            'id' => $id,
            'week_days' => isset($input['week_days']) ? $input['week_days'] : '',
            'starttime' => isset($input['starttime']) ? $input['starttime'] : '',
            'endtime' => isset($input['endtime']) ? $input['endtime'] : '',
        ];
        
        $insert = [];
        for ($i=0; $i <count($working_day['week_days']) ; $i++)
        {
            $draw = [
                'week_day' => $working_day['week_days'][$i],
                'week_start_time' => $working_day['starttime'][$i],
                'week_end_time' => $working_day['endtime'][$i],
                'business_id' => $business_id,
            ];
            if(!empty($draw['week_day']))
            {
            $insert[] = $draw;
            }
        }
        $saveworking = DB::table('tbl_workingday')->insert($insert);
        
        
            if ($saveworking) {
                return redirect('businesslist')->with('success', 'Business updated Successfully.');
            } else {
                return redirect('businesslist')->with('success', 'Business created Successfully.');
            }
    }*/

    function delete($id = false) {
        
        $id = Common::decodeData($id);
         $row = DB::table('tbl_business')->where('id',$id)->first();
         if($row) {
             DB::table('tbl_business')->where('id',$id)->delete();
            return redirect('businesslist')->with('success',"Business deleted successfully.");
         }else {
            return redirect('businesslist')->with('error',"User not found");
         }
    }
	
	public function reviewlist(Request $request){

        $title = "Business Review List";
        $businessList = DB::table('tbl_business')->where('user_id',Sentinel::getUser()->id)->get();

        $temp = [];
        foreach($businessList as $key=>$value){
            $temp[$key] = $value;
            
            $temp[$key]->total_review = DB::table('tbl_reviews')->where('business_id',$value->id)->count();
            $rating = DB::table('tbl_reviews')->where('business_id',$value->id)->avg('rating');
            if($rating){
            $temp[$key]->review = round($rating,1); 
            } else {
                $temp[$key]->review = 0;
            }
            $temp[$key]->id =Common::encodeData($value->id); 
        }
       

        $currentPage = LengthAwarePaginator::resolveCurrentPage();       
        $itmeCollection = collect($temp);      
        $perPage = 10;
        $currentPageItems = $itmeCollection->slice(($currentPage*$perPage) - $perPage, $perPage)->all(); 
        $paginatedItems = new LengthAwarePaginator($currentPageItems , count($itmeCollection), $perPage);
        $paginatedItems->setPath($request->url());
       
        
        return view('frontend.businessadmin.pages.business-review-list')->with('title',$title)->with('businessList',$paginatedItems);

    }
    
    public function businessReviewDetails(Request $request, $encodedId = false){
       
   
        $title = "Business Review Details";
        $loginId = sentinel::getUser()->id;
        $buss_id = common::decodeData($encodedId);

      /*  $businessRs=DB::table('tbl_business')->where('user_id',$loginId)->get();
        //dd($businessRs);
        $reviewtemp=array();
        foreach($businessRs as $newkey=>$newval)
        {
            $reviewtemp[$newkey]=$newval;
            $businessid=$newval->id;
            $reviewtemp[$newkey]=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name',
            'tbl_business.business_title')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            ->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$businessid)->get();
        }*/

        $businessDetails=DB::table('tbl_business')->where('id',$buss_id)->first();

        $reviewtemp = DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name',
            'tbl_business.business_title')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            ->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$buss_id)->get();
        
        $finalreview = collect($reviewtemp)->filter()->flatten()->all();
        //dd($finalreview);
        return view('frontend.businessadmin.pages.reviewlist',compact('businessDetails'))->with('reviewList',$finalreview)->with('title', $title);
    }

    public function previewBusiness(Request $request, $id = false){

        $title = "preview Bussiness";
        $id = Common::decodeData($id);
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=DB::table('tbl_category')->where('parent_id',0)->pluck('category_name','id');   
            
            
           
            $data = DB::table('tbl_business')->where('id',$id)->first(); 
         
            $userType = [                
                "1"=>"Free",
                "2"=>"Premium",
                "3"=>"Premium Plus",
                "4"=>"Ultra Premium Plus",
            ];
            if(!$data){
                return redirect('businesslist')->with('error','Data not found.');
            }else {
                
                $preview = [];
                $preview['category_name'] = $getall[$data->category_id];

                $getSubAll = DB::table('tbl_category')->where('parent_id',$data->category_id)->pluck('category_name','id'); 
              
                if($data->sub_category_id !="" || $data->sub_category_id ==0) {
                   $preview['sub_cat_name'] = $getSubAll[$data->sub_category_id];
                }else{
                    $preview['sub_cat_name'] = ""; 
                }

              //  $totalViewCount = DB::table('tbl_view_count')->where('business_id',$id)->sum('freqency');
              $totalViewCount = 23;
                $getReview = DB::table('tbl_reviews')->where('business_id',$id)->avg('rating');
               if($getReview) { 
                $preview['review']= round($getReview,1);
               }else {
                $preview['review'] = 0;
               }
               
                $preview['first_name'] = $data->business_first_name;
                $preview['last_name'] = $data->business_last_name;
                $preview['email'] = $data->business_email;
                $preview['mobile_no'] =$data->business_contactno;
                $preview['address'] =$data->business_address;
                $preview['city_name'] =$data->city_name;
                $preview['pincode'] =$data->pincode;

                $preview['business_title'] =$data->business_title;
                $preview['website'] =$data->business_website;
               
                $preview['user_type'] =$data->modeofpay !="" ? $userType[$data->modeofpay] :"";
               
                $preview['business_tag'] =$data->business_tag;
                $preview['business_desc'] =$data->business_desc;
                $preview['thumbnail_img'] =$data->thumbnail_img;
                $preview['banner_img'] =$data->banner_img;
                $preview['status'] =$data->status;
                $preview['lattutude_lat'] =$data->lattutude;
                $preview['longitude_lng'] =$data->longitude;
                $preview['view_count'] =$totalViewCount;
               
            }

            $getImages = DB::table('tbl_gallery')->where('business_id',$id)->get();
            $getWorkingDay = DB::table('tbl_workingday')->where('business_id',$id)->pluck('day','id')->toArray();
           
           // dd($getWorkingDay);
           
            return view('frontend.businessadmin.pages.preview-business')->with('allImages',$getImages)->with('preview',$preview)->with('working_days',$getWorkingDay)->with('title', $title);
       
            
    }

    function deleteImage(){
    
        $input = Input::all();
        $row = DB::table("tbl_gallery")->where('id',$input['id'])->delete();
        return response()->json(['status'=>'1','msg'=>'Image deleted successfully.']);
        
    }
	
}
