<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Users;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Intervention\Image\Facades\Image;

class BlogController extends Controller
{

    public function __construct()
    {
        $this->users = new Users();
    }

//    for get all users
    public function blogadd()
    {
        $title = "Blog Management";
        return view('admin.pages.blogadd')->with('title', $title);
    }
    
    public function bloglist()
    {
        $title = "Blog Management";
        return view('admin.pages.bloglist')->with('title', $title);
    }
}
