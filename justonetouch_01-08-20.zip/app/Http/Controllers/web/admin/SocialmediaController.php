<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Users;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Intervention\Image\Facades\Image;

class SocialmediaController extends Controller
{

    public function __construct()
    {
        $this->users = new Users();
    }

//    for get all users
    public function socialmedia()
    {
        $title = "Social Management";
        return view('admin.pages.socialmedia')->with('title', $title);
    }

}
