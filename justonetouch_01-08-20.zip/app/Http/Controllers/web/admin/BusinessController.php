<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Category;
use App\Models\Business;
use App\Models\Gallary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;

class BusinessController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->business = new Business();
        $this->gallary = new Gallary();
    }
    public function index(Request $request){

        $title = "Business";
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->business->getAll();
			//dd($getall);
            return view('admin.pages.businesslist')->with('getall',$getall)->with('title', $title);
        //}
    }
	
	public function addbusiness(Request $request){

        $title = "Add Bussiness";
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->category->getAllParent();
            $getallcity=DB::table('cities')->where('state_id',21)->get();
            $data = [];
            $getSubAll = [];
            $working_days = [];
            $getGallaryimages =[];

            return view('admin.pages.addbusiness')->with('getGallaryimages',$getGallaryimages)->with('working_days',$working_days)->with('getallcity',$getallcity)->with('getSuball',$getSubAll)->with('getall',$getall)->with('data',$data)->with('title', $title);
        //}
    }

    public function editbusiness(Request $request, $id = false){

        $title = "Edit Bussiness";
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->category->getAllParent();
            $getallcity=DB::table('cities')->where('state_id',21)->get();
            $data = DB::table('tbl_business')->where('id',$id)->first();
            $data = json_decode(json_encode($data),TRUE);
            if($data['lattutude']){
                $data['lattutude_lat'] = (float)$data['lattutude'];
            }else {
                $data['lattutude_lat'] =13.060422 ;
            }
            if($data['longitude']){
                $data['longitude_lng'] = (float)$data['longitude'];
            }else {
                $data['longitude_lng'] =80.249583;
            }
            $getSubAll = [];
            if($data['sub_category_id'] && $data['sub_category_id'] !=0) {
                $getSubAll = DB::table('tbl_category')->where('parent_id',$data['category_id'])->get();
            }

            
            $getWorkingDay = DB::table('tbl_workingday')->where('business_id',$id)->pluck('day','id')->toArray();
            $getGallaryimages = DB::table('tbl_gallery')->where('business_id',$id)->get();
           // dd($data);
          
            //'category_id' => $data['parent_id'],
            //'sub_category_id' => $data['subcat_id'],
           // dd($data['business_first_name']);
            return view('admin.pages.addbusiness')->with('getGallaryimages',$getGallaryimages)->with('working_days',$getWorkingDay)->with('getallcity',$getallcity)->with('getall',$getall)->with('getSubAll',$getSubAll)->with('data',$data)->with('title', $title);
        //}
    }
	
	public function getSubcategory($id)
	{
		$states = DB::table("tbl_category")
					->where("parent_id",$id)
					->pluck("category_name","id");
		return Response::json($states);
	}

    public function postbusiness(Request $request,$id = false)
    {
        $title = "Category";
        //$loginUser=Sentinel::getUser();
        $input = Input::all();

        //echo "<pre>";print_r($input);die;
        
        $data = [
            'id' => isset($input['id']) ? $input['id'] : NULL,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'business_firstname' => isset($input['business_firstname']) ? $input['business_firstname'] : '',
            'business_lastname' => isset($input['business_lastname']) ? $input['business_lastname'] : '',
            'business_title' => isset($input['business_title']) ? $input['business_title'] : '',
            'business_email' => isset($input['business_email']) ? $input['business_email'] : '',
			'business_contactno' => isset($input['business_contactno']) ? $input['business_contactno'] : '',
			'business_street' => isset($input['business_street']) ? $input['business_street'] : '',
            'business_website' => isset($input['business_website']) ? $input['business_website'] : '',
            'business_address' => isset($input['business_address']) ? $input['business_address'] : '',
            'business_street' => isset($input['business_street']) ? $input['business_street'] : '',
            'business_tags' => isset($input['business_tags']) ? $input['business_tags'] : '',
			'business_status' => isset($input['business_status']) ? $input['business_status'] : '',
            'business_desc' => isset($input['business_desc']) ? $input['business_desc'] : '',
            'business_image' => isset($input['business_image']) ? $input['business_image'] : '',
            'business_banner' => isset($input['business_banner']) ? $input['business_banner'] : '',
            'city_name' => isset($input['city_name']) ? $input['city_name'] : '',
            'filename' => isset($input['filename']) ? $input['filename'] : '',
            'pincode' => isset($input['pincode']) ? $input['pincode'] : '0',
            
            'cityLat' => isset($input['cityLat']) ? $input['cityLat'] : '',
            'cityLng' => isset($input['cityLng']) ? $input['cityLng'] : '',
            'category_type' => isset($input['category_type']) ? $input['category_type'] : '',
            'locationRoute' => isset($input['locationRoute']) ? $input['locationRoute'] : '',
            'about_business_img' => isset($input['about_business_img']) ? $input['about_business_img'] : '',

        ];
       
        
		
		if ($data['business_image']) 
		{
            $truckpictures = $input['business_image'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $thumb_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/thumbnail/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/thumbnail/icon/' . $imageName);
        } 
        else 
        {
            if ($data['id']) {
                
                $getbusiness = $this->business->getBusiness($data['id']);
              
                if ($getbusiness) {
                    $thumb_image_name = $getbusiness->thumbnail_img;
                } else {
                    $thumb_image_name= '';
                }

            } else {
                $thumb_image_name = '';
            }

        }
        
        if ($data['business_banner']) 
		{
            $truckpictures = $input['business_banner'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $banner_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/banner/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
        } 
        else 
        {
            if ($data['id']) {
                
                $getbusiness = $this->business->getBusiness($data['id']);
                if ($getbusiness) {
                    $banner_image_name = $getbusiness->banner_img;
                } else {
                    $banner_image_name= '';
                }

            } else {
                $banner_image_name = '';
            }

        }

         /****** ABOUT BUSINESS IMAGE UPLOAD START ******/

         if ($data['about_business_img']) 
         {
             $truckpictures = $input['about_business_img'];
             $imagesize = getimagesize($truckpictures);
 
             $width = $imagesize[0];
             $height = $imagesize[1];
             $image = $truckpictures->getClientOriginalExtension();
 
             $imageName = 'image' . '-' . uniqid() . '.' . $image;
             $about_business_img	 = $imageName;
             $imagePath = $truckpictures->move(base_path() . '/public/upload/business/aboutbusiness/', $imageName);
             $img = Image::make($imagePath->getRealPath());
 
         } 
         else 
         {
             if ($data['id']) {
                 
                 $getbusiness = $this->business->getBusiness($data['id']);
                 //dd($getbusiness);
                 if ($getbusiness) {
                     $about_business_img = $getbusiness->about_business_img;
                 } else {
                     $about_business_img = '';
                 }
 
             } else {
                 $about_business_img	 = '';
             }
 
         }
 
         /****** ABOUT BUSINESS IMAGE UPLOAD END ******/


        //$getallcity=DB::table('cities')->where('id',$data['city_id'])->first();
        //dd($getallcity);
        //$city_name=$getallcity->city;
        DB::beginTransaction();
        try {
        $userInput = array(
            'id' => $data['id'],
			'business_first_name' => $data['business_firstname'],
            'business_last_name' => $data['business_lastname'],
            'business_title' => $data['business_title'],
            'business_desc' => $data['business_desc'],
            'business_email' => $data['business_email'],
            'business_website' => $data['business_website'],
            'business_address' => $data['business_address'],
            'business_contactno' => $data['business_contactno'],
            'business_street' => $data['business_street'],
            'address_route' => $data['locationRoute'],
            //'city_id' => $data['city_id'],
            'city_name' => $data['city_name'],
            'pincode' => $data['pincode'],
            'lattutude' => $data['cityLat'],
            'longitude' => $data['cityLng'],
            'category_id' => $data['parent_id'],
            'sub_category_id' => $data['subcat_id'],
            'business_tag' => $data['business_tags'],
            'thumbnail_img' => $thumb_image_name,
            'banner_img' => $banner_image_name,
            'modeofpay' => $data['category_type'],
            'status'=>$data['business_status'],
            //'year_of_estd' => $data['year_of_estd'],
            'about_business_img' => $about_business_img,
        );
       
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $business_id = $this->business->saveBusiness($userInput);
            
        
        if($request->hasfile('filename'))
            {
    
                foreach($request->file('filename') as $images)
                {
                
                    if ($images) {

                        $truckpictures = $images;
        
                        $imagesize = getimagesize($truckpictures);
        
                        $width = $imagesize[0];
                        $height = $imagesize[1];
                        $image = $truckpictures->getClientOriginalExtension();
        
                        $imageName = 'image' . '-' . uniqid() . '.' . $image;
                        $gimage_name = $imageName;
                        $imagePath = $truckpictures->move(base_path() . '/public/upload/business/gallary/original', $imageName);
                        $img = Image::make($imagePath->getRealPath());
        
                        $largeWidth = $width;
                        $mediumWidth = $width;
                        $smallWidth = $width;
                        $extralargeWidth = $width;
                        $iconWidth = $width;
                        $thumbnailWidth = $width;
                        //thumbnail
                        if ($width > 200) {
                            $thumbnailWidth = 200;
                        }
                        Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/thumbnail/' . $imageName);
        
                        //small
                        if ($width > 320) {
                            $smallWidth = 320;
                        }
                        Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/small/' . $imageName);
        
                        //medium
                        if ($width > 375) {
                            $mediumWidth = 375;
                        }
        
                        //icon
                        if ($width > 64) {
                            $iconWidth = 64;
                        }
                        Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/icon/' . $imageName);


            } else {

                if ($id) {

                    $getbusiness = $this->gallary->getGallary($id);
                    if ($getbusiness) {
                        $gimage_name = $getbusiness->image;
                    } else {
                        $gimage_name= '';
                    }


                } else {
                    $gimage_name = '';
                }

            }
                $userInput = array(
                    'id' => $id,
                    'business_id' => $business_id,
                    'image_name' => $gimage_name,
    
                );
                if($userInput['id']){
                    $userInput['created_by']=1;
                }
                else{
                    $userInput['updated_by']=1;
                }
                $table = $this->gallary->saveGallary($userInput);
            
                }
            }
            
            if($data['id']) {
               
                DB::table('tbl_workingday')->where('business_id',$data['id'])->delete();
            }
            
            
        $working_day= [
            'id' => $id,
            'week_days' => isset($input['week_days']) ? $input['week_days'] : '',
            'starttime' => isset($input['starttime']) ? $input['starttime'] : '',
            'endtime' => isset($input['endtime']) ? $input['endtime'] : '',
            'open_close' => isset($input['open_close']) ? $input['open_close'] : '',
        ];
       
       
        
        $inputs =[];
        for ($i=0; $i <count($working_day['week_days']) ; $i++) {
            if($working_day['week_days'][$i] && $working_day['starttime'][$i] && $working_day['starttime'][$i]) {
                $inputs[$i]['day'] = $i;
                $inputs[$i]['week_days'] =$working_day['week_days'][$i];
                $inputs[$i]['starttime'] =$working_day['starttime'][$i];
                $inputs[$i]['endtime'] =$working_day['endtime'][$i]; 
                $inputs[$i]['open_close'] =$working_day['open_close'][$i]; 
                $inputs[$i]['business_id'] =$business_id;  
           }
    }
    
    
   if(!empty($inputs)){
        foreach($inputs as $key=>$value) {
            
            $draw[] = [
                'day' => $value['day'],
                'week_day' => $value['week_days'],
                'week_start_time' => $value['open_close'] == 'open' ? $value['starttime'] :"Close",
                'week_end_time' => $value['open_close'] == 'open' ? $value['endtime']:"Close",
                'open_close' => $value['open_close'],
                'business_id' => $value['business_id'],
            ];
        }
    }
    //dd($draw);
        $saveworking = DB::table('tbl_workingday')->insert($draw);
        DB::commit();
    } catch (\Exception $e){ 
        DB::rollback();

    }
        
        
           // if ($saveworking) {
               // return redirect('admin/businesslist')->with('success', 'Business updated Successfully.');
           // } else {
               return redirect('admin/businesslist')->with('success', 'Business Saved Successfully.');
            //}
    }
    public function deleteBusiness($id){
        $data=$this->business->deleteBusiness($id);
        return redirect('admin/businesslist')->with('success', 'Deleted Successfully.');
    }

    public function showDetails(){
        $input = Input::all();
        $getDetails = DB::table('tbl_business')->where('id',$input['id'])->first();
       // dd($getDetails);
        return response()->json(['getData'=>$getDetails]);
    }
    
    public function previewBusiness(Request $request, $id = false){

        $title = "preview Bussiness";
       
      
        //$loginUser=Sentinel::getUser(); 
        //if($loginUser->assembly_id){
            $getall=DB::table('tbl_category')->where('parent_id',0)->pluck('category_name','id');   
            
            
           
            $data = DB::table('tbl_business')->where('id',$id)->first(); 
         
            $userType = [                
                "1"=>"Free",
                "2"=>"Premium",
                "3"=>"Premium Plus",
                "4"=>"Ultra Premium Plus",
            ];
            if(!$data){
                return redirect('businesslist')->with('error','Data not found.');
            }else {
                
                $preview = [];
                $preview['category_name'] = $getall[$data->category_id];

                $getSubAll = DB::table('tbl_category')->where('parent_id',$data->category_id)->pluck('category_name','id'); 
              
                if($data->sub_category_id !="" || $data->sub_category_id ==0) {
                   $preview['sub_cat_name'] = $getSubAll[$data->sub_category_id];
                }else{
                    $preview['sub_cat_name'] = ""; 
                }

              //  $totalViewCount = DB::table('tbl_view_count')->where('business_id',$id)->sum('freqency');
              $totalViewCount = 23;
                $getReview = DB::table('tbl_reviews')->where('business_id',$id)->avg('rating');
               if($getReview) { 
                $preview['review']= round($getReview,1);
               }else {
                $preview['review'] = 0;
               }
               
                $preview['first_name'] = $data->business_first_name;
                $preview['last_name'] = $data->business_last_name;
                $preview['email'] = $data->business_email;
                $preview['mobile_no'] =$data->business_contactno;
                $preview['address'] =$data->business_address;
                $preview['city_name'] =$data->city_name;
                $preview['pincode'] =$data->pincode;

                $preview['business_title'] =$data->business_title;
                $preview['website'] =$data->business_website;
               
                $preview['user_type'] =$data->modeofpay !="" ? $userType[$data->modeofpay] :"";
               
                $preview['business_tag'] =$data->business_tag;
                $preview['business_desc'] =$data->business_desc;
                $preview['thumbnail_img'] =$data->thumbnail_img;
                $preview['banner_img'] =$data->banner_img;
                $preview['status'] =$data->status;
                $preview['lattutude_lat'] =$data->lattutude;
                $preview['longitude_lng'] =$data->longitude;
                $preview['view_count'] =$totalViewCount;
               
            }

            $getImages = DB::table('tbl_gallery')->where('business_id',$id)->get();
            $getWorkingDay = DB::table('tbl_workingday')->where('business_id',$id)->pluck('day','id')->toArray();
           
           // dd($getWorkingDay);
           
            return view('admin.pages.preview-business')->with('allImages',$getImages)->with('preview',$preview)->with('working_days',$getWorkingDay)->with('title', $title);
       
            
    }
}
