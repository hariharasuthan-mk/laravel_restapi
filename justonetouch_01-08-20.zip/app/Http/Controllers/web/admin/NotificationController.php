<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Users;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Intervention\Image\Facades\Image;

class NotificationController extends Controller
{

    public function __construct()
    {
        $this->users = new Users();
    }
//    for get all users
    public function allnotification()
    {
        $title = "Notification Management";
        return view('admin.pages.allnotification')->with('title', $title);
    }
    
    public function usernotification()
    {
        $title = "Notification Management";
        return view('admin.pages.usernotification')->with('title', $title);
    }
    public function pushnotification()
    {
        $title = "Notification Management";
        return view('admin.pages.pushnotification')->with('title', $title);
    }

}
