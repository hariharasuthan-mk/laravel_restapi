<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;

class CategoryController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    public function index(Request $request){

        $title = "Category";
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->category->getAll();
			//dd($getall);
            return view('admin.pages.categorylist')->with('getall',$getall) ->with('title', $title);
        //}
    }
    
    public function admin(Request $request){
       
            return view('admin.pages.dashboard');
    }
    
    public function dblisting(Request $request){

       
            return view('admin.pages.adminlisting');
    }
	
	
    public function form(Request $request, $id=false){

             $title = "Edit Category";
             $getall=$this->category->getAllParent();            
            
           
             $subcat = [];
             if($id) {
               $data=$this->category->getCategory($id); 
               $data = json_decode(json_encode($data), True);             
               if($data['parent_id'] != 0) {
                  $datass=$this->category->getCategory($data['parent_id']); 
                  $subcat = DB::table('tbl_category')->where('parent_id',$datass->parent_id)->get();
                  //dd();
                
                  $data['grand_parent_id'] = $datass->parent_id; 
               }
               else {
                $data['grand_parent_id'] = ""; 
               }
               
             }else {
                $data['id'] ="";
                $data['parent_id'] ="";
                $data['category_image'] ="";
                
             }

             //dd($data);

            
            return view('admin.pages.addcategory')->with('getall',$getall)->with('subcat',$subcat)->with('data',$data)->with('title', $title);
      
    }
	
	public function getSubcategory($id)
	{
		$states = DB::table("tbl_category")
					->where("parent_id",$id)
					->pluck("category_name","id");
		return Response::json($states);
	}

    public function postcategory(Request $request,$id = false)
    {  
        $title = "Category";
        //$loginUser=Sentinel::getUser();
        $input = Input::all();
        $getall=$this->category->getAllParent();
       //echo "<pre>";print_r($input);die;
        $data = [
            'id' => $id,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '0',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '0',
            'cat_name' => isset($input['cat_name']) ? $input['cat_name'] : '',
            'cat_desc' => isset($input['cat_desc']) ? $input['cat_desc'] : '',
            'image' => isset($input['image']) ? $input['image'] : '',
        ];

        $rules = [
            'cat_name' => 'required',
            'cat_desc' => 'required'
        ];
        $error = array();
        $checkStatus = false;
        if ($request->isMethod('post')) {

            $checkValid = Validator::make($data, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
        } elseif ($request->isMethod('get')) {
            $checkStatus = true;
        }


        if ($checkStatus) {

            $data['id'] ="";
            $data['parent_id'] ="";
            $data['category_image'] ="";
            //dd($error);
            return redirect('admin/addcategory')
            ->withErrors($checkValid)
            ->withInput();
            //return view('admin.pages.addcategory')->with('data', $data)->with('errors', $error)->with('getall',$getall)->with('title', $title);

        } else {
       
		
		if ($data['image']) {

                   $truckpictures = $input['image'];
                    $imagesize = getimagesize($truckpictures);

                    $width = $imagesize[0];
                    $height = $imagesize[1];
                    $image = $truckpictures->getClientOriginalExtension();

                    $imageName = 'image' . '-' . uniqid() . '.' . $image;
                    $image_name = $imageName;
                    $imagePath = $truckpictures->move(base_path() . '/public/upload/category/original', $imageName);
                    $img = Image::make($imagePath->getRealPath());

                    $largeWidth = $width;
                    $mediumWidth = $width;
                    $smallWidth = $width;
                    $extralargeWidth = $width;
                    $iconWidth = $width;
                    $thumbnailWidth = $width;
                    //thumbnail
                    if ($width > 200) {
                        $thumbnailWidth = 200;
                    }
                    Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/thumbnail/' . $imageName);

                    //small
                    if ($width > 320) {
                        $smallWidth = 320;
                    }
                    Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/small/' . $imageName);

                    //medium
                    if ($width > 375) {
                        $mediumWidth = 375;
                    }
                    Image::make($imagePath)->resize($mediumWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/medium/' . $imageName);

                    //extraLarge
                    if ($width > 768) {
                        $extralargeWidth = 768;
                    }
                    Image::make($imagePath)->resize($extralargeWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/extralarge/' . $imageName);

                    //large
                    if ($width > 425) {
                        $largeWidth = 425;
                    }
                    Image::make($imagePath)->resize($largeWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/large/' . $imageName);

                    //icon
                    if ($width > 64) {
                        $iconWidth = 64;
                    }
                    Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/icon/' . $imageName);
            } else {

                if ($id) {

                    $getcategory = $this->category->getCategory($id);
                    if ($getcategory) {
                        $image_name = $getcategory->category_image;
                    } else {
                        $image_name= '';
                    }


                } else {
                    $image_name = '';
                }

            }
			$subcatid=$data['subcat_id'];
			if($subcatid)
			{
				$parentid=$subcatid;
			}
			else{
				$parentid=$data['parent_id'];
			}
			$userInput = array(
                'id' => $id,
				'category_name' => $data['cat_name'],
                'parent_id' => $parentid,
                'category_slug' => $data['cat_name'],
                'category_desc' => $data['cat_desc'],
                'category_image' => $image_name,
            );
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $table = $this->category->saveCategory($userInput);
			
            if ($table) {
                return redirect('admin/categorylist')->with('success', 'Category updated Successfully.');
            } else {
                return redirect('admin/categorylist')->with('success', 'Category created Successfully.');
            }
    }
}
    public function deleteCategory($id){
        $data=$this->category->deleteCategory($id);
        return redirect('admin/categorylist')->with('success', 'Deleted Successfully.');
    }
}
