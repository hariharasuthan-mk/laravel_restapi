<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Users;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Intervention\Image\Facades\Image;

class UserController extends Controller
{

    public function __construct()
    {
        $this->users = new Users();
    }

//    for get all users
    public function useradd($id=false)
    {
        $title = "User Management";
        //$getCity=DB::table('cities')->get();
        $data = [];
        if($id) {
           $data = $this->users->getUserById($id);         
           $data = json_decode(json_encode($data),TRUE);       
         
        }
        return view('admin.pages.useradd')->with('title', $title)->with('data',$data);
    }
    public function adminuseradd(Request $request) 
    {

        $title = "Signup";
        $input = Input::all();
        //echo "<pre>";print_r($input);die; 

        $data = [
            'id' => isset($input['id']) ? $input['id'] : '',
            'first_name' => isset($input['first_name']) ? $input['first_name'] : '',
            'last_name' => isset($input['last_name']) ? $input['last_name'] : '',
            'mobile_no' => isset($input['mobile_no']) ? $input['mobile_no'] : '',
            'email' => isset($input['email']) ? $input['email'] : '',
            'address' => isset($input['address']) ? $input['address'] : '',
            'category_type' => isset($input['category_type']) ? $input['category_type'] : '',
        ];
        
        $rules = [
            'first_name' => 'required',
            "email" => 'required|email|unique:tbl_user,email,'.$data['id'],
            "mobile_no" => 'required|digits:10|unique:tbl_user,mobile_no,'.$data['id'],
            'category_type' => 'required',
        ]; 
        $error = array();
        $checkStatus = false;
        if ($request->isMethod('post')) {

            $checkValid = Validator::make($input, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
        } elseif ($request->isMethod('get')) {
            $checkStatus = true;
        }
       
        if ($checkStatus) {
            return redirect('admin/useradd/'.$data['id'])
            ->withErrors($checkValid)
            ->withInput();
            //return view('admin.pages.useradd')->with('errors', $error)->with('title', $title);

        } else {
            $input = Input::all();
            if($data['id']){
                //dd($data);

                $userInput = array(                                  
                    'first_name' => $data['first_name'],
                    'last_name' => $data['last_name'],
                    'email' => $data['email'],
                    'mobile_no' => $data['mobile_no'],
                    'address' => $data['address'],
                    'category_type' => $data['category_type']    
                );

                DB::table('tbl_user')->where('id',$data['id'])->update($userInput);
                return redirect('admin/userlist')->with('message', 'User profile is updated successfully.');


            }else {

            $userInput = array(
                'id'=>false,
                'uuid' => uniqid(),
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $data['email'],
                'mobile_no' => $data['mobile_no'],
                'address' => $data['address'],
                'category_type' => $data['category_type'],
                'password' => 123456,
                'password_str' => 123456,
                'is_active' =>1,

            );
                //echo "<pre>";print_r($userInput);die;
                $userrs = Sentinel::registerAndActivate($userInput);
               //$userrs=$this->users->saveUser($userInput);
               return redirect('admin/userlist')->with('message', 'We sent you an activation code. Check your email and click on the link to verify.');

        }
        }


    }
    
    public function userlist()
    {
        $title = "User Management";
        $userRs=DB::table('tbl_user')->get();
        
        $temp=array();
        foreach($userRs as $key=>$val)
        {
            $temp[$key]=$val;
            $user_id=$val->id;
            $temp[$key]->businessCnt=DB::table('tbl_business')->where('user_id',$user_id)->count();
            $temp[$key]->enquiryCnt=DB::table('tbl_quotes')->where('author_id',$user_id)->count();
            $temp[$key]->reviewCnt=DB::table('tbl_reviews')->where('user_id',$user_id)->count();
        }
        
        //dd($temp);
        
        return view('admin.pages.userlist')->with('title', $title)->with('userRs',$temp);
    }

    public function deleteUser($id){
        DB::table('tbl_user')->where('id',$id)->delete();
        return redirect('admin/userlist')->with('success', 'User deleted successfully.');
    }
    

}
