<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;

class DashboardController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    
    public function index(Request $request){

        $title = "Dashboard";
        $loginId = sentinel::getUser()->id;
        $businesscnt=DB::table('tbl_business')->count();
        $quotescnt=DB::table('tbl_quotes')->count();
        $users=DB::table('tbl_user')->where('user_group_id', 0)->get();
        $usercnt=count($users);
        $businessRs=DB::table('tbl_business')->orderby('created_at','desc')->take(5)->get();
        //dd($businessRs);
        $userRs=DB::table('tbl_user')->orderby('created_at','desc')->take(5)->get();
        
        //$userRs=DB::table('tbl_user')->get();
        
        $temp=array();
        foreach($userRs as $key=>$val)
        {
            $temp[$key]=$val;
            $user_id=$val->id;
            $temp[$key]->businessCnt=DB::table('tbl_business')->where('user_id',$user_id)->count();
            $temp[$key]->enquiryCnt=DB::table('tbl_quotes')->where('author_id',$user_id)->count();
            $temp[$key]->reviewCnt=DB::table('tbl_reviews')->where('user_id',$user_id)->count();
        }
        $leadRs=DB::table('tbl_quotes')->orderby('created_at','desc')->take(5)->get();
        
        return view('admin.pages.dashboard')->with('title', $title)->with('quotescnt',$quotescnt)->with('leadRs',$leadRs)->with('businessRs',$businessRs)->with('userRs',$temp)->with('businesscnt',$businesscnt)->with('usercnt',$usercnt);
    }
    
	
}
