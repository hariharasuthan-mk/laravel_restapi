<?php

namespace App\Http\Controllers\web\admin;

use App\Models\Category;
use App\Models\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use App\Helpers\Common;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Session;
use Illuminate\Support\Facades\URL;


class LoginController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->users = new Users();
    }
    public function index(Request $request){

        $title = "Signup";
        return view('admin.pages.login')->with('title', $title);
    }
    public function adminpostLogin(Request $request)
  {
      try {
          $input = Input::all();

          $data = array(
              'mobile_no' => isset($input['mobile_no']) ? $input['mobile_no'] : '',
              'password' => isset($input['password']) ? $input['password'] : '',
          );

          //echo "<pre>";print_r($data);die;
          $rules = [
              'mobile_no' => 'required',
              'password' => 'required',
          ];
          $validator = \Illuminate\Support\Facades\Validator::make($input, $rules);
          if ($validator->fails()) {
              return Redirect::back()
                  ->withInput()
                  ->withErrors($validator);
          }
          $remember = (bool)Input::get('remember', false);
          //echo"<pre>";print_r($remember);die;
          if ($user = Sentinel::authenticate($data, $remember)) {
             // echo"<pre>";print_r($user);die;
              if($user->is_active == 1) {

                  if($user->user_group_id==1){
                      return redirect('admin/dashboard');
                  }else{
                   
                    $errors = 'Invalid login or password.';
                    Session::flash('error','Invalid login or password.');
                    return Redirect::back();
                  }

              }else {
                  $errors = "Your account is deactivated. Please contact admin.";
                  Session::flash('error',$errors);
                  return Redirect::back()
                      ->withInput()
                      ->withErrors($errors);
              }


          } else {
              $errors = 'Invalid login or password.';
              Session::flash('error','Invalid login or password.');
              return Redirect::back();
                
          }
      } catch (ThrottlingException $e) {
          $delay = $e->getDelay();

          $errors = "Your account is blocked for {$delay} second(s).";
        
          return Redirect::back()
              ->withInput()
              ->withErrors($errors);
      } 
      
      catch (\Cartalyst\Sentinel\Checkpoints\NotActivatedException $e){
          return Redirect::back()->with(['error' => "u r not Actived."]);
      }
  }

  public function logout()
    {
        Sentinel::logout();
        Session::flash('success','You have logged out succesfully.');
        return Redirect::to('admin');
    }
	
}
