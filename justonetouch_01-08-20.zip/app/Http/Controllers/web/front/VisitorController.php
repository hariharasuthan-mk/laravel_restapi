<?php

namespace App\Http\Controllers\web\front;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Helpers\Common;
use Illuminate\Pagination\LengthAwarePaginator;
use Carbon\Carbon;
use Illuminate\Support\Facades\View;
use App\Helpers\IPInfoDB;
use Location;


class VisitorController extends Controller
{
    public function __Construct()
    {
    }
    public function visitorinfo(Request $request){

        $title = "Visitors";
		$input = Input::all();
        //dd($input);
        $uniquechk=DB::table('visitor_details')->where('current_page',$input['current_page'])->where('ipaddr',$input['ipaddr'])->first();  
        //dd($uniquechk);
        if($uniquechk=="")
        {
                $segments = explode('/', $input['current_page']);
                //dd($segments[3]);
                if($segments[3]=="search")
                {
                   $categoryid=Common::decodeData($segments[4]);
                   $categoryname=$segments[5];
                   $sub_categoryid="";
                   $subcategoryname="";
                   $businessid=0;
                   $businessname="";
                }
                elseif($segments[3]=="searchlist")
                {
                   $sub_categoryid=Common::decodeData($segments[4]);
                   $catRs=DB::table('tbl_category')->where('id',$sub_categoryid)->first();
                   //dd($catRs);
                   $categoryid=$catRs->parent_id;
                   $categoryRs=DB::table('tbl_category')->where('id',$categoryid)->first();
                   $categoryname=$categoryRs->category_name;
                   $subcategoryname=$segments[5];
                   $businessid=0;
                   $businessname="";
                }
                elseif($segments[3]=="list")
                {
                   $businessid=Common::decodeData($segments[4]);
                   $businessRs=DB::table('tbl_business')->where('id',$businessid)->first();
                   $businessname=$businessRs->business_title;
                   
                   $categoryid=$businessRs->category_id;
                   $sub_categoryid=$businessRs->sub_category_id;
                   
                   $categorynameRs=DB::table('tbl_category')->where('id',$categoryid)->first();
                   $categoryname=$categorynameRs->category_name;
                   $subcategorynameRs=DB::table('tbl_category')->where('id',$sub_categoryid)->first();
                   $subcategoryname=$subcategorynameRs->category_name;
                }
                $ip = $input['ipaddr'];
                $data = \Location::get($ip);
                //dd($data);
                //$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}"));
                //dd($details->city);
                $userInput = array(
                'ipaddr' => $input['ipaddr'],
                'current_page' => $input['current_page'],
                'view_time' => $input['view_time'],
                'user_agent' => $input['browser'],
                'city' => $data->cityName,
                'region' => $data->regionName,
                'country' => $data->countryName,
                'latitude' => $data->latitude,
                'longitude' => $data->longitude,
                'postal' => $data->zipCode,
                'created_at' => Carbon::now()->toDateTimeString(),
                'category_id' => $categoryid,
                'category_name' => $categoryname,
                'sub_category_id' => $sub_categoryid,
                'sub_categoryname' => $subcategoryname,
                'business_id' => $businessid,
                'business_name' => $businessname,
            );
            //dd($userInput);
                $result=DB::table('visitor_details')->insertGetId($userInput);
                
                return Response::json([
                    'status' => 1,
                    'success' => 'Added new records'
                ], 200);
        }

    }
}
