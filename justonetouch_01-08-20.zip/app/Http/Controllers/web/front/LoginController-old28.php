<?php

namespace App\Http\Controllers\web\front;

use App\Models\Category;
use App\Models\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use App\Helpers\Common;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use Session;
use Illuminate\Support\Facades\URL;


class LoginController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->users = new Users();
    }
    public function signup(Request $request){

        $title = "Signup";
        return view('frontend.signup')->with('title', $title);
    }
    public function postsignup(Request $request){

        $title = "Signup";
        $input = Input::all();
        //echo "<pre>";print_r($input);die;

        $data = [
            'name' => isset($input['name']) ? $input['name'] : '',
            'mobile' => isset($input['mobile']) ? $input['mobile'] : '',
            'email' => isset($input['email']) ? $input['email'] : '',
            'password' => isset($input['password']) ? $input['password'] : '',
            'confirmPassword' => isset($input['confirmPassword']) ? $input['confirmPassword'] : '',
            'active' => isset($input['active']) ? $input['active'] : '',
        ];
        
        
        $rules = [
            'name' => 'required',
            "email" => 'required|email|unique:tbl_user,email',
            "mobile" => 'required|digits:10|unique:tbl_user,mobile_no',
            'password' => 'required',
            'confirmPassword' => 'required',
            'active' => 'required',

        ];
        $error = array();
        $checkStatus = false;
        if ($request->isMethod('post')) {

            $checkValid = Validator::make($input, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
        } elseif ($request->isMethod('get')) {
            $checkStatus = true;
        }
        
        if ($checkStatus) {
            return Response::json([
                    'status' => 0,
                    'errors' => $error
                ], 200);
            //return view('frontend.signup')->with('errors', $error)->with('title', $title);

        } else {
            $input = Input::all();
            $otp = rand(1000, 9999);
            $userInput = array(
                'uuid' => uniqid(),
                'first_name' => $input['name'],
                //'last_name' => $input['lastName'],
                'email' => $input['email'],
                'mobile_no' => $input['mobile'],
                'password' => $input['password'],
                'password_str' => $input['confirmPassword'],
                'otp' => $otp,
                'is_active' =>$input['active'],
                'email_verification_code' =>mt_rand(100000, 999999),

            );
                //echo "<pre>";print_r($userInput);die;
                $userrs = Sentinel::registerAndActivate($userInput);
                
                $message = "IEMS -" . $otp . " is your Just One Touch verification code";
                //$output = Common::newSMS($data['mobile'], $message);
                return Response::json([
                    'status' => 1,
                    'id'=>$userrs['id'],
                    'success' => 'Added new records'
                ], 200);
                //return view('frontend.verification')->with('user',$userrs['id'])->with('title',"Email Verification Code");
               
               /* $last_insert_id = $userrs->id;
                $userlogin = Sentinel::findById($last_insert_id);
                Sentinel::login($userlogin);
                if($userlogin)
                {
                    return redirect('businessadmin');
                }
                else
                {
                    return redirect('signup');
                }*/
                /*$Mailmessage=$userInput['email_verification_code'];
                Mail::send(['html' => 'frontend.sendemail'], ['temp' => $userrs], function ($message) use ($userInput) {
                    $message->to($userInput['email']);
                });
                //return redirect('signup')->with('message', 'We sent you an activation code. Check your email and click on the link to verify.');
                */
                

        }


    }
    public function signin(Request $request){

        $title = "Signup";
        Session::put('url.intended',URL::previous());
        return view('frontend.signin')->with('title', $title);
    }
    public function postsignin(Request $request){
        $title = "Signin";
        try {
          $input = Input::all();

          $data = array(
              'mobile_no' => isset($input['mobile_no']) ? $input['mobile_no'] : '',
              'password' => isset($input['password']) ? $input['password'] : '',
          );

          //echo "<pre>";print_r($data);die;
          $rules = [
              'mobile_no' => 'required',
              'password' => 'required',
          ];
          $checkValid = Validator::make($input, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
                return view('frontend.signin')->with('errors', $error)->with('title', $title);
            }
            else
            {
                 $remember = (bool)Input::get('remember', false);
                 if ($user = Sentinel::authenticate($data, $remember)) {
                        //echo"<pre>";print_r($user);die;
                        if($user->is_active == 1) {
            
                            //return redirect('businessadmin');
                            return Redirect::to(Session::get('url.intended'));
            
                          }else {
                              $error = ['Your account is deactivated..'];
                              return view('frontend.signin')->with('errors', $error)->with('title', $title);
                          }
            
                  } else {
                      $error = ['Invalid login or password.'];
                      return view('frontend.signin')->with('errors', $error)->with('title', $title);
                  }
            }
         
       }
     catch (ThrottlingException $e) {
          $delay = $e->getDelay();
          $error = ["Your account is blocked for {$delay} second(s)."];
          return view('frontend.signin')->with('error', $error)->with('title', $title);
          
      } catch (NotActivatedException $e) {
          $error = ["Your are not activated"];
          return view('frontend.signin')->with('error', $error)->with('title', $title);
          //return Redirect::back()->with(['error' => "u r not Actived."]);
      }
    }
    
    public function logout()
    {
        Sentinel::logout();
        return Redirect::to('/');
    }
    public function verifyotp(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $input = Input::all();
        
        $data = [
            'userid' => isset($input['userid']) ? $input['userid'] : '',
            'otp' => isset($input['otp']) ? $input['otp'] : '',
            ];
        $saveuser =$this->users->getUserById($data['userid']);
        //dd($saveuser);
        //if($checkOtp->otp!=$data['otp']){
        if($saveuser->otp==$data['otp']){
            
            $data = array(
              'mobile_no' => $saveuser->mobile_no,
              'password' => $saveuser->password_str,
          );
          $remember = (bool)Input::get('remember', false);
                 if ($user = Sentinel::authenticate($data, $remember)) {
                        //echo"<pre>";print_r($user);die;
                        if($user->is_active == 1) {
                            //return redirect('businessadmin');
                            return Response::json([
                                'status' => 1
                            ], 200);
                        }
                 }
            
            
        }
        else
        {
            $error=['Invalid otp. Please provide valid otp'];
             return Response::json([
                    'status' => 0,
                    'errors' => $error
                ], 200);
        }
        
        
    }
	
}
