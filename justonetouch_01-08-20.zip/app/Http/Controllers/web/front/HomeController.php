<?php

namespace App\Http\Controllers\web\front;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Helpers\Common;
use Illuminate\Pagination\LengthAwarePaginator;
use Carbon\Carbon;
use Illuminate\Support\Facades\View;
use URL;
use Cookie;

class HomeController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }
    public function index(Request $request){

        $title = "Category";
        //$loginUser=Sentinel::getUser();
        //if($loginUser->assembly_id){
            $getall=$this->category->getAllParent();
            $temp=array();
            foreach($getall as $key=>$val)
            {
                $temp[$key]=$val;
                $catid=$val->id;
                $temp[$key]->id=$this->encodeData($catid);
            }
            $businessRs = DB::table('tbl_business as tb')
            ->select('tb.id as businessid','tb.business_title','tb.thumbnail_img','tb.business_address','tc.category_name','tc.id as categoryid')
            ->join('tbl_category as tc', 'tb.sub_category_id', '=', 'tc.id')
                ->inRandomOrder()
                ->take(4)
                ->get();
                
           
                $businesstemp=array();
                foreach($businessRs as $key=>$val)
                {
                    $businesstemp[$key]=$val;
                    $businessid=$val->businessid;
                    $businesstemp[$key]->id=$this->encodeData($businessid);
                }
                
                $businesssecRs = DB::table('tbl_business as tb')
            ->select('tb.id as businessid','tb.business_title','tb.thumbnail_img','tb.business_address','tc.category_name','tc.id as categoryid')
            ->join('tbl_category as tc', 'tb.sub_category_id', '=', 'tc.id')
                ->inRandomOrder()
                ->take(4)
                ->get();
                $businesstempsec=array();
                foreach($businesssecRs as $key=>$val)
                {
                    $businesstempsec[$key]=$val;
                    $businessid=$val->businessid;
                    $businesstempsec[$key]->id=$this->encodeData($businessid);
                }
                
                
                //dd($businesstemp);
                
            //echo "<pre>";print_r($businesstemp);die;
		
            return view('frontend.index')->with('getall',$temp)->with('randombusiness',$businesstemp)->with('randombusinessec',$businesstempsec)->with('title', $title);
        //}
    }
	
	public function subcategorylist(Request $request,$id,$slug){

        $title = "Category";
        //echo $id.$slug;die;
        $cid=$this->decodeData($id);
        if($cid)
        {
            $getcatRs=DB::table('tbl_category')->where('id',$cid)->first();
            $getallsub=$this->category->getAllsubcat($cid);
            $temp=array();
                foreach($getallsub as $key=>$val)
                {
                    $temp[$key]=$val;
                    $catid=$val->id;
                    $temp[$key]->id=$this->encodeData($catid);
                }
            	//dd($temp);
            	
            return view('frontend.subcategorylist')->with('title', $title)->with('getallsub',$temp)->with('slug',$slug)->with('getcatRs',$getcatRs);
        }
        else
        {
            return redirect('/');
        }
    }
    
    public function businesslist(Request $request,$cid,$slug){

        $title = "Business";
      
        //echo $id.$slug;die;
        $id=$this->decodeData($cid);
        if($id)
        {
            //echo $id.$slug;die;
            $getbusinessRs=DB::table('tbl_business')->where('sub_category_id',$id)->first();
            //dd($getbusinessRs);
            
            if(isset($getbusinessRs->category_id))
            {
                
                $getcategoryRs=DB::table('tbl_business')->where('sub_category_id',$id)->first();
                $catid=$getcategoryRs->category_id;
                //dd($catid);
                $categoryid=$this->encodeData($catid);
                
                $catagorynameRs=DB::table('tbl_category')->where('id',$catid)->first();
                $catagoryname=$catagorynameRs->category_slug;
                
                $getallsub=$this->category->getAllsubcat($catid);
                //dd($getallsub);
                
                $descbusinessRs = DB::table('tbl_business')->where('category_id',$catid)->get();
                //dd($descbusinessRs);
                $desctemp=array();
                foreach($descbusinessRs as $key=>$val)
                {
                    $desctemp[$key]=$val;
                    $businessid=$val->id;
                    $desctemp[$key]->id=$this->encodeData($businessid);
                }
                //dd($desctemp);
                
                $recentbusinessRs = DB::table('tbl_business')
                ->where('category_id',$catid)
                ->inRandomOrder()
                ->get();

                $temp=array();
                foreach($recentbusinessRs as $key=>$val)
                {
                    $temp[$key]=$val;
                    $catid=$val->id;
                    $getReview = DB::table('tbl_reviews')->where('business_id',$val->id)->avg('rating');
                    $temp[$key]->id=$this->encodeData($catid);
                    if($getReview) { 
                        $temp[$key]->review = round($getReview,1);
                    }else {
                        $temp[$key]->review = '0.0';
                    }
                   
                }
                
          
                // Get current page form url e.x. &amp;page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();
 
        // Create a new Laravel collection from the array data
        $itemCollection = collect($temp);
 
        // Define how many items we want to be visible in each page
        $perPage = 10;
 
        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
 
        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);

        // set url path for generted links
        $paginatedItems->setPath($request->url());
        
                
                //$recentbusinessliRs=DB::table('tbl_business')->where('sub_category_id',$id)->orderby('id','desc')->get();
            }
            else
            {
                $getcategoryRs=DB::table('tbl_category')->where('id',$id)->first();
                //dd($getcategoryRs);
                $catid=$getcategoryRs->parent_id;
                $categoryid=$this->encodeData($catid);
                
                $getparentcategoryRs=DB::table('tbl_category')->where('id',$catid)->first();
                //dd($getparentcategoryRs);
                $catagoryname=$getparentcategoryRs->category_slug;
                
                $getallsub=$this->category->getAllsubcat($catid);
                //dd($getallsub);
                
                $recentbusinessRs = DB::table('tbl_business')
                ->where('category_id',$catid)
                ->inRandomOrder()
                ->get();

                $temp=array();
                foreach($recentbusinessRs as $key=>$val)
                {
                    $temp[$key]=$val;
                    $catid=$val->id;
                    $temp[$key]->id=$this->encodeData($catid);
                }
                
                $descbusinessRs = DB::table('tbl_business')
                ->where('category_id',$catid)->orderBy('id','DESC')
                //->inRandomOrder()
                ->get();
                $desctemp=array();
                foreach($descbusinessRs as $key=>$val)
                {
                    $desctemp[$key]=$val;
                    $catid=$val->id;
                   
                    $getReview = DB::table('tbl_reviews')->where('business_id',$val->id)->avg('rating');               
                    $desctemp[$key]->id=$this->encodeData($catid);
                    if($getReview) { 
                        $desctemp[$key]->review = round($getReview,1);
                    }else {
                        $desctemp[$key]->review = '0.0';
                    }
                   
                }
             
                // Get current page form url e.x. &amp;page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();
 
        // Create a new Laravel collection from the array data
        $itemCollection = collect($temp);
 
        // Define how many items we want to be visible in each page
        $perPage = 10;
 
        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
 
        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);

        // set url path for generted links
        $paginatedItems->setPath($request->url());
            }
            
        return view('frontend.searchlist')->with('title', $title)->with('categoryid',$categoryid)->with('catagoryname',$catagoryname)->with('getbusinessRs',$paginatedItems)->with('getallsub',$getallsub)->with('slug',$slug)->with('nearbybusinessRs',$desctemp);
        }
        else
        {
            return redirect('/');
        }
        
    }

    
    public function businessdetails(Request $request,$bid,$slug){
        //echo $id.$slug;die;
        $title = "Business";
        $id=$this->decodeData($bid);
        $userIp = $request->ipinfo->ip;
    
      /*  $pageWasRefreshed = isset($_SERVER['HTTP_CACHE_CONTROL']) && $_SERVER['HTTP_CACHE_CONTROL'] === 'max-age=0';

        if($pageWasRefreshed == false ) {
            $this->viewCount($id,$userIp);
        } */
     
       
        if($id)
        {
            $getbusinessRs=DB::table('tbl_business')->where('id',$id)->first();
            
            $categoryid=$getbusinessRs->category_id;
            $randomBusiness = DB::table('tbl_business')
                ->where('category_id',$categoryid)
                ->inRandomOrder()
                ->take(10)
                ->get();
            //dd($randomBusiness);
            $randomtemp=array();
                foreach($randomBusiness as $key=>$val)
                {
                    $randomtemp[$key]=$val;
                    $catid=$val->id;
                    $randomtemp[$key]->id=$this->encodeData($catid);
                }
                
            $galleryRs=DB::table('tbl_gallery')->where('business_id',$id)->get();
            $workingdayRs=DB::table('tbl_workingday')->where('business_id',$id)->get();
            //$commentRs = DB::table('tbl_reviews')->where('business_id',$id)->orderby('created_at','desc')->get();
              $commentRs=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name','tbl_user.user_image','tbl_user.user_image_path')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            //->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$id)
            ->orderby('created_at','desc')
            ->get();
            
            $max = 0;
            $reviewcnt = count($commentRs); // get the count of comments
            foreach ($commentRs as $rate => $count) { // iterate through array
            $max = $max+$count->rating;
            }
            if($reviewcnt > 0)
            {
            $avgrating= $max / $reviewcnt;
            $finalAvgrating=round($avgrating, 1);
            }
            else
            {
                $avgrating= "";
                $finalAvgrating="";
            }

            
            
            return view('frontend.listdetail')->with('title', $title)->with('reviewcnt',$reviewcnt)->with('finalAvgrating',$finalAvgrating)->with('commentRs',$commentRs)->with('randomBusiness',$randomtemp)->with('getbusinessRs',$getbusinessRs)->with('galleryRs',$galleryRs)->with('workingdayRs',$workingdayRs);
        }
        else
        {
            return redirect('/');
        }
    }
    
    public function encodeData($string) {
        if (isset($string) || !empty($string)) {
            $string = trim($string);
            $string = base64_encode(@serialize($string));
            $base64clean = str_replace(array('=','+','/'),'',$string);
            return $base64clean;
        }
    }
	public function decodeData($string) {
		
        if (isset($string) || !empty($string)) {
            $string = trim($string);
            return @unserialize(base64_decode($string));
        }
    }
	
	public function getSubcategory($id)
	{
		$states = DB::table("tbl_category")
					->where("parent_id",$id)
					->pluck("category_name","id");
		return Response::json($states);
	}

    public function postcategory(Request $request,$id = false)
    {
        $title = "Category";
        //$loginUser=Sentinel::getUser();
        $input = Input::all();

         //echo "<pre>";print_r($input);die;
        $data = [
            'id' => $id,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'cat_name' => isset($input['cat_name']) ? $input['cat_name'] : '',
            'cat_desc' => isset($input['cat_desc']) ? $input['cat_desc'] : '',
            'image' => isset($input['image']) ? $input['image'] : '',
        ];
		
		if ($data['image']) {

                $truckpictures = $input['image'];
                    $imagesize = getimagesize($truckpictures);

                    $width = $imagesize[0];
                    $height = $imagesize[1];
                    $image = $truckpictures->getClientOriginalExtension();

                    $imageName = 'image' . '-' . uniqid() . '.' . $image;
                    $image_name = $imageName;
                    $imagePath = $truckpictures->move(base_path() . '/public/upload/category/original', $imageName);
                    $img = Image::make($imagePath->getRealPath());

                    $largeWidth = $width;
                    $mediumWidth = $width;
                    $smallWidth = $width;
                    $extralargeWidth = $width;
                    $iconWidth = $width;
                    $thumbnailWidth = $width;
                    //thumbnail
                    if ($width > 200) {
                        $thumbnailWidth = 200;
                    }
                    Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/thumbnail/' . $imageName);

                    //small
                    if ($width > 320) {
                        $smallWidth = 320;
                    }
                    Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/small/' . $imageName);

                    //medium
                    if ($width > 375) {
                        $mediumWidth = 375;
                    }
                    Image::make($imagePath)->resize($mediumWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/medium/' . $imageName);

                    //extraLarge
                    if ($width > 768) {
                        $extralargeWidth = 768;
                    }
                    Image::make($imagePath)->resize($extralargeWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/extralarge/' . $imageName);

                    //large
                    if ($width > 425) {
                        $largeWidth = 425;
                    }
                    Image::make($imagePath)->resize($largeWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/large/' . $imageName);

                    //icon
                    if ($width > 64) {
                        $iconWidth = 64;
                    }
                    Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                        $constraint->aspectRatio();
                    })->save(base_path() . '/public/upload/category/icon/' . $imageName);
            } else {

                if ($id) {

                    $getcategory = $this->category->getCategory($id);
                    if ($getcategory) {
                        $image_name = $getcategory->category_image;
                    } else {
                        $image_name= '';
                    }


                } else {
                    $image_name = '';
                }

            }
			$subcatid=$data['subcat_id'];
			if($subcatid)
			{
				$parentid=$subcatid;
			}
			else{
				$parentid=$data['parent_id'];
			}
			$userInput = array(
                'id' => $id,
				'category_name' => $data['cat_name'],
                'parent_id' => $parentid,
                'category_slug' => $data['cat_name'],
                'category_desc' => $data['cat_desc'],
                'category_image' => $image_name,
            );
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $table = $this->category->saveCategory($userInput);
			
            if ($table) {
                return redirect('admin/categorylist')->with('success', 'Category updated Successfully.');
            } else {
                return redirect('admin/categorylist')->with('success', 'Category created Successfully.');
            }
    }
    public function deleteCategory($id){
        $data=$this->category->deleteCategory($id);
        return redirect('admin/categorylist')->with('success', 'Deleted Successfully.');
    }

public function citysearch(Request $request)
    {
        $search = $request->get('term');
      
        /*$result = DB::table('cities')
        ->where('state_id',21)
        ->where('city','LIKE','%'.$search.'%')
        ->skip(0)
        ->take(8)
        ->get();*/
        $result = DB::table('tbl_business')
        ->select('city_name')
        ->distinct('city_name')
        ->where('city_name','LIKE','%'.$search.'%')
        ->skip(0)
        ->take(8)
        ->get();
    $dataModified = array();
     foreach ($result as $data)
     {
       $dataModified[] = $data->city_name;
     }

    return response()->json($dataModified);
    
    } 
    
public function businesssearch(Request $request)
    {
        $search = $request->get('term');
      
        $result = DB::table('tbl_category')
        ->where('parent_id','!=',0)
        ->where('category_name','LIKE','%'.$search.'%')
        ->skip(0)
        ->take(8)
        ->get();
    $dataModified = array();
     foreach ($result as $data)
     {
       $dataModified[] = $data->category_name;
     }

    return response()->json($dataModified);
    
    } 
    public function searchlist(Request $request)
    {
        $title = "Business";
        $search = $request->get('query');
        $slug=$search;
        //echo $search;die;
        
        $getsubcatid=DB::table('tbl_category')->where('category_name',$search)->first();
        //echo"<pre>";print_r($getsubcatid);die;
        $id=$getsubcatid->id;
        //echo $id.$slug;die;
    
            $getbusinessRs=DB::table('tbl_business')->where('sub_category_id',$id)->first();
            if(empty($getbusinessRs))
            {
                //dd($getbusinessRs);
                $getca=DB::table('tbl_category')->where('id',$id)->first();
                //dd($getca->parent_id);
                $catid=$getca->parent_id;
                $categoryid=$this->encodeData($getca->id);
                $catagoryname=$getca->category_slug;
                $descbusinessRs=DB::table('tbl_business')->where('category_id',$catid)->get();
                
                $getallsub=$this->category->getAllsubcat($id);
                //dd($getallsub);
                
                $desctemp=array();
                foreach($descbusinessRs as $key=>$val)
                {
                    $desctemp[$key]=$val;
                    $businessid=$val->id;
                    $desctemp[$key]->id=$this->encodeData($businessid);
                }
                //dd($desctemp);
                
                $recentbusinessRs = DB::table('tbl_business')
                ->where('category_id',$catid)
                ->inRandomOrder()
                ->get();
                
                $temp=array();
                foreach($recentbusinessRs as $key=>$val)
                {
                    $temp[$key]=$val;
                    $catid=$val->id;
                    $temp[$key]->id=$this->encodeData($catid);
                }
                
                //dd($getbusinessRs);
                // Get current page form url e.x. &amp;page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();
 
        // Create a new Laravel collection from the array data
        $itemCollection = collect($temp);
 
        // Define how many items we want to be visible in each page
        $perPage = 10;
 
        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
 
        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);

        // set url path for generted links
        $paginatedItems->setPath($request->url());
        
            }
            elseif(isset($getbusinessRs->category_id))
            {
                
                $getcategoryRs=DB::table('tbl_business')->where('sub_category_id',$id)->first();
                $catid=$getcategoryRs->category_id;
                //dd($catid);
                $categoryid=$this->encodeData($catid);
                
                $catagorynameRs=DB::table('tbl_category')->where('id',$catid)->first();
                $catagoryname=$catagorynameRs->category_slug;
                
                $getallsub=$this->category->getAllsubcat($catid);
                //dd($getallsub);
                
                $descbusinessRs = DB::table('tbl_business')->where('category_id',$catid)->get();
                //dd($descbusinessRs);
                $desctemp=array();
                foreach($descbusinessRs as $key=>$val)
                {
                    $desctemp[$key]=$val;
                    $businessid=$val->id;
                    $desctemp[$key]->id=$this->encodeData($businessid);
                }
                //dd($desctemp);
                
                $recentbusinessRs = DB::table('tbl_business')
                ->where('category_id',$catid)
                ->inRandomOrder()
                ->get();
                
                $temp=array();
                foreach($recentbusinessRs as $key=>$val)
                {
                    $temp[$key]=$val;
                    $catid=$val->id;
                    $temp[$key]->id=$this->encodeData($catid);
                }
                
                // Get current page form url e.x. &amp;page=1
        $currentPage = LengthAwarePaginator::resolveCurrentPage();
        //dd($currentPage);
 
        // Create a new Laravel collection from the array data
        $itemCollection = collect($temp);
 
        // Define how many items we want to be visible in each page
        $perPage = 10;
 
        // Slice the collection to get the items to display in current page
        $currentPageItems = $itemCollection->slice(($currentPage * $perPage) - $perPage, $perPage)->all();
 
        // Create our paginator and pass it to the view
        $paginatedItems= new LengthAwarePaginator($currentPageItems , count($itemCollection), $perPage);

        // set url path for generted links
        $paginatedItems->setPath($request->url());
        //dd($request->url());
            }
        return view('frontend.searchlist')->with('title', $title)->with('categoryid',$categoryid)->with('catagoryname',$catagoryname)->with('getbusinessRs',$paginatedItems)->with('getallsub',$getallsub)->with('slug',$slug)->with('nearbybusinessRs',$desctemp);
    }

    public function reviewFormpost(Request $request){

        $title = "Signup";
        $input = Input::all();
       // dd($input);
        
         $data = [
			'business_id' => isset($input['business_id']) ? $input['business_id'] : '',
			'userid' => isset($input['userid']) ? $input['userid'] : '',
            'reviews' => isset($input['reviews']) ? $input['reviews'] : '',
            'rating' => isset($input['rating']) ? $input['rating'] : '0',
        ];
       

        $commentdata = array(
            'business_id' => $data['business_id'],
            'user_id' => $data['userid'],
            'comment' => $data['reviews'],
            'rating' => $data['rating'],
            'is_active' => 1,
        );
        $var  = Carbon::now('Asia/Kolkata');
        $commentdata['created_at'] = $var->toDateTimeString();
        $commentid = DB::table('tbl_reviews')->insertGetId($commentdata);
        
        //$commentRs = DB::table('tbl_reviews')->where('business_id',$data['business_id'])->orderby('created_at','desc')->get();
        
        $commentRs=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name','tbl_user.user_image','tbl_user.user_image_path')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            //->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$data['business_id'])
            ->orderby('created_at','desc')
            ->get();
        
        
        $commentCnt =DB::table('tbl_reviews')->where('business_id',$data['business_id'])->count();
        
        $max = 0;
        $reviewcnt = count($commentRs); // get the count of comments
        foreach ($commentRs as $rate => $count) { // iterate through array
        $max = $max+$count->rating;
        }
        $avgrating= $max / $reviewcnt;
        $finalAvgrating=round($avgrating, 1);

        if (!$commentRs->isEmpty()) {

            $view = View::make('frontend.commentajax', ['commentRs'=>$commentRs]);
            $formData = $view->render();
            die(json_encode(array("result" => true, "formData" => trim($formData),'reviewcnt'=>$reviewcnt,'finalAvgrating'=>$finalAvgrating)));
        } else {
            die(json_encode(array("result" => false)));

        }
        //return view('frontend.businessadmin.pages.dashboard')->with('title', $title);
    }

   public function viewCount($id, $userIP) {

    $row = DB::table('tbl_view_count')->where(['business_id'=>$id,'user_ip'=>$userIP])->first();
    //DB::table('tbl_view_count')->increment('freqency',5,['updated_at'=>'2020-01-31 05:57:03']);

   /* if($row){

        $frequency = $row->freqency + 1;
        if(Sentinel::getUser()){
            $update['user_id'] = Sentinel::getUser()->id;
            
         }
         $update['freqency'] = $frequency;
            $update['updated_at'] =date('Y-m-d h:i:s');
            DB::table('tbl_view_count')->where('id',$row->id)->update($update);

    }else { */
     
     $save = [];
     $save['business_id'] = $id;
     $save['user_ip'] = $userIP;
     if(Sentinel::getUser()){
        $save['user_id'] = Sentinel::getUser()->id;
     }
     $save['freqency'] = 1;
     $save['created_at'] = date('Y-m-d h:i:s');
     DB::table('tbl_view_count')->insert($save);
   // }


}


	
}
