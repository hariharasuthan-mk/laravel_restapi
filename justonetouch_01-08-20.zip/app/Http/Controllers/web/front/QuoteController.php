<?php

namespace App\Http\Controllers\web\front;

use App\Models\Category;
use App\Models\Business;
use App\Models\Gallary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Carbon\Carbon;

class QuoteController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
        $this->business = new Business();
        $this->gallary = new Gallary();
    }
	
	public function addquote(Request $request){

        $title = "Quotes";
        $input = Input::all();
        //dd($input);
        
         $data = [
            'businessid' => isset($input['businessid']) ? $input['businessid'] : '',
			'qname' => isset($input['qname']) ? $input['qname'] : '',
			'qmobile' => isset($input['qmobile']) ? $input['qmobile'] : '',
            'qemail' => isset($input['qemail']) ? $input['qemail'] : '',
            'qmessage' => isset($input['qmessage']) ? $input['qmessage'] : '0',
        ];
        
        $businessRs = DB::table('tbl_business')->where('id',$data['businessid'])->first();

        $quotedata = array(
            'category_id' => $businessRs->category_id,
            'sub_category_id' => $businessRs->sub_category_id,
            'business_id' => $data['businessid'],
            'quote_name' => $data['qname'],
            'quote_mobile' => $data['qmobile'],
            'quote_email' => $data['qemail'],
            'quote_message' => $data['qmessage'],
        );
        //dd($quotedata);
        $var  = Carbon::now('Asia/Kolkata');
        $quotedata['created_at'] = $var->toDateTimeString();
        $quoteid = DB::table('tbl_quotes')->insertGetId($quotedata);

        if ($quoteid) {
            die(json_encode(array("result" => true)));
        } else {
            die(json_encode(array("result" => false)));

        }
    }
	
	public function getSubcategory($id)
	{
		$states = DB::table("tbl_category")
					->where("parent_id",$id)
					->pluck("category_name","id");
		return Response::json($states);
	}

    public function postbusiness(Request $request,$id = false)
    {
        $title = "Category";
        //$loginUser=Sentinel::getUser();
        $input = Input::all();

        //echo "<pre>";print_r($input);die;
        
        $data = [
            'id' => $id,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'business_firstname' => isset($input['business_firstname']) ? $input['business_firstname'] : '',
            'business_lastname' => isset($input['business_lastname']) ? $input['business_lastname'] : '',
            'business_title' => isset($input['business_title']) ? $input['business_title'] : '',
            'business_email' => isset($input['business_email']) ? $input['business_email'] : '',
			'business_contactno' => isset($input['business_contactno']) ? $input['business_contactno'] : '',
            'business_website' => isset($input['business_website']) ? $input['business_website'] : '',
            'business_address' => isset($input['business_address']) ? $input['business_address'] : '',
            'business_tags' => isset($input['business_tags']) ? $input['business_tags'] : '',
			'business_status' => isset($input['business_status']) ? $input['business_status'] : '',
            'business_desc' => isset($input['business_desc']) ? $input['business_desc'] : '',
            'business_image' => isset($input['business_image']) ? $input['business_image'] : '',
            'business_banner' => isset($input['business_banner']) ? $input['business_banner'] : '',
            'city_id' => isset($input['city_id']) ? $input['city_id'] : '',
            'filename' => isset($input['filename']) ? $input['filename'] : '',
            'pincode' => isset($input['pincode']) ? $input['pincode'] : '',
        ];
        
		
		if ($data['business_image']) 
		{
            $truckpictures = $input['business_image'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $thumb_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/thumbnail/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/thumbnail/icon/' . $imageName);
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $thumb_image_name = $getbusiness->thumbnail_img;
                } else {
                    $thumb_image_name= '';
                }

            } else {
                $thumb_image_name = '';
            }

        }
        
        if ($data['business_banner']) 
		{
            $truckpictures = $input['business_banner'];
            $imagesize = getimagesize($truckpictures);

            $width = $imagesize[0];
            $height = $imagesize[1];
            $image = $truckpictures->getClientOriginalExtension();

            $imageName = 'image' . '-' . uniqid() . '.' . $image;
            $banner_image_name = $imageName;
            $imagePath = $truckpictures->move(base_path() . '/public/upload/business/banner/original/', $imageName);
            $img = Image::make($imagePath->getRealPath());

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $banner_image_name = $getbusiness->banner_img;
                } else {
                    $banner_image_name= '';
                }

            } else {
                $banner_image_name = '';
            }

        }
        $getallcity=DB::table('cities')->where('id',$data['city_id'])->first();
        //dd($getallcity);
        $city_name=$getallcity->city;
        
        $userInput = array(
            'id' => $id,
			'business_first_name' => $data['business_firstname'],
            'business_last_name' => $data['business_lastname'],
            'business_title' => $data['business_title'],
            'business_desc' => $data['business_desc'],
            'business_email' => $data['business_email'],
            'business_website' => $data['business_website'],
            'business_address' => $data['business_address'],
            'business_contactno' => $data['business_contactno'],
            'city_id' => $data['city_id'],
            'city_name' => $city_name,
            'pincode' => $data['pincode'],
            'lattutude' => "65",
            'longitude' => "65",
            'category_id' => $data['parent_id'],
            'sub_category_id' => $data['subcat_id'],
            'business_tag' => $data['business_tags'],
            'thumbnail_img' => $thumb_image_name,
            'banner_img' => $banner_image_name,
            //'year_of_estd' => $data['year_of_estd'],
        );
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $business_id = $this->business->saveBusiness($userInput);
            
        
        if($request->hasfile('filename'))
            {
    
                foreach($request->file('filename') as $images)
                {
                
                    if ($images) {

                        $truckpictures = $images;
        
                        $imagesize = getimagesize($truckpictures);
        
                        $width = $imagesize[0];
                        $height = $imagesize[1];
                        $image = $truckpictures->getClientOriginalExtension();
        
                        $imageName = 'image' . '-' . uniqid() . '.' . $image;
                        $gimage_name = $imageName;
                        $imagePath = $truckpictures->move(base_path() . '/public/upload/business/gallary/original', $imageName);
                        $img = Image::make($imagePath->getRealPath());
        
                        $largeWidth = $width;
                        $mediumWidth = $width;
                        $smallWidth = $width;
                        $extralargeWidth = $width;
                        $iconWidth = $width;
                        $thumbnailWidth = $width;
                        //thumbnail
                        if ($width > 200) {
                            $thumbnailWidth = 200;
                        }
                        Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/thumbnail/' . $imageName);
        
                        //small
                        if ($width > 320) {
                            $smallWidth = 320;
                        }
                        Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/small/' . $imageName);
        
                        //medium
                        if ($width > 375) {
                            $mediumWidth = 375;
                        }
        
                        //icon
                        if ($width > 64) {
                            $iconWidth = 64;
                        }
                        Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                            $constraint->aspectRatio();
                        })->save(base_path() . '/public/upload/business/gallary/icon/' . $imageName);


            } else {

                if ($id) {

                    $getbusiness = $this->gallary->getGallary($id);
                    if ($getbusiness) {
                        $gimage_name = $getbusiness->image;
                    } else {
                        $gimage_name= '';
                    }


                } else {
                    $gimage_name = '';
                }

            }
                $userInput = array(
                    'id' => $id,
                    'business_id' => $business_id,
                    'image_name' => $gimage_name,
    
                );
                if($userInput['id']){
                    $userInput['created_by']=1;
                }
                else{
                    $userInput['updated_by']=1;
                }
                $table = $this->gallary->saveGallary($userInput);
            
                }
            }
            
        $working_day= [
            'id' => $id,
            'week_days' => isset($input['week_days']) ? $input['week_days'] : '',
            'starttime' => isset($input['starttime']) ? $input['starttime'] : '',
            'endtime' => isset($input['endtime']) ? $input['endtime'] : '',
        ];
        
        $insert = [];
        for ($i=0; $i <count($working_day['week_days']) ; $i++)
        {
            $draw = [
                'week_day' => $working_day['week_days'][$i],
                'week_start_time' => $working_day['starttime'][$i],
                'week_end_time' => $working_day['endtime'][$i],
                'business_id' => $business_id,
            ];
            if(!empty($draw['week_day']))
            {
            $insert[] = $draw;
            }
        }
        $saveworking = DB::table('tbl_workingday')->insert($insert);
        
        
            if ($saveworking) {
                return redirect('admin/businesslist')->with('success', 'Business updated Successfully.');
            } else {
                return redirect('admin/businesslist')->with('success', 'Business created Successfully.');
            }
    }
    public function deleteBusiness($id){
        $data=$this->business->deleteBusiness($id);
        return redirect('admin/businesslist')->with('success', 'Deleted Successfully.');
    }
}
