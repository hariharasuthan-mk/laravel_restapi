<?php

namespace App\Http\Controllers\web\front;

use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use DB;
use Response;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redirect;
use App\Helpers\Common;
use Illuminate\Pagination\LengthAwarePaginator;
use Carbon\Carbon;
use Illuminate\Support\Facades\View;

class PageviewController extends Controller
{
    public function __Construct()
    {
        $this->category = new Category();
    }

    public static function createLog($page_owner_id) {
    $browser = new BrowserDetection(); //just a function i wrote
    // special values
    $address = getRealIp(); //just a function i wrote
    $browser = $browser->getName()." ver-".$browser->getVersion();
    $url = Request::url();
    $session_id = Request::getSession()->getId();
    $log_exists = (new PageViewCount)->where([['page_id', '=', $page_owner_id], ['session_id', '=', $session_id], ['url', '=', $url]])->exists();
        if (!$log_exists) {
            $pageViewCount = new DiaryViewCount();
            $pageViewCount->url = $url;
            $pageViewCount->session_id = $session_id;
            $pageViewCount->diary_id = $page_owner_id;
            $pageViewCount->address = $address;
            $pageViewCount->browser = $browser;
            $pageViewCount->save();
        }
}
    
	
	
    
	
}
