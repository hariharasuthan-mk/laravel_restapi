<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

use App\Models\Business;
use App\Models\Users;
use Carbon\Carbon;
use DB;
use JsonMapper;
use Response;
use Validator;
use Crypt;
use App\Helpers\Common;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

class BusinessController extends Controller
{
    public function __construct()
    {
        
        $this->business = new Business();
        $this->users = new Users();
    }

    public function getbusinesslist(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
        $input=Input::all();
        $data=[
            'limit'=>isset($input['limit'])?$input['limit']:"",
            'offset'=>isset($input['offset'])?$input['offset']:"",
            'lat'=>isset($input['lat'])?$input['lat']:"",
            'lng'=>isset($input['lng'])?$input['lng']:"",
            'subcategory_id'=>isset($input['subcategory_id'])?$input['subcategory_id']:"",
        ];
        $businessRs = $this->business->getsubcategoryBusiness($data);
        /*$temp=array();
        foreach ($businessRs as $key=>$value){
            $temp[$key]=$value;
            $temp[$key]->thumb_path= asset("public/upload/business/thumbnail/original");
            $temp[$key]->thumb_icon_path= asset("public/upload/business/thumbnail/icon");
            $temp[$key]->banner_path= asset("public/upload/business/banner/original");
            $temp[$key]->banner_icon_path= asset("public/upload/business/banner/icon");
        }*/
        
        
        $temp = [];
      foreach($businessRs as $key=>$value){
            $temp[$key]=$value;
            
            $temp[$key]->thumb_path= asset("public/upload/business/thumbnail/original");
            $temp[$key]->thumb_icon_path= asset("public/upload/business/thumbnail/icon");
            $temp[$key]->banner_path= asset("public/upload/business/banner/original");
            $temp[$key]->banner_icon_path= asset("public/upload/business/banner/icon");
            
            $catid=$value->id;
            $getReview = DB::table('tbl_reviews')->where('business_id',$value->id)->avg('rating');    
        // $temp[$key]->view_count = DB::table('tbl_view_count')->where('business_id',$val->id)->sum('freqency');  
            $temp[$key]->view_count = 23;
            $temp[$key]->idddd = $value->id;      
                //$temp[$key]->id=Common::encodeData($catid);
                $temp[$key]->id=$catid;
            if($getReview) {
                $temp[$key]->review = round($getReview,1);
            }else {
                $temp[$key]->review = 0;
            }
           // $distInDegree = rad2deg(acos((sin(deg2rad($latitudeFrom))* sin(deg2rad($value->lattutude))) +
                                 //   (cos(deg2rad($latitudeFrom))*cos(deg2rad($value->lattutude))*cos(deg2rad($longitudeFrom - $value->longitude)))));
           // $distance = $distInDegree * 111.13384;  // 1 degree = 111.13384 km                        
           // $temp[$key]->distance = $distance;
         
      }

  $temp = array_sort($temp, 'distance', SORT_ASC);
  
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
        
    }
    
    public function getbusiness(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
        $input=Input::all();
        $data=[
            'business_id'=>isset($input['business_id'])?$input['business_id']:"",
        ];
        $businessRs = $this->business->getBusinessnew($data);
        //echo "<pre>";print_r($businessRs);die;
        $temp=array();
        foreach ($businessRs as $key=>$value){
            $temp[$key]=$value;
            $businessid=$value->id;
            $temp[$key]->thumb_path= asset("public/upload/business/thumbnail/original");
            $temp[$key]->thumb_icon_path= asset("public/upload/business/thumbnail/icon");
            $temp[$key]->banner_path= asset("public/upload/business/banner/original");
            $temp[$key]->banner_icon_path= asset("public/upload/business/banner/icon");
            $temp[$key]->wokingday=$this->business->getworkingDay($businessid);
            $temp[$key]->gallerylist=$this->business->getgallery($businessid);
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
    }
    public function getcity(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        
        $cityRs =DB::table('cities')->get();
        if ($cityRs) {
            return Response::json([
                'status' => 1,
                'data'   => $cityRs,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        
    }
    
    public function addbusiness(Request $request,$id = false)
    {
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
            
        $loginId = $tokenChecking[0];
        $input = Input::all();

        //echo "<pre>";print_r($input);die;
        
        $data = [
            'id' => $id,
			'parent_id' => isset($input['parent_id']) ? $input['parent_id'] : '',
			'subcat_id' => isset($input['subcat_id']) ? $input['subcat_id'] : '',
            'business_firstname' => isset($input['business_firstname']) ? $input['business_firstname'] : '',
            'business_lastname' => isset($input['business_lastname']) ? $input['business_lastname'] : '',
            'business_title' => isset($input['business_title']) ? $input['business_title'] : '',
            'business_email' => isset($input['business_email']) ? $input['business_email'] : '',
			'business_contactno' => isset($input['business_contactno']) ? $input['business_contactno'] : '',
            'business_website' => isset($input['business_website']) ? $input['business_website'] : '',
            'business_address' => isset($input['business_address']) ? $input['business_address'] : '',
            'business_tags' => isset($input['business_tags']) ? $input['business_tags'] : '',
			'business_status' => isset($input['business_status']) ? $input['business_status'] : '',
            'business_desc' => isset($input['business_desc']) ? $input['business_desc'] : '',
            'business_image' => isset($input['business_image']) ? $input['business_image'] : '',
            'business_banner' => isset($input['business_banner']) ? $input['business_banner'] : '',
            'city_id' => isset($input['city_id']) ? $input['city_id'] : '',
            'filename' => isset($input['filename']) ? $input['filename'] : '',
            'pincode' => isset($input['pincode']) ? $input['pincode'] : '0',
            'timearr' => isset($input['timearr']) ? $input['timearr'] : '',
            'galleryimg' => isset($input['galleryimg']) ? $input['galleryimg'] : '',
        ];
        
        $rules = [
                'parent_id' => 'required',
                'subcat_id' => 'required',
                'business_title' => 'required',
                'business_email' => 'required',
                'business_contactno' => 'required',
                'business_address' => 'required',
                'business_tags' => 'required',
                'business_desc' => 'required',
                //'business_image' => 'required',
                //'business_banner' => 'required',
                'city_id' => 'required',
                'pincode' => 'required',
            ];
            $error = array();
            $checkValid = validator::make($data, $rules);
        if ($checkValid->fails()) {
            $checkstatus = true;
            $error = $checkValid->errors()->all();
            return Response::json([
                'status' => 0,
                'message' => $error,
            ], 400);
        }
        else
        {
		
		if ($data['business_image']) 
		{
            
            $imgsize = getimagesize($input['business_image']);
//                        print_r($imgsize);die;
            $width = $imgsize[0];
            $height = $imgsize[1];
            $imgtype = explode("/", $imgsize['mime']);
            $filetype = $imgtype[1];

            $imageName = "business" . '-' . uniqid() . '.' . $filetype;

            $truck_image = $imageName;

            $image = $this->image->imageUpload($input['image'], '/public/upload/business/thumbnail/original/', $imageName);

            $largeWidth = $width;
            $mediumWidth = $width;
            $smallWidth = $width;
            $extralargeWidth = $width;
            $iconWidth = $width;
            $thumbnailWidth = $width;

            $imagePath = $this->image->path;
            $imageType = $this->image->imageType;
            

            if ($width > 64) {
                $iconWidth = 64;
            }
//
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
           
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $thumb_image_name = $getbusiness->thumbnail_img;
                } else {
                    $thumb_image_name= '';
                }

            } else {
                $thumb_image_name = '';
            }

        }
        
        if ($data['business_banner']) 
		{
            
            $imgsize = getimagesize($input['business_banner']);
            $width = $imgsize[0];
            $height = $imgsize[1];
            $imgtype = explode("/", $imgsize['mime']);
            $filetype = $imgtype[1];

            $imageName = "business" . '-' . uniqid() . '.' . $filetype;

            $truck_image = $imageName;

            $image = $this->image->imageUpload($input['image'], '/public/upload/business/banner/original/', $imageName);

            $largeWidth = $width;
            $mediumWidth = $width;
            $smallWidth = $width;
            $extralargeWidth = $width;
            $iconWidth = $width;
            $thumbnailWidth = $width;

            $imagePath = $this->image->path;
            $imageType = $this->image->imageType;
            

            if ($width > 64) {
                $iconWidth = 64;
            }
//
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/banner/icon/' . $imageName);
        } 
        else 
        {
            if ($id) {
                
                $getbusiness = $this->business->getBusiness($id);
                if ($getbusiness) {
                    $banner_image_name = $getbusiness->banner_img;
                } else {
                    $banner_image_name= '';
                }

            } else {
                $banner_image_name = '';
            }

        }
        $getallcity=DB::table('cities')->where('id',$data['city_id'])->first();
        //dd($getallcity);
        if($getallcity)
        {
        $city_name=$getallcity->city;
        }
        else
        {
            $city_name="";
        }
        
        $userInput = array(
            'id' => $id,
            'user_id' =>$loginId,
			'business_first_name' => $data['business_firstname'],
            'business_last_name' => $data['business_lastname'],
            'business_title' => $data['business_title'],
            'business_desc' => $data['business_desc'],
            'business_email' => $data['business_email'],
            'business_website' => $data['business_website'],
            'business_address' => $data['business_address'],
            'business_contactno' => $data['business_contactno'],
            'city_id' => $data['city_id'],
            'city_name' => $city_name,
            'pincode' => $data['pincode'],
            'lattutude' => "65",
            'longitude' => "65",
            'category_id' => $data['parent_id'],
            'sub_category_id' => $data['subcat_id'],
            'business_tag' => $data['business_tags'],
            'thumbnail_img' => $thumb_image_name,
            'banner_img' => $banner_image_name,
            //'year_of_estd' => $data['year_of_estd'],
        );
			//echo "<pre>";print_r($userInput);die;
            if($userInput['id']){
                $userInput['updated_by']=1;
            }
            else{
                $userInput['created_by']=1;
            }
            $business_id = $this->business->saveBusiness($userInput);
            
        
         if($data['galleryimg'])   
            {
    
                foreach($data['galleryimg'] as $images)
                {
                
                    if ($images['filename']) {
                        
                        $imgsize = getimagesize($images['filename']);
            $width = $imgsize[0];
            $height = $imgsize[1];
            $imgtype = explode("/", $imgsize['mime']);
            $filetype = $imgtype[1];

            $imageName = "image" . '-' . uniqid() . '.' . $filetype;

            $truck_image = $imageName;

            $image = $this->image->imageUpload($images['filename'], '/public/upload/business/gallary/original/', $imageName);

            $largeWidth = $width;
            $mediumWidth = $width;
            $smallWidth = $width;
            $extralargeWidth = $width;
            $iconWidth = $width;
            $thumbnailWidth = $width;

            $imagePath = $this->image->path;
            $imageType = $this->image->imageType;
            
            //thumbnail
            if ($width > 200) {
                $thumbnailWidth = 200;
            }
            Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/gallary/thumbnail/' . $imageName);

            //small
            if ($width > 320) {
                $smallWidth = 320;
            }
            Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/gallary/small/' . $imageName);

            //medium
            if ($width > 375) {
                $mediumWidth = 375;
            }

            //icon
            if ($width > 64) {
                $iconWidth = 64;
            }
            Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                $constraint->aspectRatio();
            })->save(base_path() . '/public/upload/business/gallary/icon/' . $imageName);



            } else {

                if ($id) {

                    $getbusiness = $this->gallary->getGallary($id);
                    if ($getbusiness) {
                        $gimage_name = $getbusiness->image;
                    } else {
                        $gimage_name= '';
                    }


                } else {
                    $gimage_name = '';
                }

            }
                $userInput = array(
                    'id' => $id,
                    'business_id' => $business_id,
                    'image_name' => $gimage_name,
    
                );
                if($userInput['id']){
                    $userInput['created_by']=$loginId;
                }
                else{
                    $userInput['updated_by']=$loginId;
                }
                $table = $this->gallary->saveGallary($userInput);
            
                }
            }
        
        if($data['timearr'])   
        {
            $weekdaycnt=count($data['timearr']);
            //print_r($data['timearr']);die;
            $insert = [];
            for ($i=0; $i <$weekdaycnt; $i++)
            {
                $draw = [
                    'week_day' => $data['timearr'][$i]['week_days'],
                    'week_start_time' => $data['timearr'][$i]['starttime'],
                    'week_end_time' => $data['timearr'][$i]['endtime'],
                    'business_id' => $business_id,
                ];
                if(!empty($draw['week_day']))
                {
                $insert[] = $draw;
                }
            }
            $saveworking = DB::table('tbl_workingday')->insert($insert);
        }
        
            if ($business_id) {
                        return Response::json([
                            'status' => 1,
                            'message' => 'Business has been posted successfully',
                        ], 200);
                    }
                    return Response::json([
                        'status' => 0,
                        'message' => 'Please try again.'
                    ], 400);
                    
        }

        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
    }
    
}
