<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

use App\Models\Review;
use App\Models\Users;
use Carbon\Carbon;
use DB;
use JsonMapper;
use Response;
use Validator;
use Crypt;
use Helper;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

class ReviewController extends Controller
{
    public function __construct()
    {
        
        $this->review = new Review();
        $this->users = new Users();
    }

    public function getreviewlist(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
         $input=Input::all();
        $reviewRs=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name','tbl_user.user_image','tbl_user.user_image_path')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            //->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$input['business_id'])
            ->orderby('created_at','desc')
            ->get();
        $temp=array();
        foreach ($reviewRs as $key=>$value){
            $temp[$key]=$value;
            $temp[$key]->user_image_path= asset("public/upload/user/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
        
    }
   
    public function addreview(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $input = $request->json()->all();
        $chektoken = $this->users->checkToken($token);
        if ($chektoken[0] != 0) {
            $userId = $chektoken[0];
            $emailId = $chektoken[1];
            $uuid = $chektoken[2];

            $data = [
                'business_id' => isset($input['business_id']) ? $input['business_id'] : "",
                //'user_id' => isset($input['user_id']) ? $input['user_id'] : "",
                'rating' => isset($input['rating']) ? $input['rating'] : "",
                'comment' => isset($input['comment']) ? $input['comment'] : "",
            ];

            $rules = [
                'comment' => 'required',
            ];
            $error = array();
            $checkstatus = false;
            if ($request->isMethod('post')) {

                $checkValid = validator::make($data, $rules);
                if ($checkValid->fails()) {
                    $checkstatus = true;
                    $error = $checkValid->errors()->all();
                }
                if ($checkstatus) {
                    return Response::json([
                        'status' => 0,
                        'message' => $error,
                    ], 400);

                } else {

                
                    $userInput = [
                        'id' => false,
                        'business_id' => $data['business_id'],
                        'user_id' => $userId,
                        'rating' => $data['rating'],
                        'comment' => $data['comment'],

                    ];

                    $result = $this->review->saveReview($userInput);
                    
                    $reviewRs=DB::table('tbl_reviews')
            ->select('tbl_reviews.id as reviewid','tbl_reviews.business_id','tbl_reviews.user_id','tbl_reviews.rating','tbl_reviews.comment','tbl_reviews.approved','tbl_reviews.created_at','tbl_reviews.is_active','tbl_user.first_name','tbl_user.user_image','tbl_user.user_image_path')
            ->join('tbl_user','tbl_user.id','tbl_reviews.user_id')
            ->join('tbl_business','tbl_business.id','tbl_reviews.business_id')
            ->where('tbl_reviews.business_id',$data['business_id'])
            ->where('tbl_reviews.user_id',$userId)
            ->orderby('created_at','desc')
            ->get();

                    if ($result) {
                        return Response::json([
                            'status' => 1,
                            'reviewRs' => $reviewRs,
                            'message' => 'Review has been posted successfully',
                        ], 200);
                    }
                    return Response::json([
                        'status' => 0,
                        'message' => 'Please try again.'
                    ], 400);

                }
            }
        } else {
            return Response()->json([
                'status' => 0,
                'message' => 'Your session is expired pls login'
            ], 401);
        }
    }
}
