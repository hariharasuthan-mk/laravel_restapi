<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

use App\Models\Category;
use App\Models\Users;
use Carbon\Carbon;
use DB;
use JsonMapper;
use Response;
use Validator;
use Crypt;
use Helper;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

class CategoryController extends Controller
{
    public function __construct()
    {
        $this->category = new Category();
        $this->users = new Users();
    }

	public function getcategory(Request $request){
	    
	    header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $input = $request->json()->all();
        $tokenChecking = $this->users->checkToken($token);
        //echo "<pre>";print_r($tokenChecking);die;
        if ($tokenChecking[0] != 0) {
            
        $data=[
            'limit'=>isset($input['limit'])?$input['limit']:"",
            'offset'=>isset($input['offset'])?$input['offset']:"",
            //'type'=>isset($input['type'])?$input['type']:"",
        ];
            
         $categoryRs = $this->category->getAllCategory($data);
         //echo "<pre>";print_r($categoryRs);die;
        $temp=array();
        foreach ($categoryRs as $key=>$value){
            $temp[$key]=$value;
            //$temp[$key]->image_path= asset("public/upload/category/appicon");
            $temp[$key]->image_path= asset("public/upload/category/original");
        }
            if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200); 
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
    }
    
    public function getsubcategory(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        //echo "<pre>";print_r($tokenChecking);die;
        if ($tokenChecking[0] != 0) {
        $input=Input::all();
        $data=[
            'limit'=>isset($input['limit'])?$input['limit']:"",
            'offset'=>isset($input['offset'])?$input['offset']:"",
            'category_id'=>isset($input['category_id'])?$input['category_id']:"",
        ];
            
        $categoryRs = $this->category->getAllsubcategory($data);
        $temp=array();
        foreach ($categoryRs as $key=>$value){
            $temp[$key]=$value;
            //$temp[$key]->image_path= asset("public/upload/category/appicon");
            $temp[$key]->image_path= asset("public/upload/category/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
       
    }
}
