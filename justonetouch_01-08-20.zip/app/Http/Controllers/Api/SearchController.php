<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;

use App\Models\Business;
use App\Models\Users;
use Carbon\Carbon;
use DB;
use JsonMapper;
use Response;
use Validator;
use Crypt;
use Helper;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

class SearchController extends Controller
{
    public function __construct()
    {
        $this->business = new Business();
        $this->users = new Users();
    }

    public function search(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
        $input=Input::all();
         $data = [
                'limit' => isset($input['limit']) ? $input['limit'] : "",
                'offset' => isset($input['offset']) ? $input['offset'] : "",
                'keyword'=>isset($input['keyword']) ? $input['keyword'] : "",
            ];
        $search=$data['keyword']; 
        $offset=$data['offset']; 
        $limit=$data['limit']; 
        $categoryRs = DB::select( DB::raw("SELECT *  FROM tbl_category WHERE parent_id !=0 and category_name LIKE '%$search%'  LIMIT $limit OFFSET $offset") );
        $businessRs = DB::select( DB::raw("SELECT *  FROM tbl_business WHERE business_title LIKE '%$search%'  LIMIT $limit OFFSET $offset") );
        
        return Response::json([
                'status' => 1,
                'categoryRs'   => $categoryRs,
                'businessRs'   => $businessRs,
            ], 200);} else {
            return Response::json([
                'status'  => 1,
                'message' => ' Not found',
            ], 200);
        }
        
    }
}
    
    
