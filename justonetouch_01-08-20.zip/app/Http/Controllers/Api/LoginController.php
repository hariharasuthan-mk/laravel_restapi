<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ImageResizer;
use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Intervention\Image\Facades\Image;
use Response;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use App\Helpers;
use DB;

class LoginController extends Controller
{

    public function __construct()
    {
        $this->users = new Users();
        //$this->image = new ImageResizer();
    }


    public function sendSMS(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $input = $request->json()->all();
        
            $data = [
                //'name' => isset($input['name']) ? $input['name'] : "",
                'mobile' => isset($input['mobile']) ? $input['mobile'] : "",
            ];

            $rules = array(
                'mobile' => 'required',
            );
            $checkValid = Validator::make($input, $rules);

            if ($checkValid->fails()) {
                return Response::json([
                    'status' => 0,
                    'message' => $checkValid->errors()->all()
                ], 200);
            }
            else{
                $otp = rand(1000, 9999);
                $message = "Just One Touch -" . $otp . " is your verification code";
                
                //$name=$data['name'];
                $mobile_number=$data['mobile'];
                $mobil=$this->phone_number_format($mobile_number);
                $userRs=DB::table('tbl_user')->where('mobile_no',$mobil)->first();
                //dd($userRs);
                if(empty($userRs))
                {
                    $userInput=[
                        'id' => false,
                        'uuid' => uniqid(),
                        //'first_name'=>$name,
                        'mobile_no'=>$mobil,
                        'otp'=>$otp
                    ];
                    //echo "<pre>";print_r($userInput);die;
                    $saveUser = $this->users->saveUser($userInput);
                     if($saveUser){
                         
                $curl = curl_init();
    
             
curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://obligr.io/api_v2/tfa/send", 
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => "sender_id=JSTONE&message=$message&mobile_no=$mobile_number",
                        CURLOPT_HTTPHEADER => array(
                        "authorization: Bearer 9Dk2P0qZsn-8nMSyiKPsZ23VsCNBf_RxxeCDuoqC6NBXbaD4eGPUWgKZW64f3wPY",
                        "cache-control: no-cache",
                        "content-type: application/x-www-form-urlencoded"
                        ),
                    ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } 
            else {
              //echo $response;die;
              $output=$response;
            }
            if ($output) {
                    return Response::json([
                        'status' => 1,
                        'otp' => $otp,
                    ], 200);
                } else {
                    return Response::json([
                        'status' => 0,
                        'message' => 'Please try again.'
                    ], 200);
                }        
                    
                    
                }
                
            }
            else{
                
                
                $userInput=[
                        'id' => $userRs->id,
                        'uuid' => uniqid(),
                        //'first_name'=>$name,
                        'mobile_no'=>$mobil,
                        'otp'=>$otp
                    ];
                    //echo "<pre>";print_r($userInput);die;
                    $saveUser = $this->users->saveUser($userInput);
                     if($saveUser){
                $curl = curl_init();
    
             
curl_setopt_array($curl, array(
                        CURLOPT_URL => "https://obligr.io/api_v2/tfa/send", 
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => "",
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 30,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => "POST",
                        CURLOPT_POSTFIELDS => "sender_id=JSTONE&message=$message&mobile_no=$mobile_number",
                        CURLOPT_HTTPHEADER => array(
                        "authorization: Bearer 9Dk2P0qZsn-8nMSyiKPsZ23VsCNBf_RxxeCDuoqC6NBXbaD4eGPUWgKZW64f3wPY",
                        "cache-control: no-cache",
                        "content-type: application/x-www-form-urlencoded"
                        ),
                    ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } 
            else {
              //echo $response;die;
              $output=$response;
            }
            if ($output) {
                    return Response::json([
                        'status' => 1,
                        'otp' => $otp,
                    ], 200);
                } else {
                    return Response::json([
                        'status' => 0,
                        'message' => 'Please try again.'
                    ], 200);
                }        
                    
                    
                }
                
                
                
                /*
                if(empty($userRs->password))
                {
                $otp = rand(1000, 9999);
                $message = "Just One Touch -" . $otp . " is your verification code";
                $userInput=[
                        'id' => $userRs->id,
                        'mobile_no'=>$mobil,
                        'otp'=>$otp
                ];
                    //echo "<pre>";print_r($userInput);die;
                    $saveUser = $this->users->saveUser($userInput);
                    
                $curl = curl_init();
    
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://obligr.io/api_v2/message/send",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => "sender_id=JSTONE&message=$message&mobile_no=$mobile_number",
              CURLOPT_HTTPHEADER => array(
                "authorization: Bearer pehbyNg-QOJeZTIN_nFPRTkjuqUsE8pFNj-GOWS5OelCaFglW-pz9eaJaqmDc2l1",
                "cache-control: no-cache",
                "content-type: application/x-www-form-urlencoded"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } 
            else {
              //echo $response;die;
              $output=$response;
            }
            return Response::json([
                        'status' => 1,
                        'otp' => $otp,
                    ], 200);
                    
                }
                else
                {
                    return Response::json([
                    'status' => 0,
                    'message' => 'Already Registered'
                ], 200);
                
                }*/
            }
        }
    }
    
    public function phone_number_format($number) {
        $number = preg_replace("/[^\d]/","",$number);
          // get number length.
          $length = strlen($number);
         // if number = 10
        if($length == 10) {
            $number = preg_replace("/^1?(\d{3})(\d{3})(\d{4})$/", "$1$2$3", $number);
        }
        return $number;
    }
    
    public function verifyotp(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $input = $request->json()->all();
        //echo "<pre>";print_r($input);die;
         if (!$input) {
            return Response::json([
                'status' => 0,
                'message' => "Please provide valid data"
            ], 200);
        }
        $data = [
            'mobileno' => isset($input['mobileno']) ? $input['mobileno'] : '',
            'otp' => isset($input['otp']) ? $input['otp'] : '',
            ];
        $saveuser =$this->users->getUserByMobile($data['mobileno']);
//dd($saveuser);
        //if($checkOtp->otp!=$data['otp']){
        if($saveuser->otp==$data['otp']){
            $token = Helpers\Common::encodeData($saveuser->id . 'token' . $saveuser->mobile_no . 'token' . $saveuser->uuid);
            //echo "<pre>";print_r($token);die;
             $updateToken = [
                'id' => $saveuser->id,
                'user_token' => $token,
                'is_active' => 1,
                'updated_at' => Carbon::now()->toDateTimeString(),
            ];
            $UpdateUser = $this->users->saveUser($updateToken); 
            $getUser = DB::table('tbl_user')->where('id',$saveuser->id)->first();
            if($UpdateUser)
            {
                return Response::json([
                            'status' => 1,
                            'token' => $token,
                            'userRs' => $getUser,
                        ], 200);
            }
            else
            {
                return Response::json([
                            'status' => 0,
                            'message' => "Somthing went wrong please try again"
                ], 400);
            }
        }
        else
        {
            return Response::json([
                'status'=>0,
                'message'=>'invalid otp.pls provide valid otp'
            ],200);
        }
        
        
    }
    public function postnameimage(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
            
        $userId = $tokenChecking[0];
        
        $input =Input::all();
        //dd($input);
        $data = [
            'firstname' => isset($input['firstname']) ? $input['firstname'] : "",
            'profile_image' => isset($input['profile_image']) ? $input['profile_image'] : "",
        ];

        $rules = [
            "firstname" => "required",
        ];
        $error = array();
        $checkStatus = false;

            $checkValid = Validator::make($data, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
            if ($checkStatus) {
                return Response::json([
                        'status' => 0,
                        'message' => $error,
                    ], 200);
            }
            
            else
            {
                
                $input =Input::all();

            if ($data['profile_image']) {

                 $truckpictures = $input['profile_image'];


                $imagesize = getimagesize($truckpictures);

                $width = $imagesize[0];
                $height = $imagesize[1];
                $image = $truckpictures->getClientOriginalExtension();

                $imageName = 'user' . '-' . uniqid() . '.' . $image;
                $image_name = $imageName;
                $imagePath = $truckpictures->move(base_path() . '/public/upload/user/original', $imageName);
                $img = Image::make($imagePath->getRealPath());

                $largeWidth = $width;
                $mediumWidth = $width;
                $smallWidth = $width;
                $extralargeWidth = $width;
                $iconWidth = $width;
                $thumbnailWidth = $width;

//thumbnail
                if ($width > 200) {
                    $thumbnailWidth = 200;
                }
                Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/thumbnail/' . $imageName);

                //small
                if ($width > 320) {
                    $smallWidth = 320;
                }
                Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/small/' . $imageName);

                //medium
                if ($width > 375) {
                    $mediumWidth = 375;
                }
                Image::make($imagePath)->resize($mediumWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/medium/' . $imageName);

                //extraLarge
                if ($width > 768) {
                    $extralargeWidth = 768;
                }
                Image::make($imagePath)->resize($extralargeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/extralarge/' . $imageName);

                //large
                if ($width > 425) {
                    $largeWidth = 425;
                }
                Image::make($imagePath)->resize($largeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/large/' . $imageName);

                //icon
                if ($width > 64) {
                    $iconWidth = 64;
                }
                Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/icon/' . $imageName);


            } else {

                $getUser = DB::table('tbl_user')->where('id',$userId)->first();
                //dd($getUser);
                if ($getUser) {
                    $imageName = $getUser->user_image;
                } else {
                    $imageName = '';
                }

            }
            $imagepath=url('/')."/public/upload/user/original/";
            $var  = Carbon::now('Asia/Kolkata');
            $userInput = [
                'id' => $userId,
                'first_name' => $data['firstname'],
                'user_image' => $imageName,
                'user_image_path' => $imagepath,
                'modified_by' => $userId,
                'updated_at' => $var->toDateTimeString(),
            ];
           // dd($userInput);
            $update = Sentinel::update($userId, $userInput);
            //dd($update);
            $getUser = DB::table('tbl_user')->where('id',$userId)->first();
            if ($update) {
                 return Response::json([
                            'status' => 1,
                            'userRs' => $getUser,
                            'message' => 'Profile has been Updated successfully',
                        ], 200);
            }
                
            }

            
            
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }

        
    }
    public function postpassword(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $input = $request->json()->all();
        //echo "<pre>";print_r($input);die;
         if (!$input) {
            return Response::json([
                'status' => 0,
                'message' => "Please provide valid data"
            ], 200);
        }
    
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
            
         $data = [
            'password' => isset($input['password']) ? $input['password'] : '',
            ];
            
            $userId = $tokenChecking[0];
            $mobileno = $tokenChecking[1];
            $uuid = $tokenChecking[2];
            $updatePassword = [
                'id' => $userId,
                'password' => $data['password'],
                'password_str' => $data['password'],
                'updated_at' => Carbon::now()->toDateTimeString(),
            ];

            $UpdateUser = Sentinel::update($updatePassword['id'], $updatePassword);
            if($UpdateUser)
            {
                return Response::json([
                            'status' => 1,
                        ], 200);
            }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
        
    }
    public function verifylogin(Request $request)
    {
        header('Access-Control-Allow-Origin:*');
        $input = $request->all();
        // echo "<pre>";print_r("yes");die;
        //echo "<pre>";print_r($input);die;
        if ($input) {
            $data = [
                'mobile_no' => isset($input['mobile_no']) ? $input['mobile_no'] : "",
                'password' => isset($input['password']) ? $input['password'] : "",
            ];

            $rules = [
                "mobile_no" => "required|digits:10",
                "password" => "required",
            ];
            $error = array();
            $checkStatus = false;

                $checkValid = Validator::make($data, $rules);
                if ($checkValid->fails()) {
                    $checkStatus = true;
                    $error = $checkValid->errors()->all();
                }
                if ($checkStatus) {
                    return Response::json([
                        'status' => 0,
                        'message' => $error,
                    ], 200);
                } else {
                    $input = Input::all();
                    $remember = (bool)Input::get('remember', false);

                    //if ($user = $this->users->getUserByMobile($data['mobile_no'])) {
                            $user = DB::table('tbl_user')->where('mobile_no',$data['mobile_no'])->first();
                            if($user)
                            {
                                if ($user->password_str != $data['password']) {
                                return Response::json([
                                    'status' => 0,
                                    'message' => "Invalid  password"
                                ], 200);
                                }
                                //echo "<pre>";print_r($user);die;
                                $token = Helpers\Common::encodeData($user->id . 'token' . $user->mobile_no . 'token' . $user->uuid);
                                $updateToken = [
                                    'id' => $user->id,
                                    'user_token' => $token,
                                ];

                                $savetoken = Sentinel::update($updateToken['id'], $updateToken);
                                if ($savetoken) {
                                    $userlist = array();
                                    $userlist = $this->users->getUserById($savetoken->id);
                                    //echo "<pre>";print_r($userlist);die;
                                    return Response::json([
                                        'status' => 1,
                                        'user' => $userlist,
                                    ], 200);
                                } else {
                                    return Response::json([
                                        'status' => 0,
                                        'message' => "Login Failed"
                                    ], 200);
                                }

                            }else{
                                return Response::json([
                                    'status' => 0,
                                    'message' => "Invalid User"
                                ], 200);
                            }
                   
            }
        }
}
public function profileupdate(Request $request)
    {
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
            
        $userId = $tokenChecking[0];
        
        $input =Input::all();
        //dd($input);
        $data = [
            'firstname' => isset($input['firstname']) ? $input['firstname'] : "",
            //'password' => isset($input['password']) ? $input['password'] : "",
            //'confirmpass' => isset($input['confirmpass']) ? $input['confirmpass'] : "",
            'email' => isset($input['email']) ? $input['email'] : "",
            'profile_image' => isset($input['profile_image']) ? $input['profile_image'] : "",
            'mobile' => isset($input['mobile']) ? $input['mobile'] : "",
            'address' => isset($input['address']) ? $input['address'] : "",
            //'status' => isset($input['status']) ? $input['status'] : "",
        ];

//            echo "<pre>";print_r($data);die;
        $rules = [
            "firstname" => "required",
            //"email" => "required|email",
            "mobile" => "required|digits:10"
        ];
        $error = array();
        $checkStatus = false;

            $checkValid = Validator::make($data, $rules);
            if ($checkValid->fails()) {
                $checkStatus = true;
                $error = $checkValid->errors()->all();
            }
            if ($checkStatus) {
                return Response::json([
                        'status' => 0,
                        'message' => $error,
                    ], 200);
            }
            
            else
            {
                
                $input =Input::all();

            if ($data['profile_image']) {

                 $truckpictures = $input['profile_image'];


                $imagesize = getimagesize($truckpictures);

                $width = $imagesize[0];
                $height = $imagesize[1];
                $image = $truckpictures->getClientOriginalExtension();

                $imageName = 'user' . '-' . uniqid() . '.' . $image;
                $image_name = $imageName;
                $imagePath = $truckpictures->move(base_path() . '/public/upload/user/original', $imageName);
                $img = Image::make($imagePath->getRealPath());

                $largeWidth = $width;
                $mediumWidth = $width;
                $smallWidth = $width;
                $extralargeWidth = $width;
                $iconWidth = $width;
                $thumbnailWidth = $width;

//thumbnail
                if ($width > 200) {
                    $thumbnailWidth = 200;
                }
                Image::make($imagePath)->resize($thumbnailWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/thumbnail/' . $imageName);

                //small
                if ($width > 320) {
                    $smallWidth = 320;
                }
                Image::make($imagePath)->resize($smallWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/small/' . $imageName);

                //medium
                if ($width > 375) {
                    $mediumWidth = 375;
                }
                Image::make($imagePath)->resize($mediumWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/medium/' . $imageName);

                //extraLarge
                if ($width > 768) {
                    $extralargeWidth = 768;
                }
                Image::make($imagePath)->resize($extralargeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/extralarge/' . $imageName);

                //large
                if ($width > 425) {
                    $largeWidth = 425;
                }
                Image::make($imagePath)->resize($largeWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/large/' . $imageName);

                //icon
                if ($width > 64) {
                    $iconWidth = 64;
                }
                Image::make($imagePath)->resize($iconWidth, null, function ($constraint) use ($imageName) {
                    $constraint->aspectRatio();
                })->save(base_path() . '/public/upload/user/icon/' . $imageName);


            } else {

                $getUser = DB::table('tbl_user')->where('id',$userId)->first();
                //dd($getUser);
                if ($getUser) {
                    $imageName = $getUser->user_image;
                } else {
                    $imageName = '';
                }

            }
            $imagepath=url('/')."/public/upload/user/original/";
            $var  = Carbon::now('Asia/Kolkata');
            $userInput = [
                'id' => $userId,
                'first_name' => $data['firstname'],
                //'password' => $data['password'],
                //'password_str' => $data['confirmpass'],
                'email' => $data['email'],
                'user_image' => $imageName,
                'user_image_path' => $imagepath,
                'mobile' => $data['mobile'],
                'address' => $data['address'],
                'modified_by' => $userId,
                //'profile_status'=>1,
                'updated_at' => $var->toDateTimeString(),
            ];
           // dd($userInput);
            $update = Sentinel::update($userId, $userInput);
            //dd($update);
            $getUser = DB::table('tbl_user')->where('id',$userId)->first();
            if ($update) {
                 return Response::json([
                            'status' => 1,
                            'userRs' => $getUser,
                            'message' => 'Profile has been Updated successfully',
                        ], 200);
            }
                
            }

            
            
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }

    }
    
    public function getuser(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $token = app('request')->header('token');
        $tokenChecking = $this->users->checkToken($token);
        if ($tokenChecking[0] != 0) {
        $input=Input::all();
        $loginId = $tokenChecking[0];
        $userRs = $this->users->getUserById($loginId);
        //dd($userRs);
        $temp=array();
        foreach ($userRs as $key=>$value){
            $temp[$key]=$value;
            //$temp[$key]->imagepath = public_path("upload/user/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        } 
        else 
        {
            return Response::json([
                'status' => 0,
                'message' => 'Invalid User',
            ], 200);
        }
        
    }
    

}


