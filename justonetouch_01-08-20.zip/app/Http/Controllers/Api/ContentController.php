<?php

namespace App\Http\Controllers\Api;
use App\Models\Gallary;
use App\Models\News;
use App\Models\Users;
use App\Models\Video;
use Illuminate\Http\Request;

use App\Models\Content;
use Carbon\Carbon;
use DB;
use JsonMapper;
use Response;
use Validator;
use Crypt;
use Helper;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;

class ContentController extends Controller
{
    public function __construct()
    {
        $this->gallary = new Gallary();
        $this->video = new Video();
        $this->users = new Users();
        $this->news= new News();
    }

	public function getnews(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=Input::all();
        $newsRs = $this->news->getAll();
        $temp=array();
        foreach ($newsRs as $key=>$value){
            $temp[$key]=$value;
            $temp[$key]->image_path= asset("public/upload/news/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    } 	
	
	public function getsinglenews(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $input=Input::all();
        $newsRs = $this->news->getNews($input['news_id']);
        $temp=array();
        foreach ($newsRs as $key=>$value){
            $temp[$key]=$value;
            //$temp[$key]->image_path = asset("public/upload/news/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        
    }
    

	public function getvideos(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=$request->all();
        $videoRs = $this->video->getAllVideo();
        $temp=array();
        foreach ($videoRs as $key=>$value){
            $temp[$key]=$value;
           // $temp[$key]->image_path= asset("public/images/upload/video");;
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    }
    
    public function getsinglevideos(Request $request){
        
        header('Access-Control-Allow-Origin:*');
        $input=Input::all();
        $videosRs = $this->video->getVideo($input['video_id']);
        $temp=array();
        foreach ($videosRs as $key=>$value){
            $temp[$key]=$value;
            //$temp[$key]->imagepath = asset("public/upload/news/original");
        }
        if ($temp) {
            return Response::json([
                'status' => 1,
                'data'   => $temp,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
        
    }
	public function getprivacy(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=Input::all();
        $privacyRs = DB::table('tbl_policy')->get();
        if ($privacyRs) {
            return Response::json([
                'status' => 1,
                'data'   => $privacyRs,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    }
    public function getterms(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=Input::all();
        $termsRs = DB::table('tbl_terms')->get();
        if ($termsRs) {
            return Response::json([
                'status' => 1,
                'data'   => $termsRs,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    }
    public function getabout(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=Input::all();
        $aboutRs = DB::table('tbl_about')->get();
        if ($aboutRs) {
            return Response::json([
                'status' => 1,
                'data'   => $aboutRs,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    }
    public function getwhoweare(Request $request){
        header('Access-Control-Allow-Origin: *');
        $input=Input::all();
        $whoRs = DB::table('tbl_whoweare')->get();
        if ($whoRs) {
            return Response::json([
                'status' => 1,
                'data'   => $whoRs,
            ], 200);} else {
            return Response::json([
                'status'  => 0,
                'message' => ' Not found',
            ], 200);
        }
    }
}
