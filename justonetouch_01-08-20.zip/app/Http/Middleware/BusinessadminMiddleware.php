<?php

namespace App\Http\Middleware;

use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Closure;

class BusinessadminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
       
        if(Sentinel::check() == FALSE){
           
            return redirect('/');
        }
        else{

           
            if(Sentinel::getUser()->user_group_id != 0){
                Sentinel::logout();
                return redirect('admin');
            }
            return $next($request);

        }
    }

}
