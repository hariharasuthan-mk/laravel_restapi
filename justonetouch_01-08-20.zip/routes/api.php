<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Authorization, Content-Type, Accept, Authorization, X-Request-With, token, xss-loader');
header("X-XSS-Protection: 1; mode=block");

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'v1'], function() {
    
Route::post('/sendotp', 'Api\LoginController@sendSMS');
Route::post('/verifyotp', 'Api\LoginController@verifyotp');
Route::post('/postpassword', 'Api\LoginController@postpassword');
Route::post('/verifylogin', 'Api\LoginController@verifylogin');
Route::post('/postnameimage', 'Api\LoginController@postnameimage');
Route::post('/profileupdate', 'Api\LoginController@profileupdate');
Route::get('/getuser', 'Api\LoginController@getuser');

Route::post('/getcategory', 'Api\CategoryController@getcategory');
Route::get('/getcity', 'Api\BusinessController@getcity');

Route::post('getsubcategory', [
        'uses'=>'Api\CategoryController@getsubcategory',
        'as'=>'getsubcategory'
    ]);
Route::post('getbusinesslist', [
        'uses'=>'Api\BusinessController@getbusinesslist',
        'as'=>'business'
    ]);
    
Route::post('getbusiness', [
        'uses'=>'Api\BusinessController@getbusiness',
        'as'=>'business'
    ]);
    
Route::post('/search', 'Api\SearchController@search');
// Business Add
Route::post('/addbusiness', 'Api\BusinessController@addbusiness');


//Review 
Route::post('/addreview', 'Api\ReviewController@addreview');
Route::post('/getreviewlist', 'Api\ReviewController@getreviewlist');
Route::get('/getnews', 'Api\ContentController@getnews');
Route::post('/getsinglenews', 'Api\ContentController@getsinglenews');
Route::get('/getvideos', 'Api\ContentController@getvideos');
Route::post('/getsinglevideos', 'Api\ContentController@getsinglevideos');
Route::get('/getprivacy', 'Api\ContentController@getprivacy');
Route::get('/getterms', 'Api\ContentController@getterms');
Route::get('/getabout', 'Api\ContentController@getabout');
Route::get('/getwhoweare', 'Api\ContentController@getwhoweare');
}); 


