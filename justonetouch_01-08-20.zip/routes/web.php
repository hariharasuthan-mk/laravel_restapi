<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

// Home Page
Route::get('/', 'web\front\HomeController@index');
Route::get('search/{id}/{slug}', 'web\front\HomeController@subcategorylist');
Route::get('searchlist/{id}/{slug}', 'web\front\HomeController@businesslist');
Route::get('search', 'web\front\HomeController@searchlist');

// Login

Route::post('pop-login','web\front\LoginController@popLogin');
Route::get('signup', 'web\front\LoginController@signup');
Route::post('signup', 'web\front\LoginController@postsignup');
Route::post('verifyotp', 'web\front\LoginController@verifyotp');
Route::get('signin', 'web\front\LoginController@signin');
Route::post('signin', 'web\front\LoginController@postsignin');
Route::get('/user/verify/{token}', 'web\front\LoginController@verifyUser');

Route::get('list/{id}/{slug}', 'web\front\HomeController@businessdetails');

//visitor 

Route::post('visitorinfo', 'web\front\VisitorController@visitorinfo');

Route::get("dashboard", function(){
    return view("frontend.dashboard");
});

Route::get("alllisting", function(){
    return view("frontend.all-listing");
});

Route::get("price", function(){
    return view("frontend.price");
});

Route::get('cityautocomplete', 'web\front\HomeController@citysearch');
Route::get('businessautocomplete', 'web\front\HomeController@businesssearch');

/// Front Quote 

Route::post('addquote', 'web\front\QuoteController@addquote');

Route::get('/logout', 'web\front\LoginController@logout');

Route::post('image/delete','web\businessadmin\BusinessController@deleteImage');


Route::group(['middleware' => 'businessadmin'], function () {
    
    Route::get('businessadmin', 'web\businessadmin\DashboardController@index');
    
    //Business 
    Route::get('businesslist', 'web\businessadmin\BusinessController@index');
    Route::get('businessadd', 'web\businessadmin\BusinessController@businessadd');
    Route::post('userpostbusiness', 'web\businessadmin\BusinessController@userpostbusiness');
    Route::get('businessadd/{id}','web\businessadmin\BusinessController@editbusiness');
    Route::get('businessdelete/{id}','web\businessadmin\BusinessController@delete');
    
    Route::get('preview-business/{id}','web\businessadmin\BusinessController@previewBusiness');
    
    // Frontend Review Add
    Route::get('reviewFormpost', 'web\front\HomeController@reviewFormpost');
    
    // Profile Update
    Route::post('profileupdate', 'web\businessadmin\UserController@userprofileUpdate');
    
    Route::get('reviewlist', 'web\businessadmin\BusinessController@reviewlist');
    Route::get('profileview', 'web\businessadmin\UserController@profileview');
    Route::get('profileedit/{id}', 'web\businessadmin\UserController@profileedit');
    Route::get('adsummary', 'web\businessadmin\AdsummaryController@adsummary');
    Route::get('checkout', 'web\businessadmin\PaymentController@checkout');
    Route::get('invoiceall', 'web\businessadmin\PaymentController@invoiceall');
    Route::get('invoiceview', 'web\businessadmin\PaymentController@invoiceview');
    Route::get('invoiceprint', 'web\businessadmin\PaymentController@invoiceprint');
    Route::get('setting', 'web\businessadmin\SettingController@settingnew');
    
    Route::get('review-Detials/{id}','web\businessadmin\BusinessController@businessReviewDetails');

Route::get('/getSubcategory/{id}','web\admin\CategoryController@getSubcategory');
});

Route::group(['prefix' => 'admin'], function () {
    
    
	// Category
	Route::get('/', 'web\admin\LoginController@index');
	Route::post('adminpostLogin', 'web\admin\LoginController@adminpostLogin');
	
	Route::group(['middleware' => 'admin'], function () {
	    
	    Route::get('dashboard', 'web\admin\DashboardController@index');
	    
Route::get('/logout', 'web\admin\LoginController@logout');
	    
	Route::post('postbusiness', 'web\admin\BusinessController@postbusiness');
	
	
	
	Route::get('dblisting', 'web\admin\CategoryController@dblisting');
	
    Route::get('categorylist', 'web\admin\CategoryController@index');
    Route::get('addcategory', 'web\admin\CategoryController@form');
    Route::post('postcategory/{id}', 'web\admin\CategoryController@postcategory');
    Route::post('postcategory', 'web\admin\CategoryController@postcategory');
    Route::get('category/{id}', 'web\admin\CategoryController@form');
    Route::post('category/{id}', 'web\admin\CategoryController@form');
    Route::get('deletecategory/{id}', 'web\admin\CategoryController@deleteCategory');
    Route::get('/getSubcategory/{id}','web\admin\CategoryController@getSubcategory');
    Route::get('/getSubsubcategory/{id}','web\admin\CategoryController@getSubsubcategory');
	
	// Business
    Route::get('businesslist', 'web\admin\BusinessController@index');
    Route::get('addbusiness', 'web\admin\BusinessController@addbusiness');
    Route::post('postbusiness', 'web\admin\BusinessController@postbusiness');
    Route::get('business/{id}', 'web\admin\BusinessController@form');
    Route::post('business/{id}', 'web\admin\BusinessController@form');
    Route::get('deletebusiness/{id}', 'web\admin\BusinessController@deleteBusiness');
    Route::get('addbusiness/{id}', 'web\admin\BusinessController@editbusiness');
    Route::get('preview-business/{id}','web\admin\BusinessController@previewBusiness');

    
    //User
    Route::get('useradd/{id}', 'web\admin\UserController@useradd');
    Route::get('deleteuser/{id}','web\admin\UserController@deleteUser');
    
    Route::get('userlist', 'web\admin\UserController@userlist');
    Route::get('useradd', 'web\admin\UserController@useradd');
    Route::post('adminuseradd', 'web\admin\UserController@adminuseradd');
    
    Route::get('analytics', 'web\admin\AnalyticsController@analytics');
    
    //Ads
    Route::get('adslist', 'web\admin\AdsController@adslist');
    Route::get('adsadd', 'web\admin\AdsController@adsadd');
    
    //Payment
    Route::get('paymentlist', 'web\admin\PaymentController@paymentlist');
    Route::get('earnings', 'web\admin\PaymentController@earnings');
    
    //Notification
    Route::get('allnotification', 'web\admin\NotificationController@allnotification');
    Route::get('usernotification', 'web\admin\NotificationController@usernotification');
    Route::get('pushnotification', 'web\admin\NotificationController@pushnotification');
    
    //Price
    Route::get('pricelist', 'web\admin\PriceController@pricelist');
    Route::get('priceadd', 'web\admin\PriceController@priceadd');
    
    //Price
    Route::get('bloglist', 'web\admin\BlogController@bloglist');
    Route::get('blogadd', 'web\admin\BlogController@blogadd');
    
    //Setting
    Route::get('adminsetting', 'web\admin\AdminsettingController@adminsetting');
    
    //Social Media
    Route::get('socialmedia', 'web\admin\SocialmediaController@socialmedia');
	});	
});	
