<?php $__env->startSection('content'); ?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
.list-pagenat {
	loat: right;
    background-color: #eee;    
    margin-bottom: 14px;
    margin-right: 21px;
}
</style>

<div class="tz-2-com tz-2-main">

					<h4>Business Review Listings</h4>

				
					<div class="db-list-com tz-db-table">
					<?php echo $__env->make('notification.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<div class="ds-boar-title">  
							<h2>Business List</h2>  
						</div>
						<table class="responsive-table bordered">
							<thead>
								<tr>
								  
									<th>Listing Name</th>
									<th>Date</th>
									<th>Rating</th>
									<th>Total Review</th>
									<th>View Details</th>
								</tr>
							</thead>
							<tbody>
							    <?php if($businessList): ?>
    					            <?php $__currentLoopData = $businessList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								    
									<td><?php echo e($value->business_title); ?></td>
									<td><?php echo e($value->created_at); ?></td>
									<td><span class="db-list-rat"><?php echo e($value->review); ?></span></td>
									<td><span class="db-list-rat"><?php echo e($value->total_review); ?></span></td>
									
									 <td><a href="<?php echo e(url('review-Detials/'.$value->id)); ?>" class="db-list-edit"><i class="fa fa-eye"></i></a></td>
								</tr>
								    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					            <?php endif; ?>
							</tbody>
						</table>
					
					</div>
					 
						<?php echo e($businessList->links('pagination.custom')); ?>

						
				</div>

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

				<script>
             
			  
                

				$('.delete').click(function(){

				var id =$(this).attr('rel'); 

				$.confirm ({

					title : "Confirmation.!",
					content : "Are you sure want to delete this listing.?",

					buttons : {
					confirm : function(){
                        window.location = "<?php echo e(url('businessdelete')); ?>" + "/" + id;
					},
					cancel : function() {
						

					}
					}

				});
			    
				});
				
				</script>
				
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/business-review-list.blade.php ENDPATH**/ ?>