<?php $__env->startSection('content'); ?>

<div class="tz-2-com tz-2-main">
					<h4>Manage Invoice</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>All Invoice</h2>
							<p>All the Lorem Ipsum generators on the All the Lorem Ipsum generators on the</p>
						</div>
						<table class="responsive-table bordered">
							<thead>
								<tr>
									<th>From</th>
									<th>To</th>
									<th>Invoice Number</th>
									<th>Date</th>
									<th>View</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad4582456987</td>
									<td>12 May 2017</td>
									<td><a href="<?php echo e(url('invoiceview')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad8546469821</td>
									<td>07 Jul 2017</td>
									<td><a href="<?php echo e(url('invoiceview')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad985696858</td>
									<td>07 Jul 2017</td>
									<td><a href="<?php echo e(url('invoiceview')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad4582456987</td>
									<td>12 May 2017</td>
									<td><a href="<?php echo e(url('invoiceview')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad8546469821</td>
									<td>07 Jul 2017</td>
									<td><a href="<?php echo e(url('invoiceview')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>
								<tr>
									<td>Amazon Directory</td>
									<td>John smith</td>
									<td>ad985696858</td>
									<td>07 Jul 2017</td>
									<td><a href="<?php echo e(url('invoiceall')); ?>" class="db-list-edit">View</a>
									</td>									
								</tr>								
							</tbody>
						</table>
					</div>
				</div>
				
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/invoiceall.blade.php ENDPATH**/ ?>