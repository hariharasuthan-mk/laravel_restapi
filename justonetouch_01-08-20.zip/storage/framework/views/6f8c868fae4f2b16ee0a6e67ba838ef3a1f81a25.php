<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/materialize.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/style.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/bootstrap.css')); ?>" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/responsive.css')); ?>" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<?php echo $__env->make('frontend.businessadmin.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<style>
	    .typeahead-search {
    position: relative;
}

.dropdown-menu {
    width: 100%;
}

.error
{
    color:red;
	font-size:14px;
	text-align:left;
}
a {
	color:#0000aa;
}

	</style>
</head>

<body data-ng-app="">
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<!--TOP SEARCH SECTION-->
	<?php echo $__env->make('frontend.businessadmin.layout.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section class="tz-register">
			<div class="log-in-pop">
				<div class="log-in-pop-left">
					<p>Don't have an account? Create your account. It's take less then a minutes</p>
					<h4>Enhancing Your Business</h4>
					<ul>
						<li> 
							<div>
								<img src="<?php echo e(asset('public/images/icon/7.png')); ?>" alt="">
							</div>
						</li>
					</ul>
					<h4>Advertising Your Business</h4>
					<ul>
						<li> 
							<div>
								<img src="<?php echo e(asset('public/images/icon/5.png')); ?>" alt="">
							</div>
						</li>
					</ul>
					<h4>Develop Brand Image</h4>
					<ul>
						<li> 
							<div>
								<img src="<?php echo e(asset('public/images/icon/6.png')); ?>" alt="">
							</div>
						</li>
					</ul>
				</div>
				<div class="log-in-pop-right">
					<a href="#" class="pop-close" data-dismiss="modal"><img src="images/cancel.html" alt="" />
					</a>
					<h4>Login</h4>
					<?php echo $__env->make('notification.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<p>Don't have an account? Create your account. It's take less then a minutes</p>
					
					<form class="s12" method="post" action="<?php echo e(url('signin')); ?>" id=LoginForm>
						<div>
							<div class="input-field s12">
								<input type="text" data-ng-model="name1" name="mobile_no" placeholder="Enter your mobile no" class="validate" maxlength=10>
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<label>User name</label>
							</div>
						</div>
						<div>
							<div class="input-field s12">
								<input type="password" class="validate" name="password" placeholder="Enter your password">
								<label>Password</label>
							</div>
						</div>
						<div>
							<div class="input-field s4">
								<input type="submit" value="Login" class="waves-effect waves-light log-in-btn"> </div>
						</div>
						<div>
							<div class="input-field s12">								
							<a href="#">Forgot password</a> | <a href="<?php echo e(url('signup')); ?>" style="color:#0077cc;">Create a new account</a> </div>
						</div>
					</form>
				</div>
			</div>
	</section>
	<!--MOBILE APP-->
	<section class="web-app com-padd">
		<div class="container">
			<div class="row">
				<div class="col-md-6 web-app-img"> <img src="<?php echo e(asset('public/images/mobile.png')); ?>" alt="" /> </div>
				<div class="col-md-6 web-app-con">
					<h2>Looking for the Best Service Provider? <span>Get the App!</span></h2>
					<ul>
						<li><i class="fa fa-check" aria-hidden="true"></i> Find nearby listings</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Easy service enquiry</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Listing reviews and ratings</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Manage your listing, enquiry and reviews</li>
					</ul> <span>We'll send you a link, open it on your phone to download the app</span>
					<form>
						<ul>
							<li>
								<input type="text" placeholder="+01" /> </li>
							<li>
								<input type="number" placeholder="Enter mobile number" /> </li>
							<li>
								<input type="submit" value="Get App Link" /> </li>
						</ul>
					</form>
					<a href="#"><img src="<?php echo e(asset('public/images/android.png')); ?>" alt="" /> </a>
					<a href="#"><img src="<?php echo e(asset('public/images/apple.png')); ?>" alt="" /> </a>
				</div>
			</div>
		</div>
	</section>
	<!--FOOTER SECTION-->
		<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--COPY RIGHTS-->
	<section class="copy">
		<div class="container">
			<p>copyrights © <span id="cryear">2019</span> justonetouch.in &nbsp;&nbsp;All rights reserved. </p>
		</div>
	</section>
	<!--QUOTS POPUP-->
	<section>
		<!-- GET QUOTES POPUP -->
		<div class="modal fade dir-pop-com" id="list-quo" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header dir-pop-head">
						<button type="button" class="close" data-dismiss="modal">×</button>
						<h4 class="modal-title">Get a Quotes</h4>
						<!--<i class="fa fa-pencil dir-pop-head-icon" aria-hidden="true"></i>-->
					</div>
					<div class="modal-body dir-pop-body">
						<form method="post" class="form-horizontal">
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Full Name *</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="fname" placeholder="" required> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Mobile</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="mobile" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Email</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="email" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Message</label>
								<div class="col-md-8 get-quo">
									<textarea class="form-control"></textarea>
								</div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<div class="col-md-6 col-md-offset-4">
									<input type="submit" value="SUBMIT" class="pop-btn"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- GET QUOTES Popup END -->
	</section>
	<!--SCRIPT FILES-->
	<script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/bootstrap.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/materialize.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
	<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

        $("#LoginForm").validate({
            errorElement: "div",
            //set the rules for the field names

            rules: {
             
                mobile_no: {
                    required: true					
                },
                password: {
                    required: true					
                }
				
            },
            //set messages to appear inline
            messages: {
               
                mobile_no: {
                    required : "Username is required."
					
                },
                password: {
                    required: "Password is required."					
                }

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent());
            }
        });
 });
 jQuery.validator.setDefaults({
	 ignore: ""
 });

 
	</script>
</body>
</html><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/signin.blade.php ENDPATH**/ ?>