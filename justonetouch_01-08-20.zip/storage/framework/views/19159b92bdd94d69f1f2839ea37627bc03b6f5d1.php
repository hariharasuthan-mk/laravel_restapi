<?php $__env->startSection('content'); ?>

<div class="tz-2-com tz-2-main">
					<h4>Manage My Profile</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Profile</h2>
						</div>
						
						<table class="responsive-table bordered">
						    <?php if($profileList): ?>
    					        <?php $__currentLoopData = $profileList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tbody>
								<tr>
									<td>Name</td>
									<td>:</td>
									<td><?php echo e($value->first_name); ?></td>
								</tr>
								<tr>
									<td>Password</td>
									<td>:</td>
									<td>*********</td>
								</tr>
								<tr>
									<td>Eamil</td>
									<td>:</td>
									<td><?php echo e($value->email); ?></td>
								</tr>
								<tr>
									<td>Phone</td>
									<td>:</td>
									<td><?php echo e($value->mobile_no); ?></td>
								</tr>
								<tr>
									<td>Address</td>
									<td>:</td>
									<td><?php echo e($value->address); ?></td>
								</tr>
								<tr>
									<td>Status</td>
									<td>:</td>
									<td><span class="db-done"><?php if($value->is_active==1): ?> <?php echo e("Active"); ?> <?php else: ?> <?php echo e("InActive"); ?> <?php endif; ?></span> </td>
								</tr>
							</tbody>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					    <?php endif; ?>
						</table>
						<div class="db-mak-pay-bot">
							<a href="<?php echo e(url('profileedit')); ?>/<?php echo e($value->id); ?>" class="waves-effect waves-light btn-large">Edit my profile</a> </div>
					</div>
				</div>
				
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/profileview.blade.php ENDPATH**/ ?>