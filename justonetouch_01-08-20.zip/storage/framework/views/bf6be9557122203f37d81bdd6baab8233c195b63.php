<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/jquery.timepicker.css')); ?>" />
  <script src="<?php echo e(asset('public/js/jquery.timepicker.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyCs2dQaPqIIBxc9Hb-Is6ur0keuh3kxeAw&callback=initMap&libraries=places" async defer></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
<style>
	.error
{
    color:red;
	font-size:14px;
}

.add-button {
	float: right;
    padding: 7px 10px 6px;
    background-color: #;
    background-color: #337ab7;
    color: #fff;
    font-size: 12px;
    border-radius: 3px;
}
.gm-fullscreen-control {
	top :76px;
}
.ui-timepicker-wrapper {
	width:16%;
}
.switch label {
	color: #14addb;
	font-family: 'Quicksand', sans-serif;
}

/*FAncy Box Design*/
.gallery
    {
        display: inline-block;
        margin-top: 20px;
    }
    .close-icon{
    	border-radius: 50%;
        position: absolute;
        right: 5px;
        top: -10px;
        padding: 5px 8px;
    }
    .form-image-upload{
        background: #e8e8e8 none repeat scroll 0 0;
        padding: 15px;
    }
	.img-responsive, .thumbnail > img, .thumbnail a > img, .carousel-inner > .item > img, .carousel-inner > .item > a > img {
    display: block;
    max-width: 100%;
    height: 100px;
}
table {
    background-color: #fff;
}

.ratingSpan {
    background: #55bf15;   
    color: #fff;
    font-weight: 600;
    padding: 8px;
    border-radius: 5px;
    vertical-align: sub;
    margin-right: 15px;
}
	/*FAncy Box Design*/

	</style>

	<script>
			$(function() {
				$('.starttime').timepicker();
			});
			$(function() {
				$('.endtime').timepicker();
			});
			
			</script>
			 <script type="text/javascript">

    $(document).ready(function() {

      $(".addnew").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });
    </script>
    <script>
		<?php if(isset($preview['lattutude_lat'])): ?>
		var lattitude = "<?php echo $preview['lattutude_lat'] ?>";
		<?php else: ?>
		var lattitude = 13.060422;
		<?php endif; ?>
		<?php if(isset($preview['longitude_lng'])): ?>
		var longitude = "<?php echo $preview['longitude_lng'] ?>";
		<?php else: ?>
		var longitude = 80.249583;
		<?php endif; ?>
		
	
	var center= {lat: <?php echo $preview['lattutude_lat'] ?>, lng: <?php echo $preview['longitude_lng'] ?>};
     function initMap() {
		
		var map = new google.maps.Map(document.getElementById('map'), {
			center: {lat: <?php echo $preview['lattutude_lat'] ?>, lng: <?php echo $preview['longitude_lng'] ?>},
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		zoom: 14
		});
	
	var marker = new google.maps.Marker({position: center, map: map});
	
    var input = document.getElementById('searchInput');

    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);

    var infowindow = new google.maps.InfoWindow();
    var marker = new google.maps.Marker({
        map: map,
        anchorPoint: new google.maps.Point(0, -29)
    });

    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(true);
        var place = autocomplete.getPlace();
		
	
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }
		
  
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
		
        marker.setIcon(({
            url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);
    
        var address = '';
        if (place.address_components) {
            address = [
              (place.address_components[0] && place.address_components[0].short_name || ''),
              (place.address_components[1] && place.address_components[1].short_name || ''),
              (place.address_components[2] && place.address_components[2].short_name || '')
            ].join(' ');
        }
		
        infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
        infowindow.open(map, marker);
      
        // Location details
        for (var i = 0; i < place.address_components.length; i++) {
            if(place.address_components[i].types[0] == 'postal_code'){
                //document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
            }
            if(place.address_components[i].types[0] == 'country'){
                //document.getElementById('country').innerHTML = place.address_components[i].long_name;
            }
        }
        /*document.getElementById('location').innerHTML = place.formatted_address;
        document.getElementById('lat').innerHTML = place.geometry.location.lat();
        document.getElementById('lon').innerHTML = place.geometry.location.lng();*/
		document.getElementById('city_id').value = place.name;
		document.getElementById('cityLat').value = place.geometry.location.lat();
		document.getElementById('cityLng').value = place.geometry.location.lng();
    });
}


  $(document).ready(function(){
        $(".fancybox").fancybox({
            openEffect: "none",
            closeEffect: "none"
        });
    });

</script>


    
    <!--== breadcrumbs ==-->
				
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4>Add New Listing <a href="<?php echo e(url('businesslist')); ?>" class="add-button" style="margin-left: 63%;"> <i class="fa fa-list"></i> All Bussiness List</a></h4> 
						
						<!-- Dropdown Structure -->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-inn-page">
					<div class="tab-inn ad-tab-inn">
						<div class="hom-cre-acc-left hom-cre-acc-right">
							<div class="">
								<?php echo Form::open(['url' => url('userpostbusiness'), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'businessform']); ?>

	

								<table class="responsive-table bordered">
							<tbody>
							    <tr>
									<td>Total View </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label style="padding: 5px 19px;border-radius: 3px;background-color: #f74d40;color:#fff;"><?php echo $preview['view_count']; ?> </label>
										</div>
									</td>
									<td>Rating </td>
									<td>:</td>
									<td>
									
										<div class="switch">
										<label><span class="ratingSpan"><?php echo $preview['review']; ?><i class="fa fa-star" aria-hidden="true" style="font-size: 12px;vertical-align: 6px;border: none;"></i></span></label>
											<!--<label style="padding: 5px 19px;background-color: #14addb;color:#fff;"><?php echo $preview['review']; ?><i class="fa fa-star" aria-hidden="true"></i></label>-->
										</div>
									</td>
								</tr>
								<tr>
									<td>Category </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['category_name']; ?> </label>
										</div>
									</td>
									<td>Sub Category </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['sub_cat_name']; ?></label>
										</div>
									</td>
								</tr>
								<tr>
									<td>First Name </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['first_name']; ?> </label>
										</div>
									</td>
									<td>Last Name </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['last_name']; ?></label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Email </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['email']; ?> </label>
										</div>
									</td>
									<td>Mobile Number </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['mobile_no']; ?></label>
										</div>
									</td>
								</tr>
								

								<tr>
									<td>Address </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php echo $preview['address']; ?> </label>
										</div>
									</td>
									
								</tr>
								<tr>
								<td colspan="6">
								<div class="row">
											<div id="map" style="width:96%; height:300px; margin:10px 10px; position:relative;border:1px solid #ccc;"></div>
									</div>
								</td>
								</tr>

								<tr>
									<td>City Name </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['city_name']; ?> </label>
										</div>
									</td>
									<td>Pincode </td>
									<td>:</td>
									<td>
										<div class="switch">
											<label><?php echo $preview['pincode']; ?></label>
										</div>
									</td>
								</tr>
								<tr>
									<td>User Type </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php echo $preview['user_type']; ?> </label>
										</div>
									</td>
									
								</tr>

								<tr>
									<td>Business Title </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php echo $preview['business_title']; ?> </label>
										</div>
									</td>
									
								</tr>
								<tr>
									<td>Business Website </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php echo $preview['website']; ?> </label>
										</div>
									</td>
									
								</tr>

								<tr>
								<td colspan="3">
								<div class="input-field col s3" style="margin-top: 22px;">
								<label style="margin-top: -43px;color: #a90707;font-weight:600;">Logo</label>
									<?php 
									$file = isset($preview['thumbnail_img'])?$preview['thumbnail_img']:"";
									$path= public_path()."/upload/business/thumbnail/original/".$file; ?>
									<?php if(isset($preview['thumbnail_img']) && $preview['thumbnail_img'] !="" && file_exists($path)): ?>
										
									<img src="<?php echo e(asset('/public/upload/business/thumbnail/original/'.$preview['thumbnail_img'])); ?>" width='130' height='120' id="logoImageId">
									<?php else: ?>
									<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="logoImageId">
									<?php endif; ?>
									</div>
								</td>

								<td colspan="3">
								<div class="input-field col s3" style="margin-top: 22px;">
								<label style="margin-top: -43px;color: #a90707;font-weight:600;">Banner</label>
									<?php 
									$fileBanner = isset($preview['banner_img'])?$preview['banner_img']:"";
									$pathBannner= public_path()."/upload/business/banner/original/".$fileBanner; ?>

									<?php if(isset($preview['banner_img']) && $preview['banner_img'] !="" && file_exists($pathBannner)): ?>
										
									<img src="<?php echo e(asset('/public/upload/business/banner/original/'.$preview['banner_img'])); ?>" width='130' height='120' id="imageId">
									<?php else: ?>
									<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="bannerImageId">
									<?php endif; ?>
									</div>
								</td>
								</tr>

								<tr>
									<td>Business Tag </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php echo $preview['business_tag']; ?> </label>
										</div>
									</td>
									
								</tr>
								
								<tr>
									<td>Business Description </td>
									<td>:</td>
									<td colspan="4">

									    <textarea readonly name="business_desc" placeholder="Enter Your Business Desc"><?php echo e(isset($preview['business_desc']) ? $preview['business_desc'] : ""); ?></textarea>
                                            <script>
                                                CKEDITOR.replace( 'business_desc' );
                                            </script>
										
									</td>
									
								</tr>
								
								<tr>
									<td>Status </td>
									<td>:</td>
									<td colspan="4">
										<div class="switch">
											<label><?php 
											if($preview['status'] == '1'){
											   echo "Active"; 
											}
											else {
												echo "Inactive"; 
											}
											?> </label>
										</div>
									</td>
									
								</tr>
								
							</tbody>
						</table>

						           
										


									<div class="row">
										<div class="db-v2-list-form-inn-tit" style="margin-bottom: 24px;">
											<h5>Time Operation </h5>
										</div>
									</div>
									
									<div class="row">

									<table class="responsive-table bordered">
											<thead>
												<tr>
													<th>Day</th>
													<th>Start Time</th>
													<th>End Time</th>									
												</tr>
											</thead>
											<tbody>
											<?php  for($i=0;$i<7;$i++){  
												$find = array_search($i,$working_days);
												
												if($find) {
													$details = DB::table('tbl_workingday')->where('id',$find)->first(); ?>
												
												<tr>
													<td><?php echo e($details->week_day); ?></td>
													<td><?php echo e($details->week_start_time); ?></td>
													<td><?php echo e($details->week_end_time); ?></td>
												</tr>
											
											 <?php } else { 

												 $days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
												 $dayName = $days[$i]
												 
												 ?>
												<tr>
													<td><?php echo e($dayName); ?></td>
													<td><?php echo "----";?></td>
													<td><?php echo "----";?></td>
												</tr>
											<?php } }?>
											</tbody>
										</table>
									   
									</div>

									<div class="row">
										<div class="db-v2-list-form-inn-tit" style="margin-bottom: 24px;">
											<h5>Gallery <span style="font-size:11px;color:#F00;">( Click image to view )</span></h5>
											
										</div>
										
									</div>

						  
										<div class="row" style="background-color:#fff;">
										<div class='list-group gallery'>

												<?php if($allImages->count()): ?>
													<?php $__currentLoopData = $allImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<div class='col-sm-4 col-xs-6 col-md-3 col-lg-3'>
														<a class="thumbnail fancybox" rel="ligthbox" href="<?php echo e(asset('/public/upload/business/gallary/original/'.$image->image_name)); ?>">
															<img class="img-responsive" width="150" height="150" alt="" src="<?php echo e(asset('/public/upload/business/gallary/original/'.$image->image_name)); ?>" />
															<div class='text-center'>
																<!--<small class='text-muted'><?php echo e($image->image_name); ?></small>-->
															</div> <!-- text-center / end -->
														</a>
														
													</div> <!-- col-6 / end -->
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php endif; ?>


											</div> <!-- list-group / end -->
										</div>
									
									
									
									
							
							</div>
						</div>
									</div>
								</div>
							
							</div>
						</div>
					</div>
				</div>
    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/preview-business.blade.php ENDPATH**/ ?>