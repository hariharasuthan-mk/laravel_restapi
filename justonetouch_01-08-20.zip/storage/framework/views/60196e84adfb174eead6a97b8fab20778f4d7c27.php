<div class="tz-l">
				<div class="tz-l-1">
					<ul>
					    <?php if(Request::user()->user_image): ?>
						<li><img src="<?php echo e(Request::user()->user_image_path); ?>thumbnail/<?php echo e(Request::user()->user_image); ?>" alt="" style="height:250px !important; width:350px !important;"/> </li>
						<?php else: ?>
						<li><img src="<?php echo e(asset('public/images/db-profile.jpg')); ?>" alt="" /> </li>
						<?php endif; ?>
						<li><span>80%</span> profile compl</li>
						<li><span>18</span> Notifications</li>
					</ul>
				</div>
				<div class="tz-l-2">
					<ul>
						<li>
							<a href="<?php echo e(url('businessadmin')); ?>" class="tz-lma"><img src="<?php echo e(asset('public/images/icon/dbl1.png')); ?>" alt="" /> My Dashboard</a>
						</li>
						<li>
							<a href="<?php echo e(url('businesslist')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl2.png')); ?>" alt="" /> All Listing</a>
						</li>
						<li>
							<a href="<?php echo e(url('businessadd')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl3.png')); ?>" alt="" /> Add New Listing</a>
						</li>
						<!--<li>
							<a href="db-message.html"><img src="<?php echo e(asset('public/images/icon/dbl14.png')); ?>" alt="" /> Messages(12)</a>
						</li>-->
						<li>
							<a href="<?php echo e(url('reviewlist')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl13.png')); ?>" alt="" /> Reviews</a>
						</li>
						<li>
							<a href="<?php echo e(url('profileview')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl6.png')); ?>" alt="" /> My Profile</a>
						</li>
						<li>
							<a href="<?php echo e(url('adsummary')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl11.png')); ?>" alt="" /> Ad Summary</a>
						</li>
						<li>
							<a href="<?php echo e(url('checkout')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl9.png')); ?>" alt=""> Check Out</a>
						</li>
						<li>
							<a href="<?php echo e(url('invoiceall')); ?>"><img src="<?php echo e(asset('public/images/icon/db21.png')); ?>" alt="" /> Invoice</a>
						</li>						
						<!--<li>
							<a href="db-claim.html"><img src="<?php echo e(asset('public/images/icon/dbl7.png')); ?>" alt="" /> Claim & Refund</a>
						</li>-->
						<li>
							<a href="<?php echo e(url('setting')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl210.png')); ?>" alt="" /> Setting</a>
						</li>
						<li>
							<a href="<?php echo e(url('logout')); ?>"><img src="<?php echo e(asset('public/images/icon/dbl12.png')); ?>" alt="" /> Log Out</a>
						</li>
					</ul>
				</div>
			</div><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/layout/sidenav.blade.php ENDPATH**/ ?>