<?php $__env->startSection('content'); ?>
<style>

.error
{
    color:red;
	font-size:14px;
}
.add-button {
	float: right;
    padding: 7px 10px 6px;
    background-color: #;
    background-color: #337ab7;
    color: #fff;
    font-size: 12px;
    border-radius: 3px;
}

</style>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

        $("#userform").validate({
            errorElement: "div",
            //set the rules for the field names

            rules: {
                first_name: {
                    required: true
                },
                last_name: {
                    required:true
                },
                mobile_no: {
                    required: true,
					digits:true,
					minlength:10,
					maxlength:10
                },
                email: {
                    required: true,
					email:true
                },
				address: {
                    required: true
                },
				category_type: {
                    required: true
                }
            },
            //set messages to appear inline
            messages: {
                first_name: {
                    required: "First name is required. "

                },
                last_name: {
                    required: "Last name is required. "

                },
                mobile_no: {
                    required : "Mobile number is required",
					digits: "Only Numbers allowed.",
					minlength:"Mobile number should be 10 digits.",
					maxlength:"Mobile number should be 10 digits."
                },
                email: {
                    required : "Email is required",
					email:"Please Enter the valid email address."
                },
				address: {
                    required : "Address is required"
                },
				category_type: {
                    required : "Please select user type."
                }

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent());
            }
        });
 });
 jQuery.validator.setDefaults({
	 ignore: ""
 });

 
	</script>
<!--== breadcrumbs ==-->
               <?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
				<?php endif; ?>
				<div class="sb2-2-2"> 
					<ul>
						<li style="float: left;"><a href="<?php echo e(url('admin/dashboard')); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a> </li>
						<li class="active-bre" style="list-style-type: none;"><a href="<?php echo e(url('admin/useradd')); ?>"> Add User</a> </li>
						<!--<li class="page-back"><a href="#"><i class="fa fa-backward" aria-hidden="true"></i> Back</a> </li>-->
					</ul>
				</div>
				<div class="tz-2 tz-2-admin"> 
					<div class="tz-2-com tz-2-main">
						<h4>Add New User <a href="<?php echo e(url('admin/userlist')); ?>" class="add-button" style=""> <i class="fa fa-list"></i>  Users List</a></h4> 
						<!--<a class="dropdown-button drop-down-meta drop-down-meta-inn" href="#" data-activates="dr-list"><i class="material-icons">more_vert</i></a>
						<ul id="dr-list" class="dropdown-content">
							<li><a href="#!">Add New</a> </li>
							<li><a href="#!">Edit</a> </li>
							<li><a href="#!">Update</a> </li>
							<li class="divider"></li>
							<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
							<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
							<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
						</ul>-->
						<!-- Dropdown Structure -->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-inn-page">
									<div class="tab-inn ad-tab-inn">
										<div class="hom-cre-acc-left hom-cre-acc-right">
											<div class="">
												<?php echo $__env->make('notification.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
												
												<?php echo Form::open(['url' => url('admin/adminuseradd'), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'userform']); ?>

													
												<div class="row">
														<div class="input-field col s12">
															<?php 
															$userType = [
																''=>'Select User Type',
																"1"=>"Free",
																"2"=>"Premium",
																"3"=>"Premium Plus",
																"4"=>"Ultra Premium Plus",
															];
															?>
															<?php echo e(Form::select('category_type',$userType,isset($data['category_type']) ? $data['category_type'] : '',['class'=>'validate ','id'=>'category_type'])); ?>

														
														</div>
													</div>
												<div class="row">
														<div class="input-field col s6">
															<?php echo Form::text('first_name',isset($data['first_name']) ? $data['first_name'] :"",['class'=>'validate','id'=>'first_name']); ?>


															<label for="first_name">First Name</label>
														</div>
														<div class="input-field col s6">
														<?php echo Form::text('last_name',isset($data['last_name']) ? $data['last_name'] : "",['class'=>'validate','id'=>'last_name']); ?>


															<label for="last_name">Last Name</label>
														</div>
													</div>
													<div class="row">
														<div class="input-field col s12">
															<?php echo e(Form::text('mobile_no',isset($data['mobile_no']) ? $data['mobile_no']:"",['class'=>'validate','id'=>'mobile_no','maxlength'=>10])); ?>														
															<label for="list_phone">Mobile Number</label>
														</div>
													</div>
													<div class="row">
														<div class="input-field col s12">
															
															<?php echo e(Form::email('email',isset($data['email']) ? $data['email']: "",['class'=>'validate','id'=>'email'])); ?>

															<label for="email">Email</label>
														</div>
													</div>
													<div class="row">
														<div class="input-field col s12">
															
															<?php echo e(Form::text('address',isset($data['address']) ? $data['address'] : "",['class'=>'validate','id'=>'list_addr'])); ?>

															<label for="list_addr">Address</label>
														</div>
													</div>
													
													<?php echo e(Form::hidden('id',isset($data['id']) ? $data['id'] : "",['class'=>'validate','id'=>'list_addr'])); ?>


													
													<div class="row">												 
												  <div class="input-field col s3" style="margin-left: 37%;margin-top: 44px;">
													  <input type="submit" value="SUBMIT" class="waves-button-input" style="color:#fff"> 
												  </div>
                                             
											  </div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/admin/pages/useradd.blade.php ENDPATH**/ ?>