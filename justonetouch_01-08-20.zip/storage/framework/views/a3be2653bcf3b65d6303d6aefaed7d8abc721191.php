<?php $__env->startSection('content'); ?>

<div class="tz-2-com tz-2-main">
					<h4>Setting</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>User Dashboard Setting</h2>
							<p>All the Lorem Ipsum generators on the All the Lorem Ipsum generators on the</p>
						</div>
						<table class="responsive-table bordered">
							<tbody>
								<tr>
									<td>Profile Status</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Listing Review</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Send SMS</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Call Now</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Get Quotes</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Show Contact Info</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> No
												<input type="checkbox"> <span class="lever"></span> Yes </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Listing Guarantee</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> No
												<input type="checkbox"> <span class="lever"></span> Yes </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Show Profile Info</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> No
												<input type="checkbox"> <span class="lever"></span> Yes </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Social Media Share</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> No
												<input type="checkbox"> <span class="lever"></span> Yes </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>Show Website Ads</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> No
												<input type="checkbox"> <span class="lever"></span> Yes </label>
										</div>
									</td>
								</tr>
								<tr>
									<td>All Notifications</td>
									<td>:</td>
									<td>
										<div class="switch">
											<label> Deactivate
												<input type="checkbox"> <span class="lever"></span> Activate </label>
										</div>
									</td>
								</tr>
							</tbody>
						</table>
						<div class="db-mak-pay-bot">
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p> <a href="#!" class="waves-effect waves-light btn-large">Save Settings</a> </div>
					</div>
				</div>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/setting.blade.php ENDPATH**/ ?>