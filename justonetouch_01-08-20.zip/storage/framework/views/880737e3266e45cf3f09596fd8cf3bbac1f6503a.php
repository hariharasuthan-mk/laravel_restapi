<style>
    .alert-success {
    color: #fff;
    background-color: #3c763d;
    border-color: #3c763d;
    font-size: 13px;
}
.jconfirm-content {
    font-size:13px;
}


.sb2-2-2 ul li {
    list-style-type: circle;
    float: none;
   
}
.alert > p, .alert > ul {
    margin-bottom: 0;
    padding: 13px;
}

alert-danger {
    color: #fff; 
    background-color: #a94442;
    border-color: #a94442;
}

    </style>
<?php if(Session::has('message')): ?>

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
            <i class="icon-tick"></i><?php echo e(Session::get('message')); ?>!
        </div>
    </div>

<?php endif; ?>
<?php if(Session::has('success')): ?>

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
            <i class="icon-tick"></i><?php echo e(Session::get('success')); ?>!
        </div>
    </div>

<?php endif; ?>
<?php if(Session::has('error')): ?>
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
    <div class="alert alert-danger">
        <i class="icon-warning2"></i><?php echo e(Session::get('error')); ?>!
    </div>   
    </div>
<?php endif; ?>
<?php if(Session::has('errors')): ?>
<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <i class="icon-warning2"></i><?php echo e($error); ?>

        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>






<?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/notification/notification.blade.php ENDPATH**/ ?>