<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/jquery.timepicker.css')); ?>" />
  <script src="<?php echo e(asset('public/js/jquery.timepicker.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<!-- <script src="https://maps.googleapis.com/maps/api/js?libraries=places&key=AIzaSyCs2dQaPqIIBxc9Hb-Is6ur0keuh3kxeAw&callback=initMap&libraries=places" async defer></script> -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/select2-materialize.css')); ?>" />
<script src="<?php echo e(asset('public/js/select2-materialize.js')); ?>"></script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCs2dQaPqIIBxc9Hb-Is6ur0keuh3kxeAw&libraries=places&callback=initMap" async defer></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


<style>
	.error
{
    color:red;
	font-size:14px;
}

.add-button {
	float: right;
    padding: 7px 10px 6px;
    background-color: #;
    background-color: #337ab7;
    color: #fff;
    font-size: 12px;
    border-radius: 3px;
}
.gm-fullscreen-control {
	top :76px;
}
.ui-timepicker-wrapper {
	width:16%;
}

.thumbnailccc { 
    position:relative;
}

.thumbnailccc a {
    /* display: block; */
    /* width: 18px; */
    /* height: 17px; */
    position: absolute;
    top: -3px;
    right: 20px;
    /* background: #f00; */
    overflow: hidden;
    /* text-indent: -9999px; */
}
.jconfirm-content {
	font-size: 12px;
}

	</style>
<script>
$(document).ready(function(){
    $('#parent_id').sm_select();
});
</script>

<script>




$(document).ready(function () {

$("#businessform").validate({
	errorElement: "div",
	//set the rules for the field names

	rules: {
		parent_id : {
			required: true,
		},
		business_firstname: {
			required: true
		},
		business_lastname: {
			required: true,
		},
		business_email: {
			required: true,
			email:true
		},
		business_contactno: {
			required: true,
			digits:true,
			//minlength:10,
			//maxlength:10,
		},
		city_name: {
			required: true,
		},
		pincode: {
			required: true,
			//minlength : 6
		},
		business_website: {
			required: true,
		},
		category_type: {
			required: true,
		},
		business_title: {
			required: true,
		},
		business_tags: {
			required: true,
		},
		business_desc: {
			required: true,
		},
		category_type: {
			required: true,
		},
		business_image_filename: {
			required: true,
		},
		business_banner_filename: {
			required: true,
		},

		
	},
	//set messages to appear inline
	messages: {

		parent_id : {
			required : "Please select the category."
		},
	 
		business_firstname: {
			required : "First name is required"
		},
		business_lastname: {
			required : "Last name is required."
		},
		business_email: {
			required : "Email is required.",
			email : "Please enter the valid email address."
		},
		business_contactno: {
			required : "Last name is required.",
			digits : "Only number is allowed.",
			//minlength : "Mobile number should be 10 digits.",
			//maxlength : "Mobile number should be 10 digits.",
		},
		city_name: {
			required : "City name is required."
		},
		pincode: {
			required : "Last name is required.",
			///minlength : "Please enter valid pincode"
		},
		
		category_type: {
			required : "Please select one."
		},
		business_title: {
			required : "Bussiness title is required."
		},
		business_website: {
			required : "Website field is required."
		},
		business_tags: {
			required : "Bussiness tag is required."
		},
		business_desc: {
			required : "Bussiness description is required."
		},
		business_image_filename: {
			required : "Logo is required."
		},
		business_banner_filename: {
			required: "Banner is required.",
		},
		

	},
	errorPlacement: function (error, element) {
		error.appendTo(element.parent());
	}
});
});
jQuery.validator.setDefaults({
  ignore : ""
});



$(document).ready(function () {   
    $('body').on('change','#parent_id', function() {
          //alert("sdsad");
		$("#subcatdiv").show();
        var cid = $(this).val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
		}			
		var url="<?php echo e(url('/getSubcategory')); ?>/"+cid;
        if(cid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                console.log(res);
				if(res)
                {
                    $("#subcat_id").empty();
                    //$("#city").empty();
                    $("#subcat_id").append('<option value="0">Select Sub Category</option>');
                    $.each(res,function(key,value){
                        $("#subcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                    $('#subcat_id').material_select();
                }
           }

        });
        }
    });
}); 


	</script>
	<script>
			$(function() {
				$('.starttime').timepicker();
			});
			$(function() {
				$('.endtime').timepicker();
			});
			
			</script>
			 <script type="text/javascript">

    $(document).ready(function() {

      $(".addnew").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });
    </script>
    <script>
	/*	<?php if(isset($data['lattutude_lat'])): ?>
		var lattitude = "<?php //echo $data['lattutude_lat'] ?>";
		<?php else: ?>
		var lattitude = 13.060422;
		<?php endif; ?>
		<?php if(isset($data['longitude_lng'])): ?>
		var longitude = "<?php //echo $data['longitude_lng'] ?>";
		<?php else: ?>
		var longitude = 80.249583;
		<?php endif; ?>
		
	<?php if(isset($data['id']) && $data['id']): ?>	
	var center= {lat: <?php //echo $data['lattutude_lat'] ?>, lng: <?php// echo $data['longitude_lng'] ?>};
     function initMap() {
		
		var map = new google.maps.Map(document.getElementById('map'), {
			center: {lat: <?php //echo $data['lattutude_lat'] ?>, lng: <?php //echo $data['longitude_lng'] ?>},
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		zoom: 14
		});
	<?php else: ?> 
	var center= {lat: 13.060422, lng: 80.249583};
	function initMap() {
	
		var map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: 13.060422, lng: 80.249583},
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		zoom: 14
		});
	<?php endif; ?>
	var marker = new google.maps.Marker({position: center, map: map});

	   var circle = new google.maps.Circle({
		map: map,
		radius: 1*1000,    // 10 miles in metres
		fillColor: '#AA0000',
		strokeColor: '#800000',
		strokeOpacity:1.0,
		strokeWeight:0.5
		});
		circle.bindTo('center', marker, 'position');

	
	
        var input = document.getElementById('searchInput');

		var options = {
		types: ['address'],
		componentRestrictions: {country: 'in'}
		};

    //autocomplete = new google.maps.places.Autocomplete(input, options);

    map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

    var autocomplete = new google.maps.places.Autocomplete(input,options);
    autocomplete.bindTo('bounds', map);

    var infowindow = new google.maps.InfoWindow();
    var marker = new google.maps.Marker({
        map: map,
        anchorPoint: new google.maps.Point(0, -29)
    });

    autocomplete.addListener('place_changed', function() {
        infowindow.close();
        marker.setVisible(true);
        var place = autocomplete.getPlace();
		
	
        if (!place.geometry) {
            window.alert("Autocomplete's returned place contains no geometry");
            return;
        }
		
  
        // If the place has a geometry, then present it on a map.
        if (place.geometry.viewport) {
            map.fitBounds(place.geometry.viewport);
        } else {
            map.setCenter(place.geometry.location);
            map.setZoom(17);
        }
		
        marker.setIcon(({
            url: place.icon,
            size: new google.maps.Size(71, 71),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(17, 34),
            scaledSize: new google.maps.Size(35, 35)
        }));
        marker.setPosition(place.geometry.location);
        marker.setVisible(true);
    
        var address = '';
        if (place.address_components) {
            address = [
              (place.address_components[0] && place.address_components[0].short_name || ''),
              (place.address_components[1] && place.address_components[1].short_name || ''),
              (place.address_components[2] && place.address_components[2].short_name || '')
            ].join(' ');
        }
		
        infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
        infowindow.open(map, marker);
      
        // Location details
        for (var i = 0; i < place.address_components.length; i++) {
            if(place.address_components[i].types[0] == 'postal_code'){
                //document.getElementById('postal_code').innerHTML = place.address_components[i].long_name;
            }
            if(place.address_components[i].types[0] == 'country'){
                //document.getElementById('country').innerHTML = place.address_components[i].long_name;
            }
        }
        /*document.getElementById('location').innerHTML = place.formatted_address;
        document.getElementById('lat').innerHTML = place.geometry.location.lat();
        document.getElementById('lon').innerHTML = place.geometry.location.lng();*/
		//document.getElementById('city_id').value = place.name;
		//document.getElementById('cityLat').value = place.geometry.location.lat();
		//document.getElementById('cityLng').value = place.geometry.location.lng();
    //});
//}*/

</script>
<script>

$('body').on('change','.gallaryImage',function(){
	var idValue = $(this).attr('id');
	var lastChar = idValue[idValue.length - 1];
	console.log(lastChar);
	var filename = $(this).val();
	var ext = filename.split('.').pop().toLowerCase();
	
	if($.inArray(ext,['jpg','jpeg','png']) == -1) {
       // if(idValue == 'gallaryInputId1') {
		 $('#gallaryErrorMsg'+lastChar).show().text('Only jpg, jpeg, png file is allowed.').css({'color':'#f00','font-size':'13px'});
		//}
		// else if(idValue == 'gallaryInputId2'){
		//   $('#gallaryErrorMsg2').show().text('Only jpg, jpeg, png file is allowed.').css({'color':'#f00','font-size':'13px'});
	
		// }
	    $(this).val('');  
	}else {
		$('#gallaryErrorMsg'+lastChar).hide();
		readGallaryImage(this);
	}

});

function readGallaryImage(input) {
	 var id = $(input).attr('id');
	 var lastChar = id[id.length - 1];
	if(input.files && input.files[0]){

		var reader = new FileReader();
		reader.onload = function (e){	
			//if(id == 'gallaryInputId1'){	
              $('#gallaryImage'+lastChar).attr('src',e.target.result).css('border','1px solid black');
			//}
			
		}
		reader.readAsDataURL(input.files[0]);
	}

}


$('body').on('change','#business_image,#business_banner,#about_business_img',function(){
  var idValue = $(this).attr('id');
  console.log(idValue);
  
  var filename = $(this).val(); 
  var ext = filename.split('.').pop().toLowerCase();

  if($.inArray(ext,['jpg','jpeg','png']) == -1){	
	  if(idValue == 'business_image') { 
	  $('#logoErrorMsg').show().text('Only jpg, jpeg, png file is allowed.').css({'color':'#f00','font-size':'13px'});
	  }
	  else if(idValue == 'business_banner'){
          $('#bannerErrorMsg').show().text('Only jpg, jpeg, png is allowed.').css({'color':'#F00','font-size':'13px'});
	  }
	  else if(idValue == 'about_business_img'){
		$('#aboutErrorMsg').show().text('Only jpg, jpeg, png is allowed.').css({'color':'#F00','font-size':'13px'});

	  }
	  $(this).val(''); 
  }else {

      if(idValue == 'business_image') 
	  { 
		$('#logoErrorMsg').hide();	 
	   }
	  else if(idValue == 'business_banner')
	  {
		$('#bannerErrorMsg').hide();
	  }
	  else if(idValue == 'about_business_img')
	  {
		$('#aboutErrorMsg').hide();
	  }
	
	 
	  readUrlLogo(this);
  }

})
function readUrlLogo(input) {
	 var id = $(input).attr('id');

	if(input.files && input.files[0]){

		var reader = new FileReader();
		reader.onload = function (e){	
			if(id == 'business_image'){	
              $('#logoImageId').attr('src',e.target.result).css('border','1px solid black');
			}
			else if(id =='business_banner') {
				$('#bannerImageId').attr('src',e.target.result).css('border','1px solid black');
			}
			else if(id =='about_business_img') {
				$('#aboutImageId').attr('src',e.target.result).css('border','1px solid black');
			}
		}
		reader.readAsDataURL(input.files[0]);
	}

}


var m=2;
<?php if(isset($getGallaryimages)): ?>
  var totalimg = "<?php echo e(count($getGallaryimages)); ?>";
<?php else: ?>
   var totalimg = 0;;
<?php endif; ?>
var balace = 5 - totalimg;
//var ccccc = m + balace;
m = parseInt(m) + parseInt(totalimg);
 console.log(m);



 var imgId;

function deleteImage(imgId){

	$.confirm({
		title : 'Confirmation!',
		content : 'Are you sure want to delete this image.?',

        buttons : {
		confirm :function(){

			$.ajax({
				method:"POST",
				data : {id : imgId,_token : "<?php echo e(csrf_token()); ?>"},
				url:"<?php echo e(url('image/delete')); ?>",
				dataType : 'json',

				success : function(res){
					if(res.status ==1){
						$('#imgDeleteMsg').text(res.msg).fadeOut(5000).css('color','#265626');
						m = m-1;
						$('#imageOuterDiv_'+imgId).remove();
						if(m < 7){							
							$('#addMoreRow').css('display','block');
						}
					}

				}

			});

		},
		cancel : function() {
			
		}
		}

	});
  
}


function addRow() {
	if(m < 6 ) {
		var gallaryInputId = "gallaryInputId"+m;
		var gallaryImage = "gallaryImage"+m;
		var gallaryErrorMsg = "gallaryErrorMsg"+m;
	$('.append-div').append('<div class="file-field input-field">'+
											'<div class="tz-up-btn" style="width: 130px;">'+ '<span>File</span>'+
												'<input type="file" id='+gallaryInputId+ ' class="gallaryImage" multiple name="filename[]" style="width: 30%;">' +'</div>'+
											'<div class="file-path-wrapper db-v2-pg-inp">'+
												'<input class="file-path validate" type="text" style="width: 82%;">'+ '	<img src="<?php echo e(asset("public/images/default-image.jpg")); ?>" width="50" height="46" id='+gallaryImage+'>' +
												'<a href="javascript:void(0)" class="remove-div" style="padding: 3px 2px 3px;background-color: #F00;margin-left: 10px;"><i class="fa fa-times" aria-hidden="true" style="border:none;color:#fff;"></i></a>'+
											'</div>'+ '<span id='+gallaryErrorMsg+'></span>'+ 
										'</div>');
										m++;
	}else {
	
		$('#imgDeleteMsg').show().text('Only 5 gallary image is allowed.').fadeOut(10000).css('color','#F00');

		
	}

}


$(document.body).on('click','.remove-div',function(){
    m--;
	$(this).closest('.input-field').remove();
});

$(document).on('click','#test5',function(){
  var status = $(this).prop('checked');
  var starttime = $('#starttime_0').val();
  var endtime = $('#endtime_0').val();
  

   if(starttime == "" && endtime ==""){
	$('#starttime_0').css('border-color','#f00');
	$('#endtime_0').css('border-color','#f00');
	
	
	return false;
   }
   if(status == true) {
    $(".customstart").val(starttime);
	$(".customend").val(endtime);
	$('#starttime_0').css('border-color','#e8e8e8');
	$('#endtime_0').css('border-color','#e8e8e8');
	
   }else {
	$(".customstart").val('');
	$(".customend").val('');
   }

});

var m;
 function disableTime(m){

  
	var openClose = $('#open_close_'+ m).val();
	if(openClose == 'close') {
	$('#starttime_'+ m).prop('readonly',true).val('Close').css('background-color','#ccc');
	$('#endtime_'+ m).prop('readonly',true).val('Close').css('background-color','#ccc');
    }else {
	$('#starttime_'+ m).prop('readonly',false).css('background-color','#fff');
	$('#endtime_'+ m).prop('readonly',false).css('background-color','#fff');
	}

}


</script>

<script>

//window.location.reload(true);

/** map start*/


<?php if(isset($data['lattutude_lat'])): ?>
		var lattitude = "<?php echo $data['lattutude_lat'] ?>";
		<?php else: ?>
		var lattitude = 13.060422;
		<?php endif; ?>
		<?php if(isset($data['longitude_lng'])): ?>
		var longitude = "<?php echo $data['longitude_lng'] ?>";
		<?php else: ?>
		var longitude = 80.249583;
		<?php endif; ?>
var geocoder;
var map;
var marker;
var infowindow = new google.maps.InfoWindow({size: new google.maps.Size(150,50)});



	function initMap() {
		geocoder = new google.maps.Geocoder();
		console.log(geocoder);
		var latlng = new google.maps.LatLng(12.9516, 80.1462);
		
		var mapOptions = {
			zoom:14,   
			center : {lat: 13.060422, lng: 80.249583},
			mapTypeId: google.maps.MapTypeId.ROADMAP
		}

		
		var componentForm = {
		street_number: 'short_name',
		route: 'long_name',
		locality: 'long_name',
		//administrative_area_level_1: 'short_name',
		//country: 'long_name',
		postal_code: 'short_name'
     };
	


map = new google.maps.Map(document.getElementById('map'), mapOptions);

//var input = document.getElementById('searchInput'); 

//var autocomplete = new google.maps.places.Autocomplete(input);//

    var  autocomplete = new google.maps.places.Autocomplete(
    document.getElementById('searchInput'), {types: ['geocode']});

  

autocomplete.bindTo('bounds', map);

<?php if(isset($data['id']) && $data['id']): ?>
   //var address = "<?php echo $data['business_street'] ?>"; 
   var latlng = {lat: <?php echo $data['lattutude_lat'] ?>, lng: <?php echo $data['longitude_lng'] ?>};  
<?php else: ?>
   //var address = "crompet";
   var latlng = {lat: 13.0067, lng: 80.2206};
<?php endif; ?>
 


geocoder.geocode( { 'location': latlng}, function(results, status) {
		if (status == google.maps.GeocoderStatus.OK) {

			
            //console.log("hhhhh " + results[0].formatted_address);
	     	map.setCenter(results[0].geometry.location);
			if (marker) {
				marker.setMap(null);
				if (infowindow) infowindow.close();
			}
				marker = new google.maps.Marker({   
				map: map,
				draggable: true,
				position: results[0].geometry.location
				});
				google.maps.event.addListenerOnce(map, 'idle', function () {

				google.maps.event.trigger(map, 'resize');

		});
		google.maps.event.addListener(marker, 'dragend', function() {

			geocodePosition(marker.getPosition());
		});

		   google.maps.event.trigger(marker, 'click');
		} else {
		   alert('Geocode was not successful for the following reason: ' + status);
		}
});

autocomplete.addListener('place_changed', function() {



	        /** Autofiled address */

		var place = autocomplete.getPlace();

		for (var component in componentForm) {
			document.getElementById(component).value = '';
			document.getElementById(component).disabled = false;
		}

		// Get each component of the address from the place details,
		// and then fill-in the corresponding field on the form.
		for (var i = 0; i < place.address_components.length; i++) {
			var addressType = place.address_components[i].types[0];
			if (componentForm[addressType]) {
			var val = place.address_components[i][componentForm[addressType]];
			document.getElementById(addressType).value = val;
			}
		}

			/** End  */ 

			marker.setVisible(false);
			var place = autocomplete.getPlace();
			if (!place.geometry) {
		    	window.alert("No details available for input: '" + place.name + "'");
		    	return;
			}

			if (place.geometry.viewport) {
			    map.fitBounds(place.geometry.viewport);
			} else {
				map.setCenter(place.geometry.location);
				map.setZoom(17); // Why 17? Because it looks good.
			}
			marker.setPosition(place.geometry.location);
			marker.setVisible(true);

			var address = '';
			if (place.address_components) {
			address = [
			(place.address_components[0] && place.address_components[0].short_name || ''),
			(place.address_components[1] && place.address_components[1].short_name || ''),
			(place.address_components[2] && place.address_components[2].short_name || ''),
			(place.address_components[3] && place.address_components[3].short_name || ''),
			(place.address_components[4] && place.address_components[4].short_name || ''),
			(place.address_components[5] && place.address_components[5].short_name || '')
			].join(' ');
			}

			// document.getElementById('locationaddress').innerHTML=place.name+', '+address;
			document.getElementById('cityLat').value = place.geometry.location.lat();
		    document.getElementById('cityLng').value = place.geometry.location.lng();

});

}

function geocodePosition(pos) {
	geocoder.geocode({
	   latLng: pos
	}, function(responses) {

		var place = responses[0];
		
		var componentForm = { 
			street_number: 'short_name',
			route: 'long_name',
			locality: 'long_name',
			//administrative_area_level_1: 'short_name',
			//country: 'long_name',
			postal_code: 'short_name'
       };

                   for (var component in componentForm) {
						document.getElementById(component).value = '';
						document.getElementById(component).disabled = false;
					}

				
					for (var i = 0; i < place.address_components.length; i++) {
						var addressType = place.address_components[i].types[0];
						if (componentForm[addressType]) {
						var val = place.address_components[i][componentForm[addressType]];
						document.getElementById(addressType).value = val;
						}
					}
		
	if (responses && responses.length > 0) {
	     marker.formatted_address = responses[0].formatted_address;
	     console.log(responses);
	} else {
	   marker.formatted_address = 'Cannot determine address at this location.';
}

//document.getElementById('locationaddress').innerHTML=marker.formatted_address;
$('#locationaddress').val(marker.formatted_address);
$('#searchInput').val(marker.formatted_address);

	document.getElementById('cityLat').value=marker.getPosition().lat();
	document.getElementById('cityLng').value=marker.getPosition().lng();

});
}

 /** MAP CLOSE*/

 

 </script>

 

    <!--== breadcrumbs ==-->
				
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4>Add New Listing <a href="<?php echo e(url('businesslist')); ?>" class="add-button" style="margin-left: 63%;"> <i class="fa fa-list"></i> All Bussiness List</a></h4> 
						<!--<a class="dropdown-button drop-down-meta drop-down-meta-inn" href="#" data-activates="dr-list"><i class="material-icons">more_vert</i></a>
						<ul id="dr-list" class="dropdown-content">
							<li><a href="#!">Add New</a> </li>
							<li><a href="#!">Edit</a> </li>
							<li><a href="#!">Update</a> </li>
							<li class="divider"></li>
							<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
							<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
							<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
						</ul>-->
						<!-- Dropdown Structure -->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-inn-page">
					<div class="tab-inn ad-tab-inn">
						<div class="hom-cre-acc-left hom-cre-acc-right">
							<div class="">
								<?php echo Form::open(['url' => url('userpostbusiness'), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'businessform']); ?>

	


                              <input id="address" type="hidden" value="Suite LP34740 20-22 Wenlock Road London N1 7GU">
									<div class="row">
										<div class="input-field col s12">
											<select name="parent_id" id="parent_id" class="browser-default">
                            				<option value="">Select Category</option>
                            				<?php if($getall): ?>
                            					<?php $__currentLoopData = $getall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            					<option value="<?php echo e($val->id); ?>" <?php if( isset($data['category_id']) && $val->id == $data['category_id']) { ?>  selected='selected' <?php } ?> ><?php echo e($val->category_name); ?></option>
                            					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            				<?php endif; ?>
                            			</select>
										
										</div>
									
									</div>
								

									<?php if(isset($data['id']) && $data['sub_category_id'] !=""): ?>
									
									<div class="row" id="subcatdiv" style="">
										<div class="input-field col s12">
											<select name="subcat_id" id="subcat_id">
											<option value="0">Select Sub Category</option>	
											<?php if($getSubAll): ?>		
											<?php $__currentLoopData = $getSubAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            					<option value="<?php echo e($val->id); ?>" <?php if( isset($data['sub_category_id']) && $val->id == $data['sub_category_id']) { ?>  selected='selected' <?php } ?> ><?php echo e($val->category_name); ?></option>
                            					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>	
			                                </select>
										</div>
									</div>
									<?php else: ?>
									<div class="row" id="subcatdiv" style="display:none">
										<div class="input-field col s12">
											<select name="subcat_id" id="subcat_id">
											<option value="0">Select Sub Category</option>				
			                                </select>
										</div>
									</div>
									<?php endif; ?>
								

									<div class="row">
										<div class="input-field col s6">
										
												<?php echo Form::text('business_firstname',isset($data['business_first_name']) ? $data['business_first_name'] : "" ,array('placeholder'=>'Enter Your First Name')); ?>

												<label for="list_phone">First Name</label>
											
										</div>
										<div class="input-field col s6">
											<?php echo Form::text('business_lastname',isset($data['business_last_name']) ? $data['business_last_name'] : "",array('placeholder'=>'Enter Your Last Name')); ?>

											<label for="email">Last Name</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s6">
											<?php echo Form::text('business_email',isset($data['business_email']) ? $data['business_email'] : "",array('placeholder'=>'Enter Your Business Email')); ?>

											<label for="list_phone">Email</label>
										</div>
										<div class="input-field col s6">
											<?php echo Form::text('business_contactno',isset($data['business_contactno']) ? $data['business_contactno'] : "",array('placeholder'=>'Enter Your Contact No','maxlength'=>15)); ?>

											<label for="email">Contact Number</label>
										</div>
									</div>
									<!--<div class="row">
										<div class="input-field col s12">
											<?php echo Form::text('business_address','',array('placeholder'=>'Enter Your Address')); ?>

											<label for="list_addr">Address</label>
										</div>
									</div>-->
									
									<div class="row">
										<div class="input-field col s12">
											<?php echo Form::text('business_address',isset($data['business_address']) ? $data['business_address'] : "",array('placeholder'=>'Enter Your Address','id'=>'searchInput')); ?>

											<label for="list_addr">Location</label>
										</div>
									</div>
									<div class="row">
											<div id="map" style="width:98%; height:500px; margin:10px 10px; position:relative;border:1px solid #ccc;"></div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<?php echo Form::text('business_street',isset($data['business_street']) ? $data['business_street'] : "",array('id'=>'street_number','placeholder'=>'Enter Your Door no/Street Name/Floor no')); ?>

											<label for="list_st">Address</label>
										</div>
									</div>

									<div class="row">
										<div class="input-field col s12">
											<!--<select name="city_id">
                                				<option value="0">Select City</option>
                                				<?php if($getallcity): ?>
                                				<?php $__currentLoopData = $getallcity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                				<option value="<?php echo e($valcity->id); ?>"><?php echo e($valcity->city); ?></option>
                                				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                				<?php endif; ?>
                                			</select>-->
                                			<?php echo Form::text('locationAddress',isset($data['address_route']) ? $data['address_route'] : "",array('class'=>'address','id'=>'route','placeholder'=>'Address')); ?>

                                			
										</div>
										</div>

									<div class="row">
										<div class="input-field col s6">
											<!--<select name="city_id">
                                				<option value="0">Select City</option>
                                				<?php if($getallcity): ?>
                                				<?php $__currentLoopData = $getallcity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valcity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                				<option value="<?php echo e($valcity->id); ?>"><?php echo e($valcity->city); ?></option>
                                				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                				<?php endif; ?>
                                			</select>-->
                                			<?php echo Form::text('city_name',isset($data['city_name']) ? $data['city_name'] : "",array('class'=>'city_id','id'=>'locality','placeholder'=>'Enter your City','readonly' => 'true')); ?>

                                			<input type="hidden" id="cityLat" name="cityLat" value="<?php echo e(isset($data['lattutude']) ? $data['lattutude'] : ''); ?>"/>
                                            <input type="hidden" id="cityLng" name="cityLng" value="<?php echo e(isset($data['longitude']) ? $data['longitude'] : ''); ?>"/>
										</div>
										<div class="input-field col s6">
											<?php echo Form::text('pincode',isset($data['pincode']) ? $data['pincode'] : "",array('class'=>'pincode','id'=>'postal_code','placeholder'=>'Enter your pincode','maxlength'=>12)); ?>

											<label for="email">Pincode</label>
										</div>
									</div>
									<div class="row">
    									<div class="input-field col s12">
    											<?php echo Form::text('business_website',isset($data['business_website']) ? $data['business_website'] : "",array('placeholder'=>'Enter Your Business Website')); ?>

    											<label for="email">Website</label>
    									</div>
									</div>

									<div class="row">
														<div class="input-field col s12">
															<?php 
															$userType = [
																''=>'Select User Type',
																"1"=>"Free",
																"2"=>"Premium",
																"3"=>"Premium Plus",
																"4"=>"Ultra Premium Plus",
															];
															?>
															<?php echo e(Form::select('category_type',$userType, isset($data['modeofpay']) ? $data['modeofpay'] : "",['class'=>'validate ','id'=>'category_type'])); ?>

														
														</div>
													</div>
									
									<!--<div class="row">
										<div class="input-field col s12">
											<select>
												<option value="" disabled selected>Listing Type</option>
												<option value="1">Free</option>
												<option value="2">Premium</option>
												<option value="3">Premium Plus</option>
												<option value="3">Ultra Premium Plus</option>
											</select>
										</div>
									</div>-->
									<div class="row">
										<div class="input-field col s12">
											<?php echo Form::text('business_title',isset($data['business_title']) ? $data['business_title'] : "",array('placeholder'=>'Enter Your Business Title')); ?>

											<label for="list_phone">Business Title</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<?php echo Form::textarea('business_tags',isset($data['business_tag']) ? $data['business_tag'] : "",array('class'=>'materialize-textarea','rows' => 6,'placeholder'=>'Enter Your Business Tags')); ?>

											<label for="email">Business Tags</label>
										</div>
									</div>
									<div class="row">
										<div class="input-field col s12">
											<textarea name="business_desc" placeholder="Enter Your Business Desc"><?php echo e(isset($data['business_desc']) ? $data['business_desc'] : ""); ?></textarea>
                                            <script>
                                                CKEDITOR.replace( 'business_desc' );
                                            </script>
											<label for="list_addr">Business Desc</label>
										</div>
									</div>

									
									
									<div class="row">
										<div class="db-v2-list-form-inn-tit">
											<h5>Logo Image <span class="v2-db-form-note">(image size 100x100):<span></h5>
										</div>
									</div>

									<div class="row">												 
												  <div class="input-field col s3">
												  <?php 
												  $file = isset($data['thumbnail_img'])?$data['thumbnail_img']:"";
												  $path= public_path()."/upload/business/thumbnail/original/".$file; ?>
												   <?php if(isset($data['thumbnail_img']) && $data['thumbnail_img'] !="" && file_exists($path)): ?>
													  
													<img src="<?php echo e(asset('/public/upload/business/thumbnail/original/'.$data['thumbnail_img'])); ?>" width='130' height='120' id="logoImageId">
													<?php else: ?>
													<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="logoImageId">
													<?php endif; ?>
											      </div>
											 </div>
									<div class="row tz-file-upload">
										<div class="file-field input-field">
											<div class="tz-up-btn" style="width: 130px;"> <span>File</span>
												<input type="file" name="business_image" id="business_image"> </div>
											<div class="file-path-wrapper db-v2-pg-inp">
												<input class="file-path validate" type="text" name="business_image_filename" id="business_image_filename" value="<?php echo isset($data['thumbnail_img']) ? $data['thumbnail_img'] : ""  ?>"> 
											</div>
											
											<span id="logoErrorMsg"></span>
										
										</div>
									</div>
									
									<div class="row">
										<div class="db-v2-list-form-inn-tit">
											<h5>Cover Image <span class="v2-db-form-note">(image size 1350x500):<span></h5>
										</div>
									</div>

									<div class="row">												 
												  <div class="input-field col s3">
												  <?php 
												  $fileBanner = isset($data['banner_img'])?$data['banner_img']:"";
												  $pathBannner= public_path()."/upload/business/banner/original/".$fileBanner; ?>

												   <?php if(isset($data['banner_img']) && $data['banner_img'] !="" && file_exists($pathBannner)): ?>
													  
													<img src="<?php echo e(asset('/public/upload/business/banner/original/'.$data['banner_img'])); ?>" width='130' height='120' id="imageId">
													<?php else: ?>
													<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="bannerImageId">
													<?php endif; ?>
											      </div>
											 </div>
									<div class="row tz-file-upload">
										<div class="file-field input-field">
											<div class="tz-up-btn" style="width: 130px;"> <span>File</span>
												<input type="file" name="business_banner" id="business_banner"> </div>
											<div class="file-path-wrapper db-v2-pg-inp">
												<input class="file-path validate" type="text" name="business_banner_filename" value="<?php echo isset($data['banner_img']) ? $data['banner_img'] : ""  ?>"> 
											</div>
											<span id="bannerErrorMsg"></span> 
										</div>
									</div>
									
									<div class="row">
										<div class="db-v2-list-form-inn-tit">
											<h5>Photo Gallery <span class="v2-db-form-note">(upload multiple photos note:size 750x500):<span></h5>
										</div>
									</div>
									<span id="imgDeleteMsg"></span>
									<!--<div class="input-field col s3">
									<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="image1">
									</div>-->
									<?php if(isset($getGallaryimages)): ?>
									     <div class="row">
										  <?php $__currentLoopData = $getGallaryimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									                  <div class="input-field col s3" id="imageOuterDiv_<?php echo e($img->id); ?>">											        
														<?php 
													    $file = isset($img->image_name) ? $img->image_name:"";
														$path= public_path()."/upload/business/gallary/original/".$file; ?>
														<?php if(isset($img->image_name) && $img->image_name !="" && file_exists($path)): ?>
														
    
														<div class="thumbnailccc">
														  <img src="<?php echo e(asset('/public/upload/business/gallary/original/'.$img->image_name)); ?>" width='130' height='120'>
														  <a href="javascript:void(0)" onClick="deleteImage(<?php echo e($img->id); ?>)" class="delete"><i class="fa fa-times-circle" aria-hidden="true" style="background-color: #f00;color: #fff;"></i></a>
														</div>
														<?php else: ?>
														<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120'>
														<?php endif; ?>
														</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
														
														
											     </div>
												 <?php endif; ?>

							 <div id="addMoreRow" style="<?= count($getGallaryimages) == 5 ? 'display :none' : '';?>">

									<div class="row tz-file-upload append-div">
										<div class="file-field input-field">
											<div class="tz-up-btn" style="width: 130px;"> <span>File</span>
												<input type="file" multiple name="filename[]" class="gallaryImage" id="gallaryInputId1">
												
												 </div>
											<div class="file-path-wrapper db-v2-pg-inp">
												<input class="file-path validate" name="gallary1" type="text" style="width: 82%;"> 
												<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='50' height='46' id="gallaryImage1">
											</div>
											
											<span id="gallaryErrorMsg1"></span> 
										</div>
									</div>	
									<br/>
									<div class="row">
										<div class="db-v2-list-form-inn-tit">
										<a href="javascript:void(0)" class="add-button" onClick="addRow()" style="float:left;margin-left: 23%;"> <i class="fa fa-plus" style="color:#fff;border:none"></i> Add more</a>
										</div>
									</div>
									</div>

									<!--- ABOUT BUSINESS IMAGE UPLOAD START----->

									<div class="row">
										<div class="db-v2-list-form-inn-tit">
											<h5>About Business Image <span class="v2-db-form-note">(image size 1000x500):<span></h5>
										</div>
									</div>

									<div class="row">												 
												  <div class="input-field col s3">
												  <?php 
												  $fileBanner = isset($data['about_business_img'])?$data['about_business_img']:"";
												  $pathBannner= public_path()."/upload/business/aboutbusiness/".$fileBanner; ?>

												   <?php if(isset($data['about_business_img']) && $data['about_business_img'] !="" && file_exists($pathBannner)): ?>
													  
													<img src="<?php echo e(asset('/public/upload/business/aboutbusiness/'.$data['about_business_img'])); ?>" width='130' height='120' id="aboutImageId">
													<?php else: ?>
													<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" width='130' height='120' id="aboutImageId">
													<?php endif; ?>
											      </div>
											 </div>
									<div class="row tz-file-upload">
										<div class="file-field input-field">
											<div class="tz-up-btn" style="width: 130px;"> <span>File</span>
												<input type="file" name="about_business_img" id="about_business_img"> </div>
											<div class="file-path-wrapper db-v2-pg-inp">
												<input class="file-path validate" type="text" name="about_business_img_filename" value="<?php echo isset($data['about_business_img']) ? $data['about_business_img'] : ""  ?>"> 
											</div>
											<span id="aboutErrorMsg"></span> 
										</div>
									</div>


									<!--- ABOUT BUSINESS IMAGE UPLOAD END----->

									
									<div class="row">
										<div class="db-v2-list-form-inn-tit">
											<h5>Time Operation </h5>
											<div class="col s12 hom-cr-acc-check">
									      <input type="checkbox" id="test5" name="checkAll">
									       <label for="test5"  style="font-weight: 600;float: right;margin-top: -30px;"> Fill all</label>
								         </div>	
										</div>
									</div>
									
									<div class="row">
									    <?php 
                                            $i = 0;
                                            for($i=0;$i<7;$i++){  
                                             
											
												$find = array_search($i,$working_days);
												
												if($find) {
													$details = DB::table('tbl_workingday')->where('id',$find)->first();
													//echo "<pre>";print_r($details); echo "</pre>";
												
                                        ?>
										<div class="input-field col s3">
											<select name="week_days[<?php echo e($i); ?>]">
                                				<option value="">Select Days</option>
	                                             <option value="Monday" <?php if($details->week_day == 'Monday') {?> selected='selected' <?php } ?>>Monday</option>
                                				<option value="Tuesday" <?php if($details->week_day == 'Tuesday') {?> selected='selected' <?php } ?>>Tuesday</option>
                                				<option value="Wednesday" <?php if($details->week_day == 'Wednesday') {?> selected='selected' <?php } ?>>Wednesday</option>
                                				<option value="Thursday" <?php if($details->week_day == 'Thursday') {?> selected='selected' <?php } ?>>Thursday</option>
                                				<option value="Friday" <?php if($details->week_day == 'Friday') {?> selected='selected' <?php } ?>>Friday</option>
                                				<option value="Saturday" <?php if($details->week_day == 'Saturday') {?> selected='selected' <?php } ?>>Saturday</option>
                                				<option value="Sunday" <?php if($details->week_day == 'Sunday') {?> selected='selected' <?php } ?>>Sunday</option>
                                			</select>
										</div>
										<div class="input-field col s3">
											<select name="open_close[<?php echo e($i); ?>]" id="open_close_<?php echo e($i); ?>" onchange="disableTime(<?php echo e($i); ?>)">                                				
	                                             <option value="open" <?php if($details->open_close == 'open') {?> selected='selected' <?php } ?>>Open</option>
                                				 <option value="close" <?php if($details->open_close == 'close') {?> selected='selected' <?php } ?>>Close</option>
                                				
                                			</select>
										</div>
										<?php 
										$customStart = '';
										$customEnd = '';
										
										if($i > 0) {
											$customStart = 'customstart';
											$customEnd = 'customend';
										}

										if($details->open_close == 'close'){
											 $readOnly =true;
											 $background = "#ccc";
										}else {
											$readOnly = false;
											$background = "#fff";
										}
										 ?>
										<div class="input-field col s3">
											<?php echo Form::text('starttime['.$i.']',isset($details->week_start_time)?$details->week_start_time:"",array('class'=>'starttime '.$customStart,'id'=>"starttime_".$i,'placeholder'=>'Start Time','style'=>'background-color:'.$background,'readonly'=>$readOnly)); ?>

										</div>
										<div class="input-field col s3">
    										<?php echo Form::text('endtime['.$i.']',isset($details->week_end_time)?$details->week_end_time:"",array('class'=>'endtime '.$customEnd,'id'=>"endtime_".$i,'placeholder'=>'End Time','style'=>'background-color:'.$background,'readonly'=>$readOnly)); ?>

									    </div>
										<?php } else { ?>
											<div class="input-field col s3">
											<select name="week_days[<?php echo e($i); ?>]">
                                				<option value="" >Select Days</option>
										        <option value="Monday" <?= $i == '0' ? 'selected' : ""?>>Monday</option>
                                				<option value="Tuesday" <?= $i == '1' ? 'selected':""?> >Tuesday</option>
                                				<option value="Wednesday" <?= $i == '2' ? 'selected':"" ?>>Wednesday</option>
                                				<option value="Thursday" <?= $i == '3' ? 'selected':"" ?>>Thursday</option>
                                				<option value="Friday" <?= $i == '4' ? 'selected':"" ?>>Friday</option>
                                				<option value="Saturday" <?= $i == '5' ? 'selected':"" ?>>Saturday</option>
                                				<option value="Sunday" <?= $i == '6' ? 'selected':"" ?>>Sunday</option>
                                			</select>
										</div>
										<div class="input-field col s3">
											<select name="open_close[<?php echo e($i); ?>]" id="open_close_<?php echo e($i); ?>" onchange="disableTime(<?php echo e($i); ?>)">                                				
	                                             <option value="open">Open</option>
                                				 <option value="close">Close</option>
                                				
                                			</select>
										</div>

										<?php 
										$customStart = '';
										$customEnd = '';
										
										if($i > 0) {
											$customStart = 'customstart';
											$customEnd = 'customend';
										}
										 ?>
										  
										
										<div class="input-field col s3">
										
											<?php echo Form::text('starttime['.$i.']','',array('class'=>'starttime '.$customStart,'id'=>"starttime_".$i,'placeholder'=>'Start Time')); ?>

										</div>
										<div class="input-field col s3">
    										<?php echo Form::text('endtime['.$i.']','',array('class'=>'endtime '.$customEnd,'id'=>"endtime_".$i,'placeholder'=>'End Time')); ?>

										</div>
										
										<?php if($i == 12): ?>
										
                                        <div class="input-field col s3" style="margin-left: -38px;margin-top: -18px;">
										<div class="col s12 hom-cr-acc-check">
									      <input type="checkbox" id="test5" name="checkAll">
									       <label for="test5"  style="font-weight: 600;"> Fill all</label>
								         </div>	
										 </div>	
										 <?php endif; ?>
												
	                                 <?php } }?>		
                                           
									</div>  
									
									<?php
									$selected = "";
									if(isset($data['status'])){
										if($data['status'] == 1){
											$selected=1;
										}elseif($data['status'] == 2){
											$selected=2;
										}
									}
									?>
									<div class="row">
										<div class="input-field col s12">
											<select name="business_status">
												<option value="">Select Status</option>
                                				<option value="1" <?= $selected == 1 ? 'selected' : ""?>>Active</option>
                                				<option value="2" <?= $selected == 2 ? 'selected' : ""?>>Non-Active</option>
											</select>
										</div>
									</div>
									
									<?php echo e(Form::hidden('id',isset($data['id']) ? $data['id'] : "",['class'=>'validate','id'=>'list_addr'])); ?>

						
									<div class="row">
										<div class="input-field col s12 v2-mar-top-40"> 
										<button type="submit" class="waves-effect waves-light btn-large full-btn">Submit Listing & Pay</button>
										</div>
									</div>
								</form>
							</div>
						</div>
									
									</div>
								</div>
							
							</div>
						</div>
					</div>
				</div>
				
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/userbusinessadd.blade.php ENDPATH**/ ?>