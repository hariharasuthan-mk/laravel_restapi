<?php $__env->startSection('content'); ?>

<div class="tz-2-com tz-2-main">
					<h4>Check Out</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Check Out Listing</h2>
							<p>All the Lorem Ipsum generators on the All the Lorem Ipsum generators on the</p>
						</div>
						<form action="#">
						<div class="list-check-out">
<div class="home-list-pop list-spac list-check-out-inn">
									<!--LISTINGS IMAGE-->
									<div class="col-md-3"> <img src="<?php echo e(asset('public/images/services/s10.jpg')); ?>" alt=""> </div>
									<!--LISTINGS: CONTENT-->
									<div class="col-md-9 home-list-pop-desc inn-list-pop-desc"><h3>Property Luxury Homes</h3>
										<div class="list-number">
											<ul>
												<li><b>Price</b>: $15</li>
												<li><b>Duration</b>: 6 Months</li>
												<li><b>Date</b>: 07 Nov 2017</li>
												<li><b>Category</b>: Real Estate</li>
											</ul>
										</div>
									</div>
								</div>						
						</div>
							<div class="chec-out-pay">
								<h5>Select Payment Gateway</h5>
								<input name="group1" type="radio" id="pay1" />
								<label for="pay1"><img src="<?php echo e(asset('public/images/pay1.png')); ?>" alt=""></label>
								<input name="group1" type="radio" id="pay2" />
								<label for="pay2"><img src="<?php echo e(asset('public/images/pay2.png')); ?>" alt=""></label>								
								<input name="group1" type="radio" id="pay3" />
								<label for="pay3"><img src="<?php echo e(asset('public/images/pay3.png')); ?>" alt=""></label>
								<input name="group1" type="radio" id="pay4" />
								<label for="pay4"><img src="<?php echo e(asset('public/images/pay4.png')); ?>" alt=""></label>																
							</div>
						</form>
						<div class="db-mak-pay-bot">
							<a href="#!" class="waves-effect waves-light btn-large">Proceed checkout</a> </div>
					</div>
				</div>
				
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/checkout.blade.php ENDPATH**/ ?>