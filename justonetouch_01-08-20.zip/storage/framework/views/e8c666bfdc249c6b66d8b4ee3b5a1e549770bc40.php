<?php $__env->startSection('content'); ?>
<style>
.timespan {
	float: right;
    margin-top: -31px;
    background-color: #ccc;
    padding: 1px 14px;
}
</style>

<div class="tz-2-com tz-2-main">
					<h4><?php echo e($businessDetails->business_title); ?></h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Reviews</h2>
							<p>Review approve, edit, delete and review replay options here..</p>
						</div>
						<div class="tz-mess">
							<ul>
							    <?php if(!empty($reviewList)): ?>
							    <?php $__currentLoopData = $reviewList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reviewval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    <?php if(!empty($reviewval)): ?>
								<li class="view-msg">
									<h5><img src="<?php echo e(asset('public/images/users/1.png')); ?>" alt="" /><?php echo e($reviewval->first_name); ?> 
									 

									<span class="tz-revi-star" style="color:#64addb"><strong><?php echo e($reviewval->rating); ?></strong> <i class="fa fa-star" aria-hidden="true"></i></span>
									
									</h5>
									<!--<span class="timespan"><?php echo e(Carbon\Carbon::parse($reviewval->created_at)->diffForHumans()); ?></span>-->
									<span class="timespan"><?php echo e(date("d-M-Y h:i:s",strtotime($reviewval->created_at))); ?></span>
									<p><?php echo e($reviewval->comment); ?></p>
									
									<div class="hid-msg"><a href="#!"><i class="fa fa-check" title="approve this review"></i></a><a href="#!"><i class="fa fa-edit" title="edit"></i></a><a href="#!"><i class="fa fa-trash" title="delete"></i></a><a href="#!"><i class="fa fa-reply edit-replay" title="replay"></i></a>
										<form class="col s12 hide-box">
											<div class="">
												<div class="input-field col s12">
													<textarea class="materialize-textarea"></textarea>
													<label>Write your replay</label>
												</div>
												<div class="input-field col s12">
													<input type="submit" value="Submit" class="waves-effect waves-light btn-large"> </div>
											</div>
										</form>
									</div>
								</li>
							        <?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
							<?php else: ?>
							<li class="view-msg">
									<h5>No Reviews Found</h5>
							</li>
							<?php endif; ?>
							</ul>
						</div>
						
					</div>
				</div>
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/reviewlist.blade.php ENDPATH**/ ?>