<div class="sb2-1">
				<!--== USER INFO ==-->
				<div class="sb2-12">
				    
					<ul>
						 <?php if(Request::user()->user_image): ?>
						<li><img src="<?php echo e(Request::user()->user_image_path); ?>/thumbnail/<?php echo e(Request::user()->user_image); ?>" alt="" style="border-radius: 50% !important;"/> </li>
						<?php else: ?>
						<li><img src="<?php echo e(asset('public/images/users/2.png')); ?>" alt=""> </li>
						<?php endif; ?>
						<li>
							<h5><?php echo e(Request::user()->first_name); ?> <span> <?php echo e(Request::user()->email); ?></span></h5> </li>
						<li></li>
					</ul>
				</div>
				<!--== LEFT MENU ==-->
				<div class="sb2-13">
					<ul class="collapsible" data-collapsible="accordion">
						<li><a href="<?php echo e(url('admin/dashboard')); ?>" class="menu-active"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard</a> </li>
						<li class="<?php echo e((Request::is('admin/businesslist') || Request::is('admin/addbusiness')|| Request::is('admin/categorylist')|| Request::is('admin/addcategory') ? 'active' : '')); ?>"><a href="javascript:void(0)" class="collapsible-header <?php echo e((Request::is('admin/businesslist') || Request::is('admin/addbusiness')|| Request::is('admin/categorylist')|| Request::is('admin/addcategory') ? 'active' : '')); ?>"><i class="fa fa-list-ul" aria-hidden="true"></i> Listing</a>
							<div class="collapsible-body left-sub-menu" style="<?php echo e((Request::is('admin/businesslist') || Request::is('admin/addbusiness')|| Request::is('admin/categorylist')|| Request::is('admin/addcategory') ? 'display: block' : '')); ?>">
							    
								<ul>
									<li><a href="<?php echo e(url('admin/businesslist')); ?>">All listing</a> </li>
									<li><a href="<?php echo e(url('admin/addbusiness')); ?>">Add New listing</a> </li>
									<li><a href="<?php echo e(url('admin/categorylist')); ?>">All listing Categories</a> </li>
									<li><a href="<?php echo e(url('admin/addcategory')); ?>">Add listing Categories</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-user" aria-hidden="true"></i> Users</a>
							<div class="collapsible-body left-sub-menu">
								<ul>
									<li><a href="<?php echo e(url('admin/userlist')); ?>">All Users</a> </li>
									<li><a href="<?php echo e(url('admin/useradd')); ?>">Add New user</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="<?php echo e(url('admin/analytics')); ?>"><i class="fa fa-bar-chart" aria-hidden="true"></i> Analytics</a> </li>
						<li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-buysellads" aria-hidden="true"></i>Ads</a>
							<div class="collapsible-body left-sub-menu">
								<ul>
									<li><a href="<?php echo e(url('admin/adslist')); ?>">All Ads</a> </li>
									<li><a href="<?php echo e(url('admin/adsadd')); ?>">Create New Ads</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="<?php echo e(url('admin/paymentlist')); ?>"><i class="fa fa-usd" aria-hidden="true"></i> Payments</a> </li>
						<li><a href="<?php echo e(url('admin/earnings')); ?>"><i class="fa fa-money" aria-hidden="true"></i> Earnings</a> </li>
						<li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-bell-o" aria-hidden="true"></i>Notifications</a>
							<div class="collapsible-body left-sub-menu">
								<ul>
									<li><a href="<?php echo e(url('admin/allnotification')); ?>">All Notifications</a> </li>
									<li><a href="<?php echo e(url('admin/usernotification')); ?>">User Notifications</a> </li>
									<li><a href="<?php echo e(url('admin/pushnotification')); ?>">Push Notifications</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-tags" aria-hidden="true"></i> List Price</a>
							<div class="collapsible-body left-sub-menu">
								<ul>
									<li><a href="<?php echo e(url('admin/pricelist')); ?>">All List Price</a> </li>
									<li><a href="<?php echo e(url('admin/priceadd')); ?>">Add New Price</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-rss" aria-hidden="true"></i> Blog & Articals</a>
							<div class="collapsible-body left-sub-menu">
								<ul>
									<li><a href="<?php echo e(url('admin/bloglist')); ?>">All Blogs</a> </li>
									<li><a href="<?php echo e(url('admin/blogadd')); ?>">Add Blog</a> </li>
								</ul>
							</div>
						</li>
						<li><a href="<?php echo e(url('admin/adminsetting')); ?>"><i class="fa fa-cogs" aria-hidden="true"></i> Setting</a> </li>
						<li><a href="<?php echo e(url('admin/socialmedia')); ?>"><i class="fa fa-plus-square-o" aria-hidden="true"></i> Social Media</a> </li>
					</ul>
				</div>
			</div><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/admin/layout/sidenav.blade.php ENDPATH**/ ?>