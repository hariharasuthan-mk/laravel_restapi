<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/materialize.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/style.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/bootstrap.css')); ?>" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/responsive.css')); ?>" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<style>
	    .typeahead-search {
    position: relative;
}

.dropdown-menu {
    width: 100%;
}
	</style>
		<?php echo $__env->make('frontend.businessadmin.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
		<!--HEADER VISITOR SECTION-->
	<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--END HEADER VISITOR SECTION -->	
</head>

<body style="background-color:#ff290033">
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<!--TOP SEARCH SECTION-->
		<?php echo $__env->make('frontend.businessadmin.layout.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<section class="dir-pa-sp-top">
		<div class="container">
			<div class="row">
				<div class="dir-alp-tit">
					<?php if($getcatRs->banner_img): ?> 
					<img src="<?php echo e(asset('public/upload/category/banner')); ?>/<?php echo e($getcatRs->banner_img); ?>" alt="" style="width:1024px !important;height:250px !important;" />
					<?php else: ?>
					<img src="https://www.justdial.com/public/images/b_268.jpg" alt="" style="width:1024px !important;height:250px !important;" />
					<?php endif; ?>
				</div>
			</div>
			<div class="row">
				<div class="dir-alp-con" style="width:1024px !important;">
					
					<div class="col-md-12 dir-alp-con-right">
						<div class="dir-alp-con-right-1">
							<div class="row">
								<!--LISTINGS-->
								<?php if($getallsub): ?>
    								<?php $__currentLoopData = $getallsub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    								
    								<div class="home-list-pop list-spac">
									<!--LISTINGS IMAGE-->
									<div class="col-md-3 list-ser-img" align="right"><img src="<?php echo e(asset('public/upload/category/original')); ?>/<?php echo e($val->category_image); ?>" alt="" style="width:50px !important;height:45px !important;" /> </div>
									<!--LISTINGS: CONTENT-->
									<div class="col-md-6 home-list-pop-desc inn-list-pop-desc"> <a href="<?php echo e(url('searchlist')); ?>/<?php echo e($val->id); ?>/<?php echo e($val->category_slug); ?>"><h3 style="font-size: 1.17em !important;"><?php echo e($val->category_name); ?></h3></a>
										<span class="home-list-pop-rat" style="background-color: #ff2900;!important;">>></span>
									</div>
									<div class="col-md-3 list-ser-img"> </div>
								    </div>
    								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    							<?php endif; ?>
								<!--LISTINGS END-->
								
								
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!--FOOTER SECTION-->
	<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--COPY RIGHTS-->
	<section class="copy" style="background-color: #ff290033;color: #000 !important;">
		<div class="container">
			<p>copyrights © <span id="cryear">2019</span> justonetouch.in &nbsp;&nbsp;All rights reserved. </p>
		</div>
	</section>
	<!--QUOTS POPUP-->
	<section>
		<!-- GET QUOTES POPUP -->
		<div class="modal fade dir-pop-com" id="list-quo" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header dir-pop-head">
						<button type="button" class="close" data-dismiss="modal">×</button>
						<h4 class="modal-title">Get a Quotes</h4>
						<!--<i class="fa fa-pencil dir-pop-head-icon" aria-hidden="true"></i>-->
					</div>
					<div class="modal-body dir-pop-body">
						<form method="post" class="form-horizontal">
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Full Name *</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="fname" placeholder="" required> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Mobile</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="mobile" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Email</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="email" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Message</label>
								<div class="col-md-8 get-quo">
									<textarea class="form-control"></textarea>
								</div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<div class="col-md-6 col-md-offset-4">
									<input type="submit" value="SUBMIT" class="pop-btn"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- GET QUOTES Popup END -->
		<!-- REQUIREMENT Popup END -->
		<!--<div class="req-pop">
			<div class="req-pop-in">
				<div class="req-pop-lhs">
					<h4>Why should I fill this?</h4>
					<ul>
						<li>
							<img src="<?php echo e(asset('public/images/icon/d1.png')); ?>" alt="">
							<p>Receive advertiser details instantly</p>
						</li>
						<li>
							<img src="<?php echo e(asset('public/images/icon/d2.png')); ?>" alt="">
							<p>Discover new projects/properties to <br>your liking via email/sms</p>
						</li>
						<li>
							<img src="<?php echo e(asset('public/images/icon/d3.png')); ?>" alt="">
							<p>Our experts will get in touch to help<br> you out when required</p>
						</li>
					</ul>
				</div>
				<div class="req-pop-rhs">
					<i class="fa fa-times req-pop-clo"></i>
					<!---===SECTION 1===--->
					<!--<div class="req-pop-sec-1">
						<h2>What you looking for?</h2>
						<p>Choose your category what you looking for</p>
						<div class="v8-chbox">
							<form>
								<ul>
									<li>
									  <input type="checkbox" id="look-1">
									  <label for="look-1">Hotel room booking</label>
									</li>
									<li>
									  <input type="checkbox" id="look-2">
									  <label for="look-2">Realestates</label>
									</li>
									<li>
									  <input type="checkbox" id="look-3">
									  <label for="look-3">Hospitals</label>
									</li>
									<li>
									  <input type="checkbox" id="look-4">
									  <label for="look-4">Property buy, sell & rent</label>
									</li>
									<li>
									  <input type="checkbox" id="look-5">
									  <label for="look-5">Automobiles</label>
									</li>
									<li>
									  <input type="checkbox" id="look-6">
									  <label for="look-6">Tution centeres</label>
									</li>
									<li>
									  <input type="checkbox" id="look-7">
									  <label for="look-7">Spa and massage centeres</label>
									</li>
									<li>
									  <input type="checkbox" id="look-8">
									  <label for="look-8">IT training centers</label>
									</li>
									<li>
									  <input type="checkbox" id="look-9">
									  <label for="look-9">Sports training</label>
									</li>
									<li>
									  <input type="checkbox" id="look-10">
									  <label for="look-10">Cab booking services</label>
									</li>
									<li>
									  <input type="checkbox" id="look-11">
									  <label for="look-11">Bike and car mechanics</label>
									</li>
									<li>
									  <input type="checkbox" id="look-12">
									  <label for="look-12">Home appliances</label>
									</li>
								</ul>
							</form>
						</div>
						<span class="req-nxt req-nxt-1">Next</span>
					</div>
					<!---===END SECTION 1===--->
					<!---===SECTION 2===--->
					<!--<div class="req-pop-sec-2">
						<h2>Fill this form</h2>
						<p>Choose your category what you looking for</p>
						<div class="v8-inputs">
							<form>
								<ul>
									<li>
									  <input type="textbox" placeholder="Enter your name" required>
									</li>
									<li>
									  <input type="textbox" placeholder="Enter your email">
									</li>
									<li>
									  <input type="textbox" placeholder="Enter your mobile number">
									</li>
									<li>
									  <span class="rer-sub-btn">Submit</span>
									</li>
								</ul>
							</form>
						</div>
						<span class="req-nxt req-nxt-1">Next</span>
					</div>
					<!---===END SECTION 2===--->
					<!---===SECTION 2===--->
					<!--<div class="req-pop-sec-3">
						<div>
							<h2>Success!</h2>
							<p>Thanks for contacting us! We will get in touch with you shortly</p>
							<img src="<?php echo e(asset('public/images/thank-you.png')); ?>">
						</div>
					</div>
					<!---===END SECTION 2===--->
				<!--</div>
			</div>
		</div>-->
		<!-- REQUIREMENT Popup END -->
	</section>
	
</body>
</html><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/subcategorylist.blade.php ENDPATH**/ ?>