<?php $__env->startSection('content'); ?>
<style>
    .field-icon {
  float: right;
  margin-left: -25px;
  margin-top: -25px;
  position: relative;
  z-index: 2;
}
</style>
<script>
$(document).ready(function() {

    $(".toggle-password").click(function() {

  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }
});
});
</script>
<div class="tz-2-com tz-2-main">
					<h4>Profile</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Edit Profile</h2>
						</div>
						<div class="tz2-form-pay tz2-form-com">
							<form class="col s12" method="post" action="<?php echo e(url('profileupdate')); ?>" enctype="multipart/form-data">
							    <?php echo e(csrf_field()); ?>

								<div class="row">
									<div class="input-field col s12">
										<input type="text" class="validate" name="firstname" value="<?php echo e($profileRs->first_name); ?>">
										<label>First Name</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12 m6">
									<input id="password-field" type="password" name="password" class="form-control" name="password" value="<?php echo e($profileRs->password_str); ?>">
              <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
										<label>Enter Password</label>
									</div>
									<div class="input-field col s12 m6">
										 <input id="password-field" type="password" name="confirmpass" class="form-control" name="password" value="<?php echo e($profileRs->password_str); ?>">

										<label>Confirm Password</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12 m6">
										<input type="email" class="validate" name="email" value="<?php echo e($profileRs->email); ?>">
										<label>Email id</label>
									</div>
									<div class="input-field col s12 m6">
										<input type="number" class="validate" name="mobile" value="<?php echo e($profileRs->mobile_no); ?>">
										<label>Phone</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<input type="text" class="validate" name="address" value="<?php echo e($profileRs->address); ?>">
										<label>Address</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<select name="status">
											<option value="0" selected>Select Status</option>
											<option value="1">Active</option>
											<option value="2">Non-Active</option>
										</select>
									</div>
								</div>
								<div class="row tz-file-upload">
									<div class="file-field input-field">
										<div class="tz-up-btn"> <span>File</span>
											<input type="file" name="profile_image"> </div>
										<div class="file-path-wrapper">
											<input class="file-path validate" type="text"> </div>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<input type="submit" value="SUBMIT" class="waves-effect waves-light full-btn"> </div>
								</div>
							</form>
						</div>
						<div class="db-mak-pay-bot">
					</div>
				</div>
		</div>		
				<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.businessadmin.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/businessadmin/pages/profileedit.blade.php ENDPATH**/ ?>