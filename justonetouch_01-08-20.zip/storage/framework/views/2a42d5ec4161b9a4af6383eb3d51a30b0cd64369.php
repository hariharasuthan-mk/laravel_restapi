<!--SCRIPT FILES-->
	<script src="<?php echo e(asset('public/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/bootstrap.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/materialize.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
	<?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/admin/layout/scripts.blade.php ENDPATH**/ ?>