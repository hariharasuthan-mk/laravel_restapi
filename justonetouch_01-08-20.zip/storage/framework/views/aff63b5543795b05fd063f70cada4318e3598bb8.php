<!DOCTYPE html>
<html lang="en">
<head>
		<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/font-awesome.min.css')); ?>" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/materialize.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/style.css')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/bootstrap.css')); ?>" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/css/responsive.css')); ?>" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	<?php echo $__env->make('frontend.businessadmin.layout.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


	<style>
	    .typeahead-search {
    position: relative;
}

.dropdown-menu {
    width: 100%;
}
.jconfirm-content {
	font-size : 14px;
}
.log-in-pop-right {
    float: none;
    width: 100%;
    padding: 50px;
}
.error{
	color:#F00;
	font-size:12px;
}

.log-in-pop-right input {
 border: 1px solid #dfdfdf; 
     padding: 8px; 
     box-sizing: border-box; 
     height: 45px; 
     border-radius: 2px; 
     font-size: 15px; 
     color: #636363; 
}
.log-in-btn {
    background: #f4364f;
    color: #fff;
    padding: 8px 14px;
    font-weight: 600;
    font-size: 13px;
}

.field-icons {
	float: right;
    margin-top: -29px;
    margin-right: 11px;
    position: inherit;   
    font-size: 15px;
	
}
}
	</style>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

	<script>


function viewConfirmPassword(){
	if($('#password').attr('type') =='password'){
		$('#password').attr('type','text');
		$('.field-icons').removeClass('fa-eye-slash').addClass('fa-eye');
	}else{
		$('#password').attr("type",'password');
		$('.field-icons').removeClass('fa-eye').addClass('fa-eye-slash');
	}
}

	$(document).ready(function () {

$("#LoginForm").validate({
	errorElement: "div",
	//set the rules for the field names

	rules: {
		mobile_no : {
			required: true,
		},
		password: {
			required: true
		},
		
	},
	//set messages to appear inline
	messages: {

		mobile_no : {
			required : "Please select the category."
		},
	 
		password: {
			required : "First name is required"
		},
	},
	errorPlacement: function (error, element) {
		error.appendTo(element.parent());
	}
});
});
	</script>
	<script>
	//initialize all modals
$('.modal').modal({
    dismissible: true
});


    function openImage() {
		$("#myModalAbout").modal({
				show : true,
				keyboard : false,
				backdrop : 'static'
			});
	}
	



$(document).ready(function () {   
    $('body').on('click','#submitreview', function() {
        
        var username = '<?php echo e(@Request::user()->id); ?>';
        //alert(username);
        
        if(username=="")
        {
            $("#myModal").modal({
				show : true,
				keyboard : false,
				backdrop : 'static'
			});
            //alert("Please log in or sign up to continue");
			//$('#myModal').modal('open');
            return false;
        }
		

		var reviews = $("textarea[name=reviews]").val();;
		
		if(reviews == ""){

			$.alert({
				title : "Warning!",
				content : "Please enter the review.",
			});
			
			
			return false;
		}

        var form = $('#reviewForm');
        var formData = form.serializeArray();
        console.log(formData);
        //$('#loader').show();
        $.ajax({
            type: 'get',
            url: "<?php echo e(url('reviewFormpost')); ?>",
            data: formData,
            dataType: "json",
            "_token": "<?php echo csrf_token(); ?>",
            success: function (data) {
                if (data.result == true) {
                    //hide_animation();
                    //$('#Result').remove();
                    $('#proadd').html(data.formData);
                    $('#ratingcnt').html("<span>"+data.finalAvgrating+"<i class='fa fa-star' aria-hidden='true'></i></span> based on "+data.reviewcnt+" reviews");
                    $('#content').val("");
					$("textarea[name=reviews]").val('');
					//$("input[name=rating]").val('');
					$("input[name=rating]").prop("checked", false);
					$('#successMsg').show().text('Your review saved successfully.').css('color','#45a745').delay(3000).fadeOut();

                } else {

                    $('#proadd').remove();

                    //$('#Result').show();

                }

            }
        });
    });
});

$(document).on("click", ".open-AddBookDialog", function () {
     var myBusinessId = $(this).data('id');
     //alert(myBookId);
     $(".modal-body #businessid").val( myBusinessId );
});
$(document).on("click", "#submitquote", function(event){
    //alert( "GO" ); 
        var form = $('#quoteForm');
        var formData = form.serializeArray();
        //console.log(formData);
        //$('#loader').show();
        $.ajax({
            type: 'post',
            url: "<?php echo e(url("addquote")); ?>",
            data: formData,
            dataType: "json",
            "_token": "<?php echo csrf_token(); ?>",
            success: function (data) {
                if (data.result == true) { 
                    // $('#myModal').modal('show');
                    if(!alert('Thank you for your request for quotation. We will reply on your request as soon as possible!')){window.location.reload();}

                   //alert("Thank you for your quotation. We will reach out to you within 24 hours by email or phone with a quotation of your requested products & services.");
                } else {

                    //$('#proadd').remove();

                    //$('#Result').show();

                }

            }
        });
    });

	//For Pop up Login

	$(document).on("click", "#submitButton", function(event){
   
        var form = $('#LoginForm'); 
        var formData = form.serializeArray();
       
	    var pathname = window.location.href; 	

      if($('#LoginForm').valid()){
        $.ajax({
            type: 'post',
            url: "<?php echo e(url("pop-login")); ?>",
            data: formData,
            dataType: "json",
            "_token": "<?php echo csrf_token(); ?>",
            success: function (data) {
                if (data.status == 1) { 
                   console.log(pathname);
                    window.location = pathname;
                } else {

                 $('#popErrorMsg').text(data.error).css('color','#150d0d');

                }

            }
        });
	  }
    });
	
    $(document).on("click", "#clickforscroll", function(event){   
		$('html,body').animate({
			scrollTop: $('#contentForScroll').offset().top},
			'slow');

    });

	
</script>
<!--HEADER VISITOR SECTION-->
	<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--END HEADER VISITOR SECTION -->	
</head>

<body>
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<!--TOP SEARCH SECTION-->
		<?php echo $__env->make('frontend.businessadmin.layout.topheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!--LISTING DETAILS-->
	<?php if($getbusinessRs->banner_img): ?>
	<section class="pg-list-1 pg-list-shop" style="background: url(<?php echo e(asset('public/upload/business/banner/original')); ?>/<?php echo e($getbusinessRs->banner_img); ?>) no-repeat;background-size: 100% 100% !important;">
	<?php else: ?>
	<section class="pg-list-1 pg-list-shop" style="background: url(<?php echo e(asset('public/upload/business/thumbnail/original')); ?>/<?php echo e($getbusinessRs->thumbnail_img); ?>) no-repeat;background-size: 100% 100% !important;">
	<?php endif; ?>
	
		<div class="container">
			<div class="row">
				<div class="pg-list-1-left"> <a href="#"><h3><?php echo e($getbusinessRs->business_title); ?></h3></a>
					<div class="list-rat-ch"> <span>4.0</span> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> </div>
					<h4 style="color:#fff !important;"><?php echo e($getbusinessRs->city_name); ?></h4>
					<p style="color:#fff !important;"><b>Address:</b> <?php echo e($getbusinessRs->business_address); ?></p>
					<div class="list-number pag-p1-phone">
						<ul>
							<li><i class="fa fa-phone" aria-hidden="true"></i> <?php echo e($getbusinessRs->business_contactno); ?></li>
							<li><i class="fa fa-envelope" aria-hidden="true"></i> <?php echo e($getbusinessRs->business_email); ?></li>
							<!--<li><i class="fa fa-user" aria-hidden="true"></i> johny depp</li>-->
						</ul>
					</div>
				</div>
				<div class="pg-list-1-right">
					<div class="list-enqu-btn pg-list-1-right-p1">
						<ul>
							<li><a href="javasript:void(0)" id="clickforscroll"><i class="fa fa-star-o" aria-hidden="true"></i> Write Review</a> </li>
							<li><a href="#"><i class="fa fa-commenting-o" aria-hidden="true"></i> Send SMS</a> </li>
							<li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i> Call Now</a> </li>
							<li><a href="#" data-dismiss="modal" data-id="<?php echo e($getbusinessRs->id); ?>" class="open-AddBookDialog" data-toggle="modal" data-target="#list-quo"><i class="fa fa-usd" aria-hidden="true"></i> Get Quotes</a> </li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="list-pg-bg">
		<div class="container">
			<div class="row">
				<div class="com-padd">
					<div class="list-pg-lt list-page-com-p">
						<!--LISTING DETAILS: LEFT PART 1-->
						<div class="pglist-p1 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti">
								<h3><span>About</span> <a href="javascript:void(0)" onclick="openImage()"><?php echo e($getbusinessRs->business_title); ?></a></h3> </div>
							
							<div class="list-pg-inn-sp">
								<div class="share-btn">
									<ul>
										<li>
										    
                                       <script>function fbs_click() {u=location.href;t=document.title;window.open('http://www.facebook.com/sharer.php?u='+encodeURIComponent(u)+'&t='+encodeURIComponent(t),'sharer','toolbar=0,status=0,width=626,height=436');return false;}</script><style> html .fb_share_link { padding:2px 0 0 20px; height:16px; background:url(http://static.ak.facebook.com/images/share/facebook_share_icon.gif?6:26981) no-repeat top left; }</style><a rel="nofollow" href="http://www.facebook.com/share.php?u=<;url>" onclick="return fbs_click()" target="_blank" class="fb_share_link"><i class="fa fa-facebook fb1"></i>Share on Facebook</a>


										</li>

										<li><a href="#" onclick="tweetCurrentPage('<?php echo e($getbusinessRs->business_title); ?>');"><i class="fa fa-twitter tw1"></i> Share On Twitter</a> </li>
										<!--<li><a href="#"><i class="fa fa-google-plus gp1"></i> Share On Google Plus</a> </li>-->
									</ul>
								</div>
								<?php echo html_entity_decode($getbusinessRs->business_desc); ?>

							</div>
						</div>
					
						
						<!--END LISTING DETAILS: LEFT PART 1-->
						<!--LISTING DETAILS: LEFT PART 2-->
						<div class="pglist-p2 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti">
								<h3>PHOTO GALLERY</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="row pg-list-ser">
									<ul>
									    <?php if($galleryRs): ?>
									    <?php $__currentLoopData = $galleryRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valgal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    
										<li class="col-md-4">
											<div class="pg-list-ser-p1"><img src="<?php echo e(asset('public/upload/business/gallary/thumbnail')); ?>/<?php echo e($valgal->image_name); ?>" alt="" style="width:300px !important;height:150px !important;"/> </div>
											<div class="pg-list-ser-p2">
												<!--<h4>Grocery</h4> -->
											</div>
										</li>
									
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
										
									</ul>
								</div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 2-->
						
					
						<!--END 360 DEGREE MAP: LEFT PART 8-->
						<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti">
								<h3><span>360 </span> Degree Shop View</h3> </div>
							<div class="list-pg-inn-sp list-360">
								<iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1497026654798!6m8!1m7!1sIId_fF3cldIAAAQ7LuSTng!2m2!1d5.553927350344909!2d-0.2005543181775732!3f189.99!4f0!5f0.7820865974627469" allowfullscreen></iframe>
							</div>
						</div>
						<!--END 360 DEGREE MAP: LEFT PART 8-->
						<!--LISTING DETAILS: LEFT PART 6-->
						<div class="pglist-p3 pglist-bg pglist-p-com" id="contentForScroll">
							<div class="pglist-p-com-ti">
								<h3><span>Write Your</span> Reviews</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-write-rev">
								<span id="successMsg"></span>
									<form class="col" id="reviewForm">
										<p>Writing great reviews may help others discover the places that are just apt for them. Here are a few tips to write a good review:</p>
										<div class="row">
											<div class="col s12">
												<fieldset class="rating">
													<input type="radio" id="star5" name="rating" value="5" />
													<label class="full" for="star5" title="Awesome - 5 stars"></label>
													<input type="radio" id="star4half" name="rating" value="4 and a half" />
													<label class="half" for="star4half" title="Pretty good - 4.5 stars"></label>
													<input type="radio" id="star4" name="rating" value="4" />
													<label class="full" for="star4" title="Pretty good - 4 stars"></label>
													<input type="radio" id="star3half" name="rating" value="3 and a half" />
													<label class="half" for="star3half" title="Meh - 3.5 stars"></label>
													<input type="radio" id="star3" name="rating" value="3" />
													<label class="full" for="star3" title="Meh - 3 stars"></label>
													<input type="radio" id="star2half" name="rating" value="2 and a half" />
													<label class="half" for="star2half" title="Kinda bad - 2.5 stars"></label>
													<input type="radio" id="star2" name="rating" value="2" />
													<label class="full" for="star2" title="Kinda bad - 2 stars"></label>
													<input type="radio" id="star1half" name="rating" value="1 and a half" />
													<label class="half" for="star1half" title="Meh - 1.5 stars"></label>
													<input type="radio" id="star1" name="rating" value="1" />
													<label class="full" for="star1" title="Sucks big time - 1 star"></label>
													<input type="radio" id="starhalf" name="rating" value="half" />
													<label class="half" for="starhalf" title="Sucks big time - 0.5 stars"></label>
												</fieldset>
											</div>
										</div>
										
										<div class="row">
											<div class="input-field col s12">
											    <input type="hidden" name="business_id" value="<?php echo e($getbusinessRs->id); ?>" />
											    <input type="hidden" name="userid" value="<?php echo e(@Request::user()->id); ?>" />
												<textarea id="re_msg" name="reviews" class="materialize-textarea"></textarea>
												<label for="re_msg">Write review</label>
											</div>
										</div>
										<div class="row">
										    	
											<div class="input-field col s12">
											<button type="button" id="submitreview" class="waves-effect waves-light btn-large full-btn">Submit Review</button></div>
										</div>
									</form>
								</div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 6-->
						<!--LISTING DETAILS: LEFT PART 5-->
						<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti">
								<h3><span>User</span> Reviews</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="lp-ur-all">
									<div class="lp-ur-all-left">
										<div class="lp-ur-all-left-1">
											<div class="lp-ur-all-left-11">Excellent</div>
											<div class="lp-ur-all-left-12">
												<div class="lp-ur-all-left-13"></div>
											</div>
										</div>
										<div class="lp-ur-all-left-1">
											<div class="lp-ur-all-left-11">Good</div>
											<div class="lp-ur-all-left-12">
												<div class="lp-ur-all-left-13 lp-ur-all-left-Good"></div>
											</div>
										</div>
										<div class="lp-ur-all-left-1">
											<div class="lp-ur-all-left-11">Satisfactory</div>
											<div class="lp-ur-all-left-12">
												<div class="lp-ur-all-left-13 lp-ur-all-left-satis"></div>
											</div>
										</div>
										<div class="lp-ur-all-left-1">
											<div class="lp-ur-all-left-11">Below Average</div>
											<div class="lp-ur-all-left-12">
												<div class="lp-ur-all-left-13 lp-ur-all-left-below"></div>
											</div>
										</div>
										<div class="lp-ur-all-left-1">
											<div class="lp-ur-all-left-11">Below Average</div>
											<div class="lp-ur-all-left-12">
												<div class="lp-ur-all-left-13 lp-ur-all-left-poor"></div>
											</div>
										</div>
									</div>
									<div class="lp-ur-all-right">
										<h5>Overall Ratings</h5>
										<p id="ratingcnt"><span><?php echo e($finalAvgrating); ?><i class='fa fa-star' aria-hidden='true'></i></span> based on <?php echo e($reviewcnt); ?> reviews</p>
									</div>
								</div>
								<div class="lp-ur-all-rat">
									<h5>Reviews</h5>
									<ul>
									    <div id="proadd">
									       
                                            <?php if(isset($commentRs)): ?>
                                                <?php $__currentLoopData = $commentRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commentrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <?php if($commentrow->user_image): ?>
						<div class="lr-user-wr-img"><img src="<?php echo e($commentrow->user_image_path); ?>/icon/<?php echo e($commentrow->user_image); ?>" alt="" style="width: 50px; height: 50px;border-radius: 50%;"/> </div>
						<?php else: ?>
						<div class="lr-user-wr-img"><img src="<?php echo e(asset('public/images/users/2.png')); ?>" alt="" /> </div>
						<?php endif; ?>
						
                                        				
                                        				<div class="lr-user-wr-con">
                                        					<h6><?php echo e($commentrow->first_name); ?> <span><?php echo e($commentrow->rating); ?> <i class="fa fa-star" aria-hidden="true"></i></span></h6> 
															<span class="lr-revi-date" style="float: right;margin-top: -36px;">
															<?php echo e(Carbon\Carbon::parse($commentrow->created_at)->diffForHumans()); ?>

															</span>
                                        					<p><?php echo e($commentrow->comment); ?>  </p> 
                                        					<ul>
                                        						<li><a href="#!"><span>Like</span><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><span>Dis-Like</span><i class="fa fa-thumbs-o-down" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><span>Comments</span> <i class="fa fa-commenting-o" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><span>Share Now</span>  <i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
                                        						<!--<li><a href="#!"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
                                        						<li><a href="#!"><i class="fa fa-youtube" aria-hidden="true"></i></a> </li>-->
                                        					</ul>
                                        				</div>
                                        			</li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
										
									</ul>
								</div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 5-->
					</div>
					<div class="list-pg-rt">
					    
					    <!--LISTING DETAILS: LEFT PART 7-->
						<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti pglist-p-com-ti-right">
								<h3>Contact Details</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-guar">
									<ul>
										<li style="border-bottom: 0px solid #e2e2e2 !important;">
											<i class="fa fa-phone" aria-hidden="true"></i><span style="padding-left:5px;"> <?php echo e($getbusinessRs->business_contactno); ?></span>
										</li>
										<li style="border-bottom: 0px solid #e2e2e2 !important;">
											<i class="fa fa-home" aria-hidden="true"></i><span style="padding-left:5px;"> <?php echo e($getbusinessRs->business_address); ?> </span>
										</li>
										<li style="border-bottom: 0px solid #e2e2e2 !important;">
											<i class="fa fa-plus-circle" aria-hidden="true"></i><span style="padding-left:5px;"> <?php echo e($getbusinessRs->business_tag); ?> </span>
										</li>
									</ul>  </div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 7-->
					    
					    
						<!--LISTING DETAILS: LEFT PART 7-->
						<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti pglist-p-com-ti-right">
								<h3>Hours of Operation </h3> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-guar">
									<ul>
									    <?php if($workingdayRs): ?>
									    <?php $__currentLoopData = $workingdayRs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									    
										<li style="border-bottom: 0px solid #e2e2e2 !important;">
											<!--<div class="list-pg-guar-img"> <img src="<?php echo e(asset('public/images/icon/g1.png')); ?>" alt="" /> </div>
											<h4>Service Guarantee</h4>-->
											<p><div class="col-md-4"><?php echo e($valwork->week_day); ?></div>										
											<div class="col-md-4"><?php echo e($valwork->week_start_time); ?></div> 
											<div class="col-md-4"><?php echo e($valwork->week_end_time); ?></div> 
											
											  </p>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
									</ul></div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 7-->
						<!--LISTING DETAILS: LEFT PART 7-->
						<!--<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pg-list-user-pro"> <img src="<?php echo e(asset('public/images/users/8.png')); ?>" alt=""> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-upro">
									<h5>Kevin Jack</h5>
									<p>Member since July 2017</p> <a class="waves-effect waves-light btn-large full-btn list-pg-btn" href="#!">Contact User</a> </div>
							</div>
						</div>-->
						<!--END LISTING DETAILS: LEFT PART 7-->
						<!--LISTING DETAILS: LEFT PART 8-->
						<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti pglist-p-com-ti-right">
								<h3><span>Our</span> Location</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-map">
								
								<iframe src="https://maps.google.com/maps?q=<?php echo e($getbusinessRs->lattutude); ?>,<?php echo e($getbusinessRs->longitude); ?>&hl=en&z=14&amp;output=embed" allowfullscreen></iframe>

									<!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6290413.804893654!2d-93.99620524741552!3d39.66116578737809!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880b2d386f6e2619%3A0x7f15825064115956!2sIllinois%2C+USA!5e0!3m2!1sen!2sin!4v1469954001005" allowfullscreen></iframe> -->
								</div>
							</div>
						</div>
						<!--END LISTING DETAILS: LEFT PART 8-->
						<!--LISTING DETAILS: LEFT PART 9-->
						<!--<div class="pglist-p3 pglist-bg pglist-p-com">
							<div class="pglist-p-com-ti pglist-p-com-ti-right">
								<h3><span>Other</span> Informations</h3> </div>
							<div class="list-pg-inn-sp">
								<div class="list-pg-oth-info">
									<ul>
										<li>Today Shop <span class="green-bg">open</span> </li>
										<li>Experience <span>16</span> </li>
										<li>Parking <span>yes</span> </li>
										<li>Smoking <span>yes</span> </li>
										<li>Pool Table <span>yes</span> </li>
										<li>Take Out <span>yes</span> </li>
										<li>Good for Groups <span>yes</span> </li>
										<li>Accepts All Cards <span>yes</span> </li>
										<li>Open Time <span>09:00am</span> </li>
										<li>Close Time <span>10:00pm</span> </li>
									</ul>
								</div>
							</div>
						</div>-->
						<!--END LISTING DETAILS: LEFT PART 9-->
						<!--LISTING DETAILS: LEFT PART 10-->
						<div class="list-mig-like">
							<div class="list-ri-spec-tit">
								<h3><span>You might</span> like this</h3> </div>
								<?php if($randomBusiness): ?>
    								<?php $__currentLoopData = $randomBusiness; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $randomval): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e(url('list')); ?>/<?php echo e($randomval->id); ?>/<?php echo e($randomval->business_title); ?>">
								<div class="list-mig-like-com">
									<div class="list-mig-lc-img"> <img src="<?php echo e(asset('public/upload/business/thumbnail/original')); ?>/<?php echo e($randomval->thumbnail_img); ?>" alt="" style="width:300px !important;height:150px !important;"/> <span class="home-list-pop-rat list-mi-pr">$720</span> </div>
									<div class="list-mig-lc-con">
										<div class="list-rat-ch list-room-rati"> <span>4.0</span> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star" aria-hidden="true"></i> <i class="fa fa-star-o" aria-hidden="true"></i> </div>
										<h5><?php echo e($randomval->business_title); ?></h5>
										<p><?php echo e($randomval->city_name); ?>,</p>
									</div>
								</div>
							</a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    							<?php endif; ?>
						</div>
						<!--END LISTING DETAILS: LEFT PART 10-->
					</div>
				</div>
			</div>
		</div>
	</section>
	<a href="javascript:void(0)" id ="scrollTotop" class="btn-btn-primary">Scroll Top </a>
	<!--FOOTER SECTION-->
	<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--COPY RIGHTS-->
	<section class="copy">
		<div class="container">
			<p>copyrights © <span id="cryear">2019</span> justonetouch.in &nbsp;&nbsp;All rights reserved. </p>
		</div>
	</section>
	<!--QUOTS POPUP-->
<!--QUOTS POPUP-->
	<section>
		<!-- GET QUOTES POPUP -->
		<div class="modal fade dir-pop-com" id="list-quo" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header dir-pop-head">
						<button type="button" class="close" data-dismiss="modal">×</button>
						<h4 class="modal-title">Get a Quotes</h4>
						<!--<i class="fa fa-pencil dir-pop-head-icon" aria-hidden="true"></i>-->
					</div>
					<div class="modal-body dir-pop-body">
						<form class="form-horizontal" id="quoteForm">
							<!--LISTING INFORMATION-->
							<?php echo e(csrf_field()); ?>

							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Full Name *</label>
								<div class="col-md-8">
								    <input type="hidden" name="businessid" id="businessid" value=""/>
									<input type="text" class="form-control" name="qname" placeholder="" required> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Mobile</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="qmobile" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Email</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="qemail" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Message</label>
								<div class="col-md-8 get-quo">
									<textarea class="form-control" name="qmessage"></textarea>
								</div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<div class="col-md-6 col-md-offset-4">
									<input type="button" value="SUBMIT" id="submitquote" class="pop-btn"> </div>
							</div>
						</form>
					</div>
				
				</div>
			</div>
		</div>
		
		<!-- GET QUOTES Popup END -->
	</section>
	
	
	<!-- Trigger the modal with a button -->


	<!---- MODAL POPUP FOR SHOW ABOUT IMAGE START ------------>
	<div id="myModalAbout" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">
		
		<span style="font-weight:600;font-size:17px;color: #2ea2c5;"><?php echo e($getbusinessRs->business_title); ?></span></h4>
      </div>
      <div class="modal-body">
	  <div class='row'>
	  <?php 
	   $fileBanner = isset($getbusinessRs->about_business_img)?$getbusinessRs->about_business_img:"";
	   $pathBannner= public_path()."/upload/business/aboutbusiness/".$fileBanner; ?>
	    <?php if(isset($getbusinessRs->about_business_img) && $getbusinessRs->about_business_img !="" && file_exists($pathBannner)): ?>
	        <img src="<?php echo e(asset('/public/upload/business/aboutbusiness/'.$getbusinessRs->about_business_img)); ?>" style="width:96%;margin-left:14px;">
		<?php else: ?>
		
		<img src="<?php echo e(asset('public/images/default-image.jpg')); ?>" style="width:96%;margin-left:14px;">


		<?php endif; ?>			
      </div>
     
    </div>

  </div>
</div>
	<!---- MODAL POPUP FOR SHOW ABOUT IMAGE  END------------>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">
		<img src="<?php echo e(asset('public/images/logo.png')); ?>" alt="" style="margin-left: -47px;"> 
		<span style="font-weight:600;font-size:17px;color: #2ea2c5;">Login Form</span></h4>
      </div>
      <div class="modal-body">
	  <div class="log-in-pop-right">
					<a href="#" class="pop-close" data-dismiss="modal"><img src="images/cancel.html" alt="" />
					</a>
					<div>
						<div class="input-field s12" style="text-align: center;background-color: #f37979;">
					    <span id="popErrorMsg" ></span>
					    </div>
					</div>

					<h4>Login</h4>
					
				
					<p>Don't have an account? Create your account. It's take less then a minutes</p>
					
					<form class="s12"  id="LoginForm">
						<div>
							<div class="input-field s12">
								<input type="text" data-ng-model="name1" name="mobile_no" placeholder="Enter your mobile no" class="validate" maxlength="10" >
								<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
								<label>User name</label>
							</div>
						</div>
						<div>
							<div class="input-field s12">
								<input type="password" class="validate" id="password" name="password" placeholder="Enter your password">
								<i id="pass-status" class="fa fa-eye-slash field-icons" style="" aria-hidden="true" onClick="viewConfirmPassword()"></i>

								<label>Password</label>
							</div>
						</div>
						<div>
							<div class="input-field s4">
							
								<button type="button" id="submitButton" value="Login" class="waves-effect waves-light log-in-btn">Login</button> </div>
						</div>
						<div>
							<div class="input-field s12">								
							<a style="float: right;margin-top: -34px;color:#0077cc" href="<?php echo e(url('signup')); ?>" style="color:#0077cc;">Create a new account</a> </div>
						</div>
					</form>
				</div>
      </div>
     
    </div>

  </div>
</div>
	
	<script>


function tweetCurrentPage(twitterHandle) {
    var twitterHandle = twitterHandle;
    window.open('https://twitter.com/share?url='+escape(window.location.href)+'&text='+document.title + ' via @' + twitterHandle, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');
    return false; 
}
	</script>

	
</body>


</html><?php /**PATH /home/tba7sena02zd/public_html/justonetouch.in/resources/views/frontend/listdetail.blade.php ENDPATH**/ ?>