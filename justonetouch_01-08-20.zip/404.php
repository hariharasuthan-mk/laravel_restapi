<?php
  ?>

<!DOCTYPE html>
<html>
  <head>
    </head>
      <body>
        <p>From 404.php - This is a custom 404 error page done with ErrorDocument in .htaccess</p>
      </body>
  </html>