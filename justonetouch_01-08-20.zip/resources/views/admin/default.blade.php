<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/font-awesome.min.css')}}" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/materialize.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/style.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/bootstrap.css')}}" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/responsive.css')}}" />
	
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
		@include('admin.layout.scripts')   
</head>

<body>
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<!--== MAIN CONTRAINER ==-->
	@include('admin.layout.topheader')   
	<!--== BODY CONTNAINER ==-->
	<div class="container-fluid sb2">
		<div class="row">
			@include('admin.layout.sidenav') 
			<!--== BODY INNER CONTAINER ==-->
			
			
			<div class="sb2-2">
				
			@yield('content')	
				
			</div>
			
		</div>
	</div>
	<!--== BOTTOM FLOAT ICON ==-->
<!--	<section>
		<div class="fixed-action-btn vertical">
			<a class="btn-floating btn-large red pulse"> <i class="large material-icons">mode_edit</i> </a>
			<ul>
				<li><a class="btn-floating red"><i class="material-icons">insert_chart</i></a> </li>
				<li><a class="btn-floating yellow darken-1"><i class="material-icons">format_quote</i></a> </li>
				<li><a class="btn-floating green"><i class="material-icons">publish</i></a> </li>
				<li><a class="btn-floating blue"><i class="material-icons">attach_file</i></a> </li>
			</ul>
		</div>
	</section>-->
	<!--SCRIPT FILES-->

</body>
</html>



