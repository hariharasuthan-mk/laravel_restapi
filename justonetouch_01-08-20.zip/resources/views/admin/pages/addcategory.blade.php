@extends('admin.default')
@section('content')
<!--== breadcrumbs ==-->

<style>
	.dropdown-content {
max-height:265px;
	}
	.tz-db-table {
    background-color: #fff;
}

.error
{
    color:red;
	font-size:14px;
}

.tz2-form-com form input[type="submit"] {
    padding: 0px 69px;
}

  .dropdown-content {
    max-height:265px;
	}
	
	.add-button {
	float: right;
    padding: 7px 10px 6px;
    background-color: #;
    background-color: #337ab7;
    color: #fff;
    font-size: 12px;
    border-radius: 3px;
}
.tz-db-table {
	width:100%;
}

</style>
<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<link rel="stylesheet" type="text/css" href="{{asset('public/css/select2-materialize.css')}}" />
<script src="{{asset('public/js/select2-materialize.js')}}"></script>

	<!--SCRIPT FILES-->
	<script>
	$(document).ready(function(){
	    
    $('select').material_select();
    $('#parent_id').sm_select();
    $("select[required]").css({
    display: "block", 
    'margin-top':'-15px',
    height: 0, 
    padding: 0, 
    width: 0});
});

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#imageId').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$(document).on('change', '#imageFile', function() {
	$('#fileErrorMsg').hide();
 var fileName = $(this).val();

 var ext = $(this).val().split('.').pop().toLowerCase();

 if ($.inArray(ext, ['png','jpg','jpeg']) == -1){
	$(this).val('');
	$('#fileErrorMsg').show().text('Only PNG, JPG, and JPEG files are allowed.').css('color','#F00');
	$('#imageId').attr('src',"{{asset('public/images/default-image.jpg')}}");
  
 }else {

	readURL(this);

 }

});
	$(document).on('change', '#parent_id', function() {
//alert("dfsdf");
	//$('#parent_id').change(function(){
		$("#subcatdiv").show();
        var cid = $(this).val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
		}			
		var url="{{ url('/admin/getSubcategory')}}/"+cid;
        if(cid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                console.log(res);
				if(res)
                {
                    $("#subcat_id").empty();
                    //$("#city").empty();
                    $("#subcat_id").append('<option value="">Select Sub Category</option>');
                    $.each(res,function(key,value){
                        $("#subcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                    $('#subcat_id').material_select();
                }
           }

        });
        }
    });

	
 $(document).ready(function () {

        $("#categoryform").validate({
            errorElement: "div",
            //set the rules for the field names

            rules: {
                //parent_id: {
                //    required: true
               // },
               // subcat_id: {
                //    required:true
               // },
                cat_name: {
                    required: true
                },
                filename: {
                    required: true,
                }
            },
            //set messages to appear inline
            messages: {
               // parent_id: {
                   // required: "This field is required. "

                //},
                //subcat_id: {
                    //required: "This field is required. "

               // },
                cat_name: {
                    required : "Category name is required"
                },
                filename: {
                    required : "Please select the image file."
                }

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent());
            }
        });
 });

 
	</script>
	
<div class="sb2-2-2">
@include('notification.notification')

				<div class="tz-2-com tz-2-main">
					<h4>Home / Add New Category <a href="{{url('admin/categorylist')}}" class="add-button" style=""> <i class="fa fa-list"></i> Category List</a></h4>
					<div class="db-list-com tz-db-table">
						<!--<div class="ds-boar-title">
							 <h2>Add New Price</h2>
						</div>-->
					
						<div class="hom-cre-acc-left hom-cre-acc-right">
							<div class="">
							{!! Form::open(['url' => url('admin/postcategory/'.$data['id']), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'categoryform']) !!}
												
							        @if(isset($data['grand_parent_id']) && $data['grand_parent_id'] != 0)

										<div class="row">
											<div class="input-field col s12">
												<select name="parent_id" id="parent_id">
													<option value="">Select Category</option>
													
													@if($getall)
														@foreach($getall as $val)
														
														<option value="{{ $val->id}}" <?php if($val->id == $data['grand_parent_id']) { ?>  selected='selected' <?php } ?> >{{ $val->category_name }}</option>
														@endforeach
													@endif
												</select>
											</div>
										</div>

										     <div class="row">
													  <div class="input-field col s12">
														  <select name="subcat_id" id="subcat_id">
															  <option value="">Select Sub Category</option>
															  
															  @if($subcat)
																  @foreach($subcat as $val)
																  
																  <option value="{{ $val->id}}" <?php if($val->id == $data['parent_id']) { ?>  selected='selected' <?php } ?> >{{ $val->category_name }}</option>
																  @endforeach
															  @endif
														  </select>
													  </div>
												  </div>

										@else

										    
							
												<div class="row">
													  <div class="input-field col s12">
														  <select name="parent_id" id="parent_id" class="browser-default">
															  <option value="">Select Category</option>
															  
															  @if($getall)
																  @foreach($getall as $val)
																  
																  <option value="{{ $val->id}}" <?php if($val->id == $data['parent_id']) { ?>  selected='selected' <?php } ?> >{{ $val->category_name }}</option>
																  @endforeach
															  @endif
														  </select>
													  </div>
												  </div>
												 

												  <div class="row" id="subcatdiv" style="display:none">
												  <div class="input-field col s12">
												  <select name="subcat_id" id="subcat_id" class="validate" class="browser-default">
														  
											 </select>
												  </div>
											  </div>

												  @endif
											  
											  
											  
											  <div class="row">
												  <div class="input-field col s12">
													  
													{!! Form::text('cat_name',isset($data['category_name']) ? $data['category_name'] : "",array('class'=>'validate','placeholder'=>'Enter Your Category')) !!}  
											  </div>
											  </div>
											  <div class="row">
												  <div class="input-field col s12">
													  {!! Form::textarea('cat_desc',isset($data['category_desc']) ? $data['category_desc'] :"",array('class'=>'validate','placeholder'=>'Enter Your Category Desc','style'=>'height: 100px;')) !!} 
											  </div>
											  </div>
											 
											  <div class="row">												 
												  <div class="input-field col s3">
												   @if($data['category_image'])
													  
													<img src="{{asset('public/upload/category/original/'.$data['category_image'])}}" width='130' height='120' id="imageId">
													@else
													<img src="{{asset('public/images/default-image.jpg')}}" width='130' height='120' id="imageId">
													@endif
											      </div>
											 </div>
											  <div class="row tz-file-upload">
													<div class="file-field input-field">
														<div class="tz-up-btn"> <span>Select Image File</span>
															 <input type="file" name="image" id='imageFile'>
															</div>
															
														<div class="file-path-wrapper">
															<input class="file-path validate" type="text" value="<?php echo isset($data['category_image']) ? $data['category_image'] : ""  ?>" name="filename" placeholder="Please select image"> 
														</div>
														<span id="fileErrorMsg"></span>
														
													</div>
												</div>
												
    
											  <div class="row">												 
												  <div class="input-field col s3" style="margin-left: 37%;margin-top: 44px;">
													  <input type="submit" value="SUBMIT" class="waves-effect waves-light full-btn " style=""> 
												  </div>
                                             
											  </div>
										  {!! Form::close() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--RIGHT SECTION-->
			
		</div>
		</div>
		</div>

@stop