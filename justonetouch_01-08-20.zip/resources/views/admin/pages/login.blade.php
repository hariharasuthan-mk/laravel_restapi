<!DOCTYPE html>
<html lang="en">
<head>
<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/font-awesome.min.css')}}" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/materialize.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/style.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/bootstrap.css')}}" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/responsive.css')}}" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	@include('admin.layout.scripts')
</head>
<style>
.error
{
    color:red;
	font-size:14px;
	text-align:left;
}
</style>

<body>
	<section class="tz-login">
		<div class="tz-regi-form">
			<h4>Sign In</h4>
		@include('notification.notification')
			<form class="col s12" action="{{ url('admin/adminpostLogin') }}" method="post" id="LoginForm">
			    {{ csrf_field() }}
				<div class="row">
					<div class="input-field col s12">
						<input type="text" class="validate" name="mobile_no" maxlength=10>
						<label>Please Enter your username</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
						<input type="password" class="validate" name="password">
						<label>Please Enter Password</label>
					</div>
				</div>
				<div class="row">
					<div class="input-field col s12">
					     <button class="waves-effect waves-light btn-large full-btn" type="submit" name="action">Submit
    <i class="material-icons right">send</i>
  </button>
					     </div>
					    
					   
				</div>
			</form>
		</div>
	</section>
	
</body>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

        $("#LoginForm").validate({
            errorElement: "div",
            //set the rules for the field names

            rules: {
             
                mobile_no: {
                    required: true					
                },
                password: {
                    required: true					
                }
				
            },
            //set messages to appear inline
            messages: {
               
                mobile_no: {
                    required : "Username is required."
					
                },
                password: {
                    required: "Password is required."					
                }

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent());
            }
        });
 });
 jQuery.validator.setDefaults({
	 ignore: ""
 });

 
	</script>


</html>