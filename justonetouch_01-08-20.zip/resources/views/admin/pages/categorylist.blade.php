@extends('admin.default')
@section('content')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" />
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>


<style>
	input[type=search], textarea.materialize-textarea {
    background-color: transparent;
  
    /* border-bottom: 1px solid #9e9e9e; */
    border-radius: 0;
    outline: none;
    height: 3rem;
    width: 58%;
    font-size: 1rem;
    /* margin: 0 0 20px 0; */
    /* padding: 0; */
    box-shadow: none;
    transition: all 0.3s;
}

.dataTables_filter label {
	font-weight:200;
	padding: 12px 18px;
}

.dataTables_length label {
	padding: 17px 22px;
}

.dataTables_info {
	padding: 17px 15px;
    font-size: 13px;
}
.add-button {
	float: right;
    padding: 7px 10px 6px;
    background-color: #;
    background-color: #337ab7;
    color: #fff;
    font-size: 12px;
    border-radius: 3px;
}

.ad-inn-page i {
  
  width: 24px;
  height: 24px;    
  font-size: 16px;
 
}

	</style>
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );

var id;
function deleteCategory(id) {
	
	$.confirm({
		title: "Confirm !",
		content: "Are You sure want to delete this category",
		buttons : {

			confirm : function(){
              var deleteurl = "{{url('admin/deletecategory/')}}" +'/'+ id;
			  window.location = deleteurl;
			},
			cancel : function() {
				
			}

		},

	});


}
</script>
	<!--== breadcrumbs ==-->
				<div class="sb2-2-2">
					<ul>
						<li style="float:left;"><a href="{{url('admin/dashboard')}}"><i class="fa fa-home" aria-hidden="true"></i> Home</a> </li>
						<li class="active-bre" style="list-style-type:none;"><a href="{{url('admin/addcategory')}}"> Category List</a> </li>
						
					</ul>
				</div>
				@include('notification.notification')
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4> Category List<a href="{{ url('admin/addcategory') }}" class="add-button" style="float:right;"> <i class="fa fa-plus"></i> Add Category</a></h4>
						<!-- <a class="dropdown-button drop-down-meta drop-down-meta-inn" href="#" data-activates="dr-list"><i class="material-icons">more_vert</i></a>
						<ul id="dr-list" class="dropdown-content">
							<li><a href="{{ url('admin/addcategory') }}">Add New</a> </li>
							<li><a href="#!">Edit</a> </li>
							<li><a href="#!">Update</a> </li>
							<li class="divider"></li>
							<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
							<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
							<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
						</ul>-->
						<!-- Dropdown Structure -->
					
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp ad-inn-page">
									<div class="tab-inn ad-tab-inn">
										<div class="table-responsive">
											<table class="table table-hover" id="example" data-order='[0 ,"desc"]'>
												<thead>
													<tr>
														<th hidden></th>
														<th>Category name</th>
														<th>image</th>
														<th>Status</th>
														<th>Edit</th>
														<th>Delete</th>
													</tr>
												</thead>
												<tbody>
												
												@foreach($getall as $value)
													<tr>
													    <td hidden>{{$value->id}}</td>
														<td>{{$value->category_name}}</td>
														<td><img src="{{asset('public/upload/category/icon/'.$value->category_image)}}"></td>
														<td>{{$value->status}}</td>
														<td><a href="{{url('admin/category/'.$value->id)}}" class=""><i class="fa fa-pencil" style="color:#1c8bd2;"></i></a> </td>
														<td><a href="javascript:void(0)" data-url="{{url('admin/deletecategory/'.$value->id)}}" rel="{{$value->id}}"  onclick="deleteCategory({{$value->id}})"><i class="fa fa-trash-o" style="color: red;"></i>
															</a> 
														</td>
													</tr>
												     @endforeach
												</tbody>
							
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
					@stop

