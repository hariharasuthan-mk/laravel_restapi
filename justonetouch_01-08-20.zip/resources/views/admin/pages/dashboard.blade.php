@extends('admin.default')
@section('content')

<!--== breadcrumbs ==-->
				<div class="sb2-2-2">
					<ul>
						<li><a href="index-1.html"><i class="fa fa-home" aria-hidden="true"></i> Home</a> </li>
						<li class="active-bre"><a href="#"> Dashboard</a> </li>
						<li class="page-back"><a href="#"><i class="fa fa-backward" aria-hidden="true"></i> Back</a> </li>
					</ul>
				</div>
				<div class="tz-2 tz-2-admin">
					<div class="tz-2-com tz-2-main">
						<h4>Manage Booking</h4>
						<div class="tz-2-main-com bot-sp-20">
							<div class="tz-2-main-1 tz-2-main-admin">
								<div class="tz-2-main-2"> <img src="{{asset('public/images/icon/d1.png')}}" alt=""><span>All Listings</span>
									<!--<p>All the Lorem Ipsum generators on the</p>-->
									<h2>{{ $businesscnt }}</h2> </div>
							</div>
							<div class="tz-2-main-1 tz-2-main-admin">
								<div class="tz-2-main-2"> <img src="{{asset('public/images/icon/d4.png')}}" alt=""><span>Users</span>
									<!--<p>All the Lorem Ipsum generators on the</p>-->
									<h2>{{ $usercnt }}</h2> </div>
							</div>
							<div class="tz-2-main-1 tz-2-main-admin">
								<div class="tz-2-main-2"> <img src="{{asset('public/images/icon/d3.png')}}" alt=""><span>Leads</span>
									<!--<p>All the Lorem Ipsum generators on the</p>-->
									<h2>{{ $quotescnt }}</h2> </div>
							</div>
							<div class="tz-2-main-1 tz-2-main-admin">
								<div class="tz-2-main-2"> <img src="{{asset('public/images/icon/d2.png')}}" alt=""><span>Reviews</span>
									<!--<p>All the Lorem Ipsum generators on the</p>-->
									<h2>53</h2> </div>
							</div>
						</div>
						<!--<div class="split-row">
							<!--== Country Campaigns ==-->
							<!--<div class="col-md-6">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>Country Campaigns</h4>
										<p>Airtport Hotels The Right Way To Start A Short Break Holiday</p> <a class="dropdown-button drop-down-meta" href="#" data-activates="dropdown1"><i class="material-icons">more_vert</i></a>
										<ul id="dropdown1" class="dropdown-content">
											<li><a href="#!">Add New</a> </li>
											<li><a href="#!">Edit</a> </li>
											<li><a href="#!">Update</a> </li>
											<li class="divider"></li>
											<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
											<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
											<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
										</ul>
										<!-- Dropdown Structure -->
									<!--</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>Country</th>
														<th>Client</th>
														<th>Changes</th>
														<th>Budget</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td><span class="txt-dark weight-500">Australia</span> </td>
														<td>Beavis</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>2.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$1478</span> </td>
														<td> <span class="label label-success">Active</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">Cuba</span> </td>
														<td>Felix</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>1.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$951</span> </td>
														<td> <span class="label label-danger">Closed</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">France</span> </td>
														<td>Cannibus</td>
														<td><span class="txt-danger"><i class="fa fa-angle-up" aria-hidden="true"></i><span>-8.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$632</span> </td>
														<td> <span class="label label-default">Hold</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">Norway</span> </td>
														<td>Neosoft</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>7.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$325</span> </td>
														<td> <span class="label label-default">Hold</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">South Africa</span> </td>
														<td>Hencework</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>9.43%</span></span>
														</td>
														<td> <span>$258</span> </td>
														<td> <span class="label label-success">Active</span> </td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
							<!--== Country Campaigns ==-->
							<!--<div class="col-md-6">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>City Campaigns</h4>
										<p>Airtport Hotels The Right Way To Start A Short Break Holiday</p> <a class="dropdown-button drop-down-meta" href="#" data-activates="dropdown2"><i class="material-icons">more_vert</i></a>
										<ul id="dropdown2" class="dropdown-content">
											<li><a href="#!">Add New</a> </li>
											<li><a href="#!">Edit</a> </li>
											<li><a href="#!">Update</a> </li>
											<li class="divider"></li>
											<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
											<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
											<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
										</ul>
										<!-- Dropdown Structure -->
									<!--</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>State</th>
														<th>Client</th>
														<th>Changes</th>
														<th>Budget</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td><span class="txt-dark weight-500">California</span> </td>
														<td>Beavis</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>2.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$1478</span> </td>
														<td> <span class="label label-success">Active</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">Florida</span> </td>
														<td>Felix</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>1.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$951</span> </td>
														<td> <span class="label label-danger">Closed</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">Hawaii</span> </td>
														<td>Cannibus</td>
														<td><span class="txt-danger"><i class="fa fa-angle-up" aria-hidden="true"></i><span>-8.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$632</span> </td>
														<td> <span class="label label-default">Hold</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">Alaska</span> </td>
														<td>Neosoft</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>7.43%</span></span>
														</td>
														<td> <span class="txt-dark weight-500">$325</span> </td>
														<td> <span class="label label-default">Hold</span> </td>
													</tr>
													<tr>
														<td><span class="txt-dark weight-500">New Jersey</span> </td>
														<td>Hencework</td>
														<td><span class="txt-success"><i class="fa fa-angle-up" aria-hidden="true"></i><span>9.43%</span></span>
														</td>
														<td> <span>$258</span> </td>
														<td> <span class="label label-success">Active</span> </td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>-->
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>New Listing Details</h4>
										<p>Airtport Hotels The Right Way To Start A Short Break Holiday</p> <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-list"><i class="material-icons">more_vert</i></a>
										<ul id="dr-list" class="dropdown-content">
											<li><a href="#!">Add New</a> </li>
											<li><a href="#!">Edit</a> </li>
											<li><a href="#!">Update</a> </li>
											<li class="divider"></li>
											<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
											<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
											<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
										</ul>
										<!-- Dropdown Structure -->
									</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>Listing</th>
														<th>Name</th>
														<th>Phone</th>
														<!--<th>Exp Date</th>-->
														<th>City</th>
														<th>Payment</th>
														<th>Listing Type</th>
														<th>Status</th>
													</tr>
												</thead>
												<tbody>
												    @if($businessRs)
												    @foreach($businessRs as $businessval)
													<tr>
														<td>
														    @if($businessval->thumbnail_img)
														    <span class="list-img"><img src="{{asset('public/upload/business/thumbnail/icon')}}/{{ $businessval->thumbnail_img}}" alt=""></span> 
														    @else
														    <span class="list-img"><img src="{{asset('public/upload/business/thumbnail/icon/noimage.jpg')}}" alt=""></span> 
														    @endif
														</td>
														<td><a href="#"><span class="list-enq-name">{{ $businessval->business_title }}</span><span class="list-enq-city">{{ $businessval->business_address }}</span></a> </td>
														<td>{{ $businessval->business_contactno }}</td>
														<!--<td>24 Dec 2017</td>-->
														<td>{{ $businessval->city_name }}</td>
														<td> <span class="label label-primary">Pending</span> </td>
														<td> <span class="label label-danger">Premium</span> </td>
														<td> <span class="label label-primary">Pending</span> </td>
													</tr>
													@endforeach
					                                @endif
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>New Leads</h4>
										<p>Airtport Hotels The Right Way To Start A Short Break Holiday</p> <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-list-ad"><i class="material-icons">more_vert</i></a>
										<ul id="dr-list-ad" class="dropdown-content">
											<li><a href="#!">Add New</a> </li>
											<li><a href="#!">Edit</a> </li>
											<li><a href="#!">Update</a> </li>
											<li class="divider"></li>
											<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
											<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
											<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
										</ul>
										<!-- Dropdown Structure -->
									</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<th>User</th>
														<th>Name</th>
														<th>Phone</th>
														<th>Email</th>
														<!--<th>Category</th>-->
														<th>Status</th>
														<th>View</th>
													</tr>
												</thead>
												<tbody>
												    @if($leadRs)
												    @foreach($leadRs as $value)
													<tr>
														<td><span class="list-img"><img src="{{ asset('public/images/users/1.png')}}" alt=""></span> </td>
														<td><a href="#"><span class="list-enq-name">{{ $value->quote_name }}</span>
														<!--<span class="list-enq-city">Illunois, United States</span>-->
														</a> </td>
														<td>{{ $value->quote_mobile }}</td>
														<td>{{ $value->quote_email }}</td>
														<td> <span class="label label-primary">Un Read</span> </td>
														<td> <span class="label label-primary">View</span> </td>
													</tr>
													@endforeach
													@endif
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="split-row">
							<div class="col-md-12">
								<div class="box-inn-sp">
									<div class="inn-title">
										<h4>New User Details</h4>
										<p>Airtport Hotels The Right Way To Start A Short Break Holiday</p> <a class="dropdown-button drop-down-meta" href="#" data-activates="dr-users"><i class="material-icons">more_vert</i></a>
										<ul id="dr-users" class="dropdown-content">
											<li><a href="#!">Add New</a> </li>
											<li><a href="#!">Edit</a> </li>
											<li><a href="#!">Update</a> </li>
											<li class="divider"></li>
											<li><a href="#!"><i class="material-icons">delete</i>Delete</a> </li>
											<li><a href="#!"><i class="material-icons">subject</i>View All</a> </li>
											<li><a href="#!"><i class="material-icons">play_for_work</i>Download</a> </li>
										</ul>
										<!-- Dropdown Structure -->
									</div>
									<div class="tab-inn">
										<div class="table-responsive table-desi">
											<table class="table table-hover">
												<thead>
													<tr>
														<!--<th>Select</th>-->
														<th>Image</th>
														<th>Name</th>
														<th>Email</th>
														<th>Phone</th>
														<!--<th>Address</th>-->
														<th>Listings</th>
														<th>Enquiry</th>
														<!--<th>Bookings</th>-->
														<th>Reviews</th>
													</tr>
												</thead>
												<tbody>
												    @if($userRs)
												    @foreach($userRs as $value)
													<tr>
														<!--<td>
															<input type="checkbox" class="filled-in" id="filled-in-box-1" />
															<label for="filled-in-box-1"></label>
														</td>-->
														<td><span class="list-img"><img src="images/users/1.png" alt=""></span> </td>
														<td>
														    <a href="#"><span class="list-enq-name">{{ $value->first_name }}</span>
														<span class="list-enq-city">{{ $value->address }}</span>
														    </a> </td>
														<td>{{ $value->email }}</td>
														<td>{{ $value->mobile_no }}</td>
														<td> <span class="label label-primary">{{ $value->businessCnt }}</span> </td>
														<td> <span class="label label-danger">{{ $value->enquiryCnt }}</span> </td>
														<!--<td> <span class="label label-success">24</span> </td>-->
														<td> <span class="label label-info">{{ $value->reviewCnt }}</span> </td>
													</tr>
													@endforeach
													@endif
													
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				@stop