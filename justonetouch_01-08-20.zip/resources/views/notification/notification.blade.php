<style>
    .alert-success {
    color: #fff;
    background-color: #3c763d;
    border-color: #3c763d;
    font-size: 13px;
}
.jconfirm-content {
    font-size:13px;
}


.sb2-2-2 ul li {
    list-style-type: circle;
    float: none;
   
}
.alert > p, .alert > ul {
    margin-bottom: 0;
    padding: 13px;
}

alert-danger {
    color: #fff; 
    background-color: #a94442;
    border-color: #a94442;
}

    </style>
@if(Session::has('message'))

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
            <i class="icon-tick"></i>{{ Session::get('message') }}!
        </div>
    </div>

@endif
@if(Session::has('success'))

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
            <i class="icon-tick"></i>{{ Session::get('success') }}!
        </div>
    </div>

@endif
@if(Session::has('error'))
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
    <div class="alert alert-danger">
        <i class="icon-warning2"></i>{{ Session::get('error') }}!
    </div>   
    </div>
@endif
@if(Session::has('errors'))
@foreach ($errors as $error)
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <i class="icon-warning2"></i>{{ $error }}
        </div>
    </div>

@endforeach
@endif






