<div id="proadd">
    @if(isset($commentRs))
        @foreach ($commentRs as $commentrow)
            <li>
				<div class="lr-user-wr-img"> <img src="{{asset('public/images/users/2.png')}}" alt=""> </div>
				<div class="lr-user-wr-con">
					<h6>{{ $commentrow->first_name }} <span>{{ $commentrow->rating }}  <i class="fa fa-star" aria-hidden="true"></i></span></h6> 
					<span class="lr-revi-date" style="float: right;margin-top: -36px;">
						{{Carbon\Carbon::parse($commentrow->created_at)->diffForHumans()}}						
						</span>
					<p>{{ $commentrow->comment }}  </p> 
					<ul>
						<li><a href="#!"><span>Like</span><i class="fa fa-thumbs-o-up" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><span>Dis-Like</span><i class="fa fa-thumbs-o-down" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><span>Comments</span> <i class="fa fa-commenting-o" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><span>Share Now</span>  <i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
						<li><a href="#!"><i class="fa fa-youtube" aria-hidden="true"></i></a> </li>
					</ul>
				</div>
			</li>
        @endforeach
    @endif
</div>