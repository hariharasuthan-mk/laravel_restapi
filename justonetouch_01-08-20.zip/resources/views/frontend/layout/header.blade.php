	<?php
 $ipaddress = $_SERVER['REMOTE_ADDR'];
 $page = "http://".$_SERVER['HTTP_HOST']."".$_SERVER['PHP_SELF'];
// $referrer = $_SERVER['HTTP_REFERER'];
 $datetime = date("F j, Y, g:i a");
 $useragent = $_SERVER['HTTP_USER_AGENT'];
?>

<script>
     $(document).ready(function(){
        //alert("dasdasd");
        //var _token = $("input[name='_token']").val();
        var ipaddr = "<?php echo $ipaddress; ?>";
        //var current_page = "<?php echo $page; ?>";
        var view_time = "<?php echo $datetime; ?>";
        var browser = "<?php echo $useragent; ?>";
        var current_page = "{{ Request::fullUrl() }}";
        //alert(fullurl);
      
        $.ajax({
            url: "{{url('visitorinfo')}}",
            type:'POST',
            data: {"_token": $('meta[name="csrf-token"]').attr('content'),"ipaddr":ipaddr, "current_page":current_page, "view_time":view_time, "browser":browser},
            //data: {"ipaddr":ipaddr, "current_page":current_page, "view_time":view_time, "browser":browser},
            success: function(data) {
            if($.isEmptyObject(data.error)){
                    //alert(data.id);
                    console.log("Success");
                    if(data.status==1)
                    {
                        console.log("Success");
                    }
                    else
                    {
                        //alert("first err");
                        //printErrorMsg(data.errors);
                    }
                   
                }else{
                    //alert("second err");
                    //printErrorMsg(data.errors);
                }
                
            }
        });
       
    });
    </script>