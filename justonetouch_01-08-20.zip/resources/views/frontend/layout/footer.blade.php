<footer id="colophon" class="site-footer clearfix" style="background-color: #a94442;color: white !important;">
		<div id="quaternary" class="sidebar-container" role="complementary">
			<div class="sidebar-inner">
				<div class="widget-area clearfix">
					<div id="azh_widget-2" class="widget widget_azh_widget">
						<div data-section="section">
							<div class="container">
								<div class="row">
									<div class="col-sm-4">
										<h4 style="color:#fff">Address</h4>
										
										<!--<p style="color:#fff">5/79, SRINIVASA PERUMAL KOIL STREET, SADHANANDHAPURAM, IRANDAM KATTALAI Chennai TAMILNADU 600070 IN</p>
										<p style="color:#fff"> <span class="strong" style="color:#fff">Phone: </span> <span style="color:#fff" class="highlighted">7825881881</span> </p>-->
										<p style="color:#fff">No.16, Bhuvaneswari Nagar, Koyambedu(Mettukuppam), Chennai - 600 107</p>
										<p style="color:#fff"> <span class="strong" style="color:#fff">Phone: </span> <span style="color:#fff" class="highlighted">9159999688</span> </p>
										<p style="color:#fff"> <span class="strong" style="color:#fff">Email: </span> <span style="color:#fff" class="">&nbsp;&nbsp;admin@justonetouch.in</span> </p>
										<!--<p style="color:#fff"> <span class="strong">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</span> <span class="highlighted" style="color:#fff">9159999688</span> </p>-->
									</div>
									<div class="col-sm-4" style="color:#fff">
										<h4 style="color:#fff">Support & Help</h4>
										<ul class="two-columns" style="color:#fff">
											<li> <a href="#" style="color:#fff">Advertise us</a> </li>
											<li> <a href="#" style="color:#fff">About Us</a> </li>
											<li> <a href="#" style="color:#fff">Review</a> </li>
											<li> <a href="#" style="color:#fff">How it works </a> </li>
											<li> <a href="#" style="color:#fff">Add Business</a> </li>
											<li> <a href="#!" style="color:#fff">Register</a> </li>
											<li> <a href="#!" style="color:#fff">Login</a> </li>
											<li> <a href="#!" style="color:#fff">Quick Enquiry</a> </li>
											<li> <a href="#!" style="color:#fff">Ratings </a> </li>
											<li> <a href="trendings.html" style="color:#fff">Top Trends</a> </li>
										</ul>
									</div>
									<div class="col-sm-4 foot-social">
											<h4 style="color:#fff">Follow with us</h4>
										<p style="color:#fff">Join the thousands of other There are many variations of passages of Lorem Ipsum available</p>
										<ul>
											<li><a href="#!" style="color:#fff"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
											<li><a href="#!" style="color:#fff"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
											<li><a href="#!" style="color:#fff"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
											<li><a href="#!" style="color:#fff"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
											<li><a href="#!" style="color:#fff"><i class="fa fa-youtube" aria-hidden="true"></i></a> </li>
											<li><a href="#!" style="color:#fff"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> </li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				<!-- .widget-area -->
			</div>
			<!-- .sidebar-inner -->
		</div>
		<!-- #quaternary -->
	</footer>
	

	
	