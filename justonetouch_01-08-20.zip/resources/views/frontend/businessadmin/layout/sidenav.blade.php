<div class="tz-l">
				<div class="tz-l-1">
					<ul>
					    @if(Request::user()->user_image)
						<li><img src="{{Request::user()->user_image_path}}thumbnail/{{Request::user()->user_image}}" alt="" style="height:250px !important; width:350px !important;"/> </li>
						@else
						<li><img src="{{asset('public/images/db-profile.jpg')}}" alt="" /> </li>
						@endif
						<li><span>80%</span> profile compl</li>
						<li><span>18</span> Notifications</li>
					</ul>
				</div>
				<div class="tz-l-2">
					<ul>
						<li>
							<a href="{{ url('businessadmin') }}" class="tz-lma"><img src="{{asset('public/images/icon/dbl1.png')}}" alt="" /> My Dashboard</a>
						</li>
						<li>
							<a href="{{ url('businesslist') }}"><img src="{{asset('public/images/icon/dbl2.png')}}" alt="" /> All Listing</a>
						</li>
						<li>
							<a href="{{ url('businessadd') }}"><img src="{{asset('public/images/icon/dbl3.png')}}" alt="" /> Add New Listing</a>
						</li>
						<!--<li>
							<a href="db-message.html"><img src="{{asset('public/images/icon/dbl14.png')}}" alt="" /> Messages(12)</a>
						</li>-->
						<li>
							<a href="{{ url('reviewlist') }}"><img src="{{asset('public/images/icon/dbl13.png')}}" alt="" /> Reviews</a>
						</li>
						<li>
							<a href="{{ url('profileview') }}"><img src="{{asset('public/images/icon/dbl6.png')}}" alt="" /> My Profile</a>
						</li>
						<li>
							<a href="{{ url('adsummary') }}"><img src="{{asset('public/images/icon/dbl11.png')}}" alt="" /> Ad Summary</a>
						</li>
						<li>
							<a href="{{ url('checkout') }}"><img src="{{asset('public/images/icon/dbl9.png')}}" alt=""> Check Out</a>
						</li>
						<li>
							<a href="{{ url('invoiceall') }}"><img src="{{asset('public/images/icon/db21.png')}}" alt="" /> Invoice</a>
						</li>						
						<!--<li>
							<a href="db-claim.html"><img src="{{asset('public/images/icon/dbl7.png')}}" alt="" /> Claim & Refund</a>
						</li>-->
						<li>
							<a href="{{ url('setting') }}"><img src="{{asset('public/images/icon/dbl210.png')}}" alt="" /> Setting</a>
						</li>
						<li>
							<a href="{{ url('logout') }}"><img src="{{asset('public/images/icon/dbl12.png')}}" alt="" /> Log Out</a>
						</li>
					</ul>
				</div>
			</div>