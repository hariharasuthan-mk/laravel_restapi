<!--SCRIPT FILES-->
	<script src="{{asset('public/js/jquery.min.js')}}"></script>
	<script src="{{asset('public/js/bootstrap.js')}}"></script>
	<script src="{{asset('public/js/materialize.min.js')}}"></script>
	<script src="{{asset('public/js/custom.js')}}"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>