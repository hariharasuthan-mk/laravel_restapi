@extends('frontend.businessadmin.default')
@section('content')
<style>
.timespan {
	float: right;
    margin-top: -31px;
    background-color: #ccc;
    padding: 1px 14px;
}
</style>

<div class="tz-2-com tz-2-main">
					<h4>{{$businessDetails->business_title}}</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Reviews</h2>
							<p>Review approve, edit, delete and review replay options here..</p>
						</div>
						<div class="tz-mess">
							<ul>
							    @if(!empty($reviewList))
							    @foreach($reviewList as $reviewval)
							    @if(!empty($reviewval))
								<li class="view-msg">
									<h5><img src="{{ asset('public/images/users/1.png')}}" alt="" />{{ $reviewval->first_name }} 
									 

									<span class="tz-revi-star" style="color:#64addb"><strong>{{ $reviewval->rating }}</strong> <i class="fa fa-star" aria-hidden="true"></i></span>
									
									</h5>
									<!--<span class="timespan">{{Carbon\Carbon::parse($reviewval->created_at)->diffForHumans()}}</span>-->
									<span class="timespan">{{date("d-M-Y h:i:s",strtotime($reviewval->created_at))}}</span>
									<p>{{ $reviewval->comment }}</p>
									
									<div class="hid-msg"><a href="#!"><i class="fa fa-check" title="approve this review"></i></a><a href="#!"><i class="fa fa-edit" title="edit"></i></a><a href="#!"><i class="fa fa-trash" title="delete"></i></a><a href="#!"><i class="fa fa-reply edit-replay" title="replay"></i></a>
										<form class="col s12 hide-box">
											<div class="">
												<div class="input-field col s12">
													<textarea class="materialize-textarea"></textarea>
													<label>Write your replay</label>
												</div>
												<div class="input-field col s12">
													<input type="submit" value="Submit" class="waves-effect waves-light btn-large"> </div>
											</div>
										</form>
									</div>
								</li>
							        @endif
								@endforeach 
							@else
							<li class="view-msg">
									<h5>No Reviews Found</h5>
							</li>
							@endif
							</ul>
						</div>
						
					</div>
				</div>
				@stop