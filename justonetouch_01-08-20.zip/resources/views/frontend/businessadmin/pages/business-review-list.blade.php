@extends('frontend.businessadmin.default')
@section('content')
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
.list-pagenat {
	loat: right;
    background-color: #eee;    
    margin-bottom: 14px;
    margin-right: 21px;
}
</style>

<div class="tz-2-com tz-2-main">

					<h4>Business Review Listings</h4>

				
					<div class="db-list-com tz-db-table">
					@include('notification.notification')
						<div class="ds-boar-title">  
							<h2>Business List</h2>  
						</div>
						<table class="responsive-table bordered">
							<thead>
								<tr>
								  
									<th>Listing Name</th>
									<th>Date</th>
									<th>Rating</th>
									<th>Total Review</th>
									<th>View Details</th>
								</tr>
							</thead>
							<tbody>
							    @if($businessList)
    					            @foreach($businessList as $value)
								<tr>
								    
									<td>{{ $value->business_title }}</td>
									<td>{{ $value->created_at }}</td>
									<td><span class="db-list-rat">{{$value->review}}</span></td>
									<td><span class="db-list-rat">{{$value->total_review}}</span></td>
									
									 <td><a href="{{url('review-Detials/'.$value->id)}}" class="db-list-edit"><i class="fa fa-eye"></i></a></td>
								</tr>
								    @endforeach
					            @endif
							</tbody>
						</table>
					
					</div>
					 
						{{ $businessList->links('pagination.custom') }}
						
				</div>

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

				<script>
             
			  
                

				$('.delete').click(function(){

				var id =$(this).attr('rel'); 

				$.confirm ({

					title : "Confirmation.!",
					content : "Are you sure want to delete this listing.?",

					buttons : {
					confirm : function(){
                        window.location = "{{url('businessdelete')}}" + "/" + id;
					},
					cancel : function() {
						

					}
					}

				});
			    
				});
				
				</script>
				
				@stop