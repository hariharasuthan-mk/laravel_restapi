@extends('frontend.businessadmin.default')
@section('content')

<div class="tz-2-com tz-2-main">
					<h4>Ads</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Post your Ads</h2>
							<p>Note: Ads banner size - Header-900px X 150px, Footer-900px X 150px, Home-400px X 400px, Listing-400px X 400px, Supported file formets .jpg, .png, .jpeg, .gif</p>
						</div>
						<div class="tz2-form-pay tz2-form-com">
							<form class="col s12">
								<div class="row">
									<div class="input-field col s12">
										<input type="number" class="validate">
										<label>User Name</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12 m6">
										<input type="email" class="validate">
										<label>Email id</label>
									</div>
									<div class="input-field col s12 m6">
										<input type="number" class="validate">
										<label>Phone</label>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<select>
											<option value="" disabled selected>Where your Ads show</option>
											<option value="1">Home Page</option>
											<option value="2">Listing Page</option>
											<option value="3">Footer Part</option>
											<option value="3">Header Part</option>
										</select>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<select>
											<option value="" disabled selected>Select Duration</option>
											<option value="1">Demo - 5mins - Free</option>
											<option value="1">One Day - $10</option>
											<option value="1">One Week - $50</option>
											<option value="2">One Month - $ 200</option>
											<option value="3">Two Months - $350</option>
											<option value="3">Six Months - $700</option>
											<option value="3">One Year - $1000</option>
										</select>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<select>
											<option value="" disabled selected>Select Status</option>
											<option value="1">Active</option>
											<option value="2">Non-Active</option>
										</select>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<input type="text" class="validate">
										<label>Date will show (DD/MM/YYYY)</label>
									</div>
								</div>
								<div class="row tz-file-upload">
									<div class="file-field input-field">
										<div class="tz-up-btn"> <span>File</span>
											<input type="file"> </div>
										<div class="file-path-wrapper">
											<input class="file-path validate" type="text"> </div>
									</div>
								</div>
								<div class="row">
									<div class="input-field col s12">
										<input type="submit" value="SUBMIT ADS" class="waves-effect waves-light full-btn"> </div>
								</div>
							</form>
						</div>
						<div class="db-mak-pay-bot">
							<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters</p> <a href="db-setting.html" class="waves-effect waves-light btn-large">Ads Settings</a> </div>
					</div>
				</div>
				
				@stop