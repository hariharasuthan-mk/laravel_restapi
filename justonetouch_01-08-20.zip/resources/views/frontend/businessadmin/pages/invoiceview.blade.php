@extends('frontend.businessadmin.default')
@section('content')

<div class="tz-2-com tz-2-main">
					<h4>Invoice</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Amazon Directory</h2>
							<p>All the Lorem Ipsum generators on the All the Lorem Ipsum generators on the</p>
						</div>
						<div class="invoice">
							<div class="invoice-1">
								<div class="invoice-1-logo">
									<img src="{{ asset('public/images/invoice-logo.png')}}" alt=""><span>invoice</span>
								</div>
								<div class="invoice-1-add">
									<div class="invoice-1-add-left">
										<h3>John smith</h3>
										<p>28800 Orchard Lake Road, Suite 180 Farmington Hills, U.S.A. </p>
										<h5>Bill To</h5>
										<p>Email: johnsmith@gmail.com</p>
									</div>
									<div class="invoice-1-add-right">
										<ul>
											<li><span>Invoice Number</span> ad4582456987</li>
											<li><span>Date</span> 07 Jul 2017</li>
											<li><span>Payment Terms</span> Due on receipt</li>
											<li><span>Due Date</span> 07 Jul 2017</li>
										</ul>
									</div>
								</div>
								<div class="invoice-1-tab">
									<table class="responsive-table bordered">
										<thead>
											<tr>
												<th>Description</th>
												<th>Price</th>
												<th>Duration</th>
												<th>Subtotal</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>Premium listing update</td>
												<td>$50</td>
												<td>2 year</td>
												<td class="invo-sub">$100.00</td>									
											</tr>
											<tr>
												<td>Leads</td>
												<td>$100</td>
												<td>4 year</td>
												<td class="invo-sub">$400.00</td>									
											</tr>											
										</tbody>
									</table>								
								</div>
							</div>
							<div class="invoice-2">
								<div class="invoice-price">
									<table class="responsive-table bordered">
										<thead>
											<tr>
												<th>Bank info</th>
												<th>Due By</th>
												<th>Total Due</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>Premium listing update</td>
												<td id="invo-date">18 May '17</td>
												<td id="invo-tot">$500.00</td>									
											</tr>											
										</tbody>
									</table>								
								</div>							
							</div>
							<div class="invoice-print">
							<p>Thank you,<br>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
							<a href="{{ url('checkout') }}" class="waves-effect waves-light btn-large">Pay Invoice</a><a href="{{ url('invoiceprint') }}" target="_blank" class="waves-effect waves-light btn-large">Print</a> 
							<a href="{{ url('invoiceprint') }}" target="_blank" class="waves-effect waves-light btn-large">Download PDF</a> </div>
						</div>
					</div>
				</div>
				
				@stop