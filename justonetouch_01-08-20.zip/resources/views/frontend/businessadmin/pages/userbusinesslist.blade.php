@extends('frontend.businessadmin.default')
@section('content')
<style>
.list-pagenat {
    loat: right;
    background-color: #eee;    
    margin-bottom: 14px;
    margin-right: 21px;
}
</style>

<div class="tz-2-com tz-2-main">

					<h4>Manage Listings</h4>

				
					<div class="db-list-com tz-db-table">
					@include('notification.notification')
						<div class="ds-boar-title">
							<h2>Listings</h2>
						</div>
						<table class="responsive-table bordered">
							<thead>
								<tr>
									<th>Listing Name</th>
									<th>Date</th>
									<th>Rating</th>
									<th>Views</th>
									<th>Status</th>
									<th>Edit</th>
									<th>Delete</th>
									<th>Preview</th>
								</tr>
							</thead>
							<tbody>
							    @if($businessList)
    					            @foreach($businessList as $value)
								<tr>
									<td>{{ $value->business_title }}</td>
									<td>{{ $value->created_at }}</td>
									<td><span class="db-list-rat">{{$value->review}}</span></td>
									<td><span class="db-list-rat">{{$value->view_count}}</span></td>
									
									<td>
									@if($value->status==1)
									<span class="db-list-ststus"> {{ "Active" }} </span>
									@else
									<span class="db-list-ststus-na"> {{ "InActive" }} </span>
									@endif
									</td>
									<td><a href="{{url('businessadd/'.$value->id)}}" class="db-list-edit">Edit</a></td>
									<td><a href="javascript:void(0)" class="db-list-edit delete" rel="{{$value->id}}">Delete</a></td>
									<td><a href="{{url('preview-business/'.$value->id)}}" class="db-list-edit"><i class="fa fa-eye"></i></a></td>
								</tr>
								    @endforeach
					            @endif
							</tbody>
						</table>
					</div>
					{{ $businessList->links('pagination.custom') }}
				</div>

				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

				<script>

				

				$('.delete').click(function(){

				var id =$(this).attr('rel'); 

				$.confirm ({

					title : "Confirmation.!",
					content : "Are you sure want to delete this listing.?",

					buttons : {
					confirm : function(){
                        window.location = "{{url('businessdelete')}}" + "/" + id;
					},
					cancel : function() {
						

					}
					}

				});
			    
				});
				
				</script>
				
				@stop