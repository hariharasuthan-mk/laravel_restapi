@extends('frontend.businessadmin.default')
@section('content')

<div class="tz-2-com tz-2-main">
					<h4>Manage My Profile</h4>
					<div class="db-list-com tz-db-table">
						<div class="ds-boar-title">
							<h2>Profile</h2>
						</div>
						
						<table class="responsive-table bordered">
						    @if($profileList)
    					        @foreach($profileList as $value)
							<tbody>
								<tr>
									<td>Name</td>
									<td>:</td>
									<td>{{ $value->first_name}}</td>
								</tr>
								<tr>
									<td>Password</td>
									<td>:</td>
									<td>*********</td>
								</tr>
								<tr>
									<td>Eamil</td>
									<td>:</td>
									<td>{{ $value->email}}</td>
								</tr>
								<tr>
									<td>Phone</td>
									<td>:</td>
									<td>{{ $value->mobile_no}}</td>
								</tr>
								<tr>
									<td>Address</td>
									<td>:</td>
									<td>{{ $value->address}}</td>
								</tr>
								<tr>
									<td>Status</td>
									<td>:</td>
									<td><span class="db-done">@if($value->is_active==1) {{ "Active" }} @else {{ "InActive" }} @endif</span> </td>
								</tr>
							</tbody>
							@endforeach
					    @endif
						</table>
						<div class="db-mak-pay-bot">
							<a href="{{ url('profileedit') }}/{{ $value->id }}" class="waves-effect waves-light btn-large">Edit my profile</a> </div>
					</div>
				</div>
				
				@stop