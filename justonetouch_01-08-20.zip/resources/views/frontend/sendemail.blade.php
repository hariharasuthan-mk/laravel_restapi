<!DOCTYPE html>
<html>
  <head>
    <title>Welcome Email</title>
  </head>
  <body>
    <h2>Welcome to the site {{$temp->name}}</h2>
    <br/>
    Your registered email-id is {{$temp->email}} , Please click on the below link to verify your email account
    <br/>
    <a href="{{url('user/verify', $temp->uuid)}}">Verify Email</a>
  </body>
</html>