<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<!-- FAV ICON(BROWSER TAB ICON) -->
	<link rel="shortcut icon" href="images/fav.ico" type="image/x-icon">
	<!-- GOOGLE FONT -->
	<link href="https://fonts.googleapis.com/css?family=Poppins%7CQuicksand:500,700" rel="stylesheet">
	<!-- FONTAWESOME ICONS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/font-awesome.min.css')}}" />
	<!-- ALL CSS FILES -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/materialize.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/style.css')}}" />
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/bootstrap.css')}}" />
	
	<!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
	<link rel="stylesheet" type="text/css" href="{{asset('public/css/responsive.css')}}" />
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	@include('frontend.businessadmin.layout.scripts')

	<style>
	    .typeahead-search {
    position: relative;
}

.dropdown-menu {
    width: 100%;
}
.container .row {
  
    width: 97%;
}
.error
{
    color:red;
	font-size:14px;
	
}
.field-icons {
	float: right;
    margin-top: -29px;
    margin-right: 11px;
    position: inherit;   
    font-size: 15px;
	
}
.hom-cre-acc-left ul li {  
    padding-bottom: 4px;    
}
.hom-cre-acc-left ul {  
    padding-bottom: 4px; 
	margin-top: 0px;   
}

.alert-danger {
    color: #ff6a6a;
    
}

.alert-success {
   
    background-color: #7bbb7d;
}
	</style>

<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>
<script>
    $(document).ready(function () {

        $("#signupForm").validate({
            errorElement: "div",
            //set the rules for the field names

            rules: {
             
                name: {
                    required: true					
                },
                mobile: {
                    required: true,
					minlength : 10,
					maxlength :10					
                },
				
				email: {
                    required: true,
					email:true,					
                },
				password: {
                    required: true					
                },
				confirmPassword: {
                    required: true,
					equalTo : '#acc-pass',					
                },
				
            },
            //set messages to appear inline
            messages: {
               
                name: {
                    required : "Name is required."
					
                },
                mobile: {
                    required: "Mobile Number is required.",
					minlength : "Mobile number should be 10 digits.",
					maxlength :"Mobile number should be 10 digits.",								
                },
				email: {
                    required: "Email is required.",
					email: " please Enter the valid email.",					
                },
				password: {
                    required: "Password is required."					
                },
				confirmPassword: {
                    required: "ConfirmPassword is required.",
					equalTo : "Password and Confirm passsword is not same."					
                },

            },
            errorPlacement: function (error, element) {
                error.appendTo(element.parent());
            }
        });
 });
 jQuery.validator.setDefaults({
	 ignore: ""
 });

 
	</script>
	
	<script>
	    $(document).ready(function() {
    
    $("#btnSubmit").click(function(e){
        e.preventDefault();
		
        var _token = $("input[name='_token']").val();
        var name = $("input[name='name']").val();
        var email = $("input[name='email']").val();
        var mobile = $("input[name='mobile']").val();
        var active = $("input[name='active']").val();
        var password = $("input[name='password']").val();
        var confirmPassword = $("input[name='confirmPassword']").val();
        //var address = $("textarea[name='confirmPassword']").val();

		if($("#signupForm").valid()){

        $.ajax({
            url: "{{url('/signup')}}",
            type:'POST',
            data: {_token:_token, name:name, email:email, mobile:mobile, active:active, password:password, confirmPassword:confirmPassword},
            success: function(data) {
            if($.isEmptyObject(data.error)){
                    //alert(data.id);
                    if(data.status==1)
                    {
                        //console.log("Success");
                        $("#acc-id").val(data.id);
                        $("#verifydiv").show();
						$('.alert alert-danger').hide();
                        $("#signupdiv").hide();
						
						printSucessMsg(['Otp has been sent to registered mobile number.Please check.']);
					}
                    else
                    {
                        //alert("first err");
                        printErrorMsg(data.errors);
                    }
                   
                }else{
                    //alert("second err");
                    printErrorMsg(data.errors);
                }
                
            }
        });
		}
		
    });
    
    $("#btnSubmitOtp").click(function(e){
        e.preventDefault();
        var _token = $("input[name='_token']").val();
        var userid = $("input[name='userid']").val();
        var otp = $("input[name='otp']").val();


        $.ajax({
            url: "{{url('/verifyotp')}}",
            type:'POST',
            data: {_token:_token, userid:userid, otp:otp},
            success: function(data) {
            if($.isEmptyObject(data.error)){
                    //alert(data.status);
                    if(data.status==1)
                    {
                        console.log("Success");
                        window.location="{{URL::to('/businessadmin')}}";
                    }
                    else
                    {
						console.log("SSSS");
                        //alert("first err"+data.errors);
                        printErrorMsg(data.errors);
                    }
                    
                }else{
					console.log("VV");
                    //alert("second err");
                    printErrorMsg(data.errors);
                }
                
            }
        });
    });

	function printSucessMsg (msg) {
            $(".print-success-msg").find("ul").html('');
            $(".print-success-msg").css('display','block');
			$(".print-error-msg").css('display','none');
            $.each(msg, function( key, value ) {
                $(".print-success-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
    
        function printErrorMsg (msg) {
            $(".print-error-msg").find("ul").html('');
            $(".print-error-msg").css('display','block');
			$(".print-success-msg").css('display','none');
            $.each(msg, function( key, value ) {
                $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
            });
        }
        
});

var inpt;

function handleInput(inpt) {

	
	console.log(inpt);
	var len = inpt.length;
	console.log(len);

	if(len > 0){	
		//console.log('A');
      $('.field-icon').show();
	}
	else if( inpt.length == 0){
		//console.log('B');
		$('.field-icon').hide();
	}
}

function viewPassword(){

	var input = $('#acc-pass').val();
	var attribute = $('#acc-pass').attr('type');
	
	if(attribute == 'password'){		
		$('#acc-pass').attr('type','text');
		$('.field-icons').removeClass('fa-eye-slash').addClass('fa-eye');
	}else {
		
		$('#acc-pass').attr('type','password');
		$('.field-icons').removeClass('fa-eye').addClass('fa-eye-slash');
	}
}

function viewConfirmPassword(){
	if($('#acc-cnpass').attr('type') =='password'){
		$('#acc-cnpass').attr('type','text');
	}else{
		$('#acc-cnpass').attr("type",'password');
	}
}
	</script>
	
</head>

<body data-ng-app="">
	
	<div id="preloader">
		<div id="status">&nbsp;</div>
	</div>
	<!--TOP SEARCH SECTION-->
	@include('frontend.businessadmin.layout.topheader')
	<section class="tz-register">
			<div class="log-in-pop" style="width:80%">
				
				<div class="container">
			<div class="row">
				<div class="com-title">
					<h2 style="margin-top: 10px">Create a free <span>Account</span></h2>
					<p>Explore some of the best tips from around the world from our partners and friends.</p>
				</div>
				<div class="col-md-6">
					<div class="hom-cre-acc-left">
						<h4>A few reasons you’ll love Online <span>Business Directory</span></h4>
						<p> Benefits of Listing Your Business to a Local Online Directory</p>
						<ul>
							<li> <img src="{{asset('public/images/icon/7.png')}}" alt="">
								<div>
									<h5>Enhancing Your Business</h5>
									<p>Imagine you have made your presence online through a local online directory, but your competitors have..</p>
								</div>
							</li>
							<li> <img src="{{asset('public/images/icon/5.png')}}" alt="">
								<div>
									<h5>Advertising Your Business</h5>
									<p>Advertising your business to area specific has many advantages. For local businessmen, it is an opportunity..</p>
								</div>
							</li>
							<li> <img src="{{asset('public/images/icon/6.png')}}" alt="">
								<div>
									<h5>Develop Brand Image</h5>
									<p>Your local business too needs brand management and image making. As you know the local market..</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-md-6">
					<div class="hom-cre-acc-left hom-cre-acc-right" style="padding-right: 100px;">                          
                        <p>@include('notification.notification')</p>
                        <div class="alert alert-danger print-error-msg" style="display:none">
                            <ul></ul>
						</div>
						<div class="alert alert-success print-success-msg" style="display:none">
                            <ul></ul>
                        </div>

						<form method="post" action="{{ url('signup') }}" style="padding-right:15px;" id="signupForm">
						    <div id="signupdiv">
							<div class="row">
								<div class="input-field col s12">
								    <input type="hidden" name="_token" value="{{ csrf_token() }}">
									<input id="acc-names" type="text" name="name" class="validate" placeholder="Enter Your Name">
									<label for="acc-names">Name</label>
								</div>
							</div>
							<div class="row">
								<div class="input-field col s12">
									<input id="acc-mob" type="number" name="mobile" class="validate" placeholder="Enter Your Mobile Number">
									<label for="acc-mob">Mobile</label>
								</div>
							</div>
							<div class="row">
								<div class="input-field col s12">
									<input id="acc-mail" type="email" name="email" class="validate" placeholder="Enter Your Email">
									<label for="acc-mail">Email</label>
								</div>
							</div>
							<div class="row">
								<div class="input-field col s12">
									<input id="acc-pass" type="password" keyup="handleInput(this.value)" name="password" class="validate" placeholder="Enter Your Password">
									<i id="pass-status" class="fa fa-eye-slash field-icons" style="" aria-hidden="true" onClick="viewPassword()"></i>
									<label for="acc-pass">Password</label>
								</div>
							</div>
							<div class="row">
								<div class="input-field col s12">
									<input id="acc-cnpass" type="password"  name="confirmPassword" class="validate" placeholder="Enter Your Confirm Password">
									<i id="pass-status" class="fa fa-eye-slash field-icons" style="" aria-hidden="true" onClick="viewConfirmPassword()"></i>

									<label for="acc-cnpass">Confirm Password</label>
								</div>
							</div>
							<div class="row">
								<div class="col s12 hom-cr-acc-check">
								    <input type="checkbox" id="test5" class="custom-control-input" name="active" value="1">
									<label for="test5">By signing up, you agree to the Terms and Conditions and Privacy Policy. You also agree to receive product-related emails.</label>
								</div>
							</div>
							<div class="row">
							    <button class="waves-effect waves-light btn-large full-btn" type="button" id="btnSubmit" name="action">Submit
    
                            </button>
                        </div>
  
					    </div>
						<div id="verifydiv" style="display:none">
						<span id="otpSendSuccess"></span>
					        <div class="row">
					            <label for="acc-name"> Enter OTP</label>
								<div class="input-field col s12">
								    <label for="acc-name">OTP</label>
									 <input type="hidden" name="_token" value="{{ csrf_token() }}">
									 <span id="otpErrorMsg"></span>
								    <input id="acc-id" type="hidden" name="userid" class="validate" placeholder="Enter Your ID">
									<input id="acc-name" type="text" name="otp" class="validate" placeholder="Enter Your Name" >
									
								</div>
							</div>
							<br>
							<div class="row">
							    <button class="waves-effect waves-light btn-large full-btn" type="submit" id="btnSubmitOtp" name="action">Submit
    
                            </button>
					   </div>
				</div>
				</form>
			</div>
		</div>
				
			</div>
	</section>
	<!--MOBILE APP-->
	<section class="web-app com-padd">
		<div class="container">
			<div class="row">
				<div class="col-md-6 web-app-img"> <img src="{{asset('public/images/mobile.png')}}" alt="" /> </div>
				<div class="col-md-6 web-app-con">
					<h2>Looking for the Best Service Provider? <span>Get the App!</span></h2>
					<ul>
						<li><i class="fa fa-check" aria-hidden="true"></i> Find nearby listings</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Easy service enquiry</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Listing reviews and ratings</li>
						<li><i class="fa fa-check" aria-hidden="true"></i> Manage your listing, enquiry and reviews</li>
					</ul> <span>We'll send you a link, open it on your phone to download the app</span>
					<form>
						<ul>
							<li>
								<input type="text" placeholder="+01" /> </li>
							<li>
								<input type="number" placeholder="Enter mobile number" /> </li>
							<li>
								<input type="submit" value="Get App Link" /> </li>
						</ul>
					</form>
					<a href="#"><img src="{{asset('public/images/android.png')}}" alt="" /> </a>
					<a href="#"><img src="{{asset('public/images/apple.png')}}" alt="" /> </a>
				</div>
			</div>
		</div>
	</section>
	<!--FOOTER SECTION-->
		@include('frontend.layout.footer')
	<!--COPY RIGHTS-->
	<section class="copy">
		<div class="container">
			<p>copyrights © <span id="cryear">2019</span> justonetouch.in &nbsp;&nbsp;All rights reserved. </p>
		</div>
	</section>
	<!--QUOTS POPUP-->
	<section>
		<!-- GET QUOTES POPUP -->
		<div class="modal fade dir-pop-com" id="list-quo" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header dir-pop-head">
						<button type="button" class="close" data-dismiss="modal">×</button>
						<h4 class="modal-title">Get a Quotes</h4>
						<!--<i class="fa fa-pencil dir-pop-head-icon" aria-hidden="true"></i>-->
					</div>
					<div class="modal-body dir-pop-body">
						<form method="post" class="form-horizontal">
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Full Name *</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="fname" placeholder="" required> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Mobile</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="mobile" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Email</label>
								<div class="col-md-8">
									<input type="text" class="form-control" name="email" placeholder=""> </div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<label class="col-md-4 control-label">Message</label>
								<div class="col-md-8 get-quo">
									<textarea class="form-control"></textarea>
								</div>
							</div>
							<!--LISTING INFORMATION-->
							<div class="form-group has-feedback ak-field">
								<div class="col-md-6 col-md-offset-4">
									<input type="submit" value="SUBMIT" class="pop-btn"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- GET QUOTES Popup END -->
	</section>
	<!--SCRIPT FILES-->

</body>
</html>