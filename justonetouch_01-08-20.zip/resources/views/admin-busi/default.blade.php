<!doctype html>
<html lang="en">
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="Election Admin Panel" />
		<meta name="keywords" content="Election Admin, voters, Election Admin Dashboard" />
		<meta name="author" content="Election Gallery" />
		<link rel="shortcut icon" href="{{asset('public/admin/img/favicon.ico')}}" />
		<title>ELECTION Admin Dashboard</title>
		@include('admin.layout.scripts')
	</head>
	<body>

		<!-- Loading start -->
		<div id="loading-wrapper">
			<div id="loader"></div>
		</div>
		<!-- Loading end -->

		<!-- BEGIN .app-wrap -->
		<div class="app-wrap">

			<!-- BEGIN .app-heading -->
			@include('admin.layout.topheader')   
			<!-- END: .app-heading -->

			<!-- BEGIN .app-container -->
			<div class="app-container">

				<!-- Main nav start -->
				@include('admin.layout.nav') 
				<!-- Main nav end -->

				<!-- BEGIN .page-header -->
{{--				@include('admin.layout.header') --}}
				<!-- END: .page-header -->

				<!-- BEGIN .main-content -->
{{--				<div class="main-content">--}}
					<!-- Row start -->
					@yield('content')

					<!-- Row ends -->
{{--				</div>--}}
				<!-- END: .main-content -->

				<!-- BEGIN .main-footer -->
				<footer class="main-footer">© Election 2019 - 2020</footer>
				<!-- END: .main-footer -->

			</div>
			<!-- END: .app-container -->

		</div>
		<!-- END: .app-wrap -->
	</body>

</html>
