@if(Session::has('message'))

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-success">
            <i class="icon-tick"></i>{{ Session::get('message') }}!
        </div>
    </div>

@endif
@if(Session::has('error'))
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
    <div class="alert alert-danger">
        <i class="icon-warning2"></i>{{ Session::get('error') }}!
    </div>
    <p class="alert {{ Session::get('alert-class', 'alert-danger') }}"></p>
    </div>
@endif
@foreach ($errors as $error)
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
        <div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <i class="icon-warning2"></i>{{ $error }}
        </div>
    </div>

@endforeach




