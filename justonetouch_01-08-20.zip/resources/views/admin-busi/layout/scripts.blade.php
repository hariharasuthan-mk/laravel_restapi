<!--
			**********************
			**********************
			Common CSS files
			**********************
			**********************
		-->
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="{{asset('public/admin/css/bootstrap.min.css')}}" />

		<!-- Icomoon Icons CSS -->
		<link rel="stylesheet" href="{{asset('public/admin/fonts/icomoon/icomoon.css')}}" />

		<!-- Master CSS -->
		<link rel="stylesheet" href="{{asset('public/admin/css/main.css')}}" />

		<!--
			**********************
			**********************
			Optional CSS files
			**********************
			**********************
		-->

		<!-- Circliful CSS -->
		<link rel="stylesheet" href="{{asset('public/admin/vendor/circliful/circliful.css')}}" />

		<!-- C3 CSS -->
		<link rel="stylesheet" href="{{asset('public/admin/vendor/c3/c3.min.css')}}" />
	<!-- Data Tables CSS -->
	<link rel="stylesheet" href="{{asset('public/admin/vendor/datatables/dataTables.bs4.css')}}" />
	<link rel="stylesheet" href="{{asset('public/admin/vendor/datatables/dataTables.bs4-custom.css')}}" />
	

	<!--
			**********************
			**********************
			Common JS files
			**********************
			**********************
		-->

		<!-- jQuery JS. -->
		
		<!-- jQuery JS. -->
		<script src="{{asset('public/admin/js/jquery.js')}}"></script>
		<script src="{{asset('public/admin/js/jquery-ui.min.js')}}"></script>
	

		<!-- Tether Js, then other JS. -->
		<script src="{{asset('public/admin/js/popper.min.js')}}"></script>
		<script src="{{asset('public/admin/js/bootstrap.min.js')}}"></script>

		<!--
			**********************
			**********************
			Add Optional JS files / Plugns
			**********************
			**********************
		-->

		<!-- Data Tables JS -->
		<script src="{{asset('public/admin/vendor/datatables/dataTables.min.js')}}"></script>
		<script src="{{asset('public/admin/vendor/datatables/dataTables.bootstrap.min.js')}}"></script>
		<!-- Custom Data Tables -->
		<script src="{{asset('public/admin/vendor/datatables/custom/custom-datatables.js')}}"></script>
		<script src="{{asset('public/admin/vendor/datatables/custom/fixedHeader.js')}}"></script>

		<!-- Common JS -->
		<script src="{{asset('public/admin/js/common.js')}}"></script>