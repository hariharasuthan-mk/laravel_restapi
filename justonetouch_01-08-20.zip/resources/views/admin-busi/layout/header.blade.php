<header class="page-header">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="page-title">
					<h3>{{$title}}</h3>
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
				<div class="right-stats">
					<a href="javascript:void(0)" class="btn btn-danger"><span>895</span>Sales</a>
					<a href="javascript:void(0)" class="btn btn-success"><span>125</span>Leads</a>
				</div>
			</div>
		</div>
	</div>
</header>
