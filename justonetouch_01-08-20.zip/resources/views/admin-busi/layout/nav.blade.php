<?php $uri = Request::path();?>
<?php $suburi = Request::segment(2);?>
<?php $secsuburi = Request::segment(3);?>

<?php $userRole=Request::user()->user_group_id?>

<nav class="navbar navbar-expand-lg custom-navbar">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#retailAdminNavbar"
            aria-controls="retailAdminNavbar" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon">
							<i></i>
							<i></i>
							<i></i>
						</span>
    </button>
    <div class="collapse navbar-collapse" id="retailAdminNavbar">
        <ul class="navbar-nav">
            @if($userRole==1)
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($uri == 'admin/dashboard') {
                        echo 'active-page';
                    } else {
                        echo '';
                    }?> " href="{{url('admin/dashboard')}}">
                        <i class="nav-icon icon-home"></i>
                        Dashboards
                    </a>

                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($suburi == 'usermanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="{{url('admin/usermanagement/userlist')}}">
                        <i class="nav-icon icon-users"></i>
                        <span class="nav-item">Users</span>
                    </a>

                </li>
                <li class="nav-item dropdown ">
                    <a class="nav-link dropdown-toggle <?php if ($suburi == 'assemblymanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <i class="nav-icon icon-users"></i>
                        <span class="nav-item">Assembly</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
                        <li>
                            <a class="dropdown-item" href="{{url('admin/assemblymanagement/assemblylist')}}">Assembly List</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="{{url('admin/assemblymanagement/assemblydetails')}}">Assembly Details</a>
                        </li>
                    </ul>
                </li>
            @elseif($userRole==2)
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($uri == 'admin/mp/dashboard') {
                        echo 'active-page';
                    } else {
                        echo '';
                    }?> " href="{{url('admin/mp/dashboard')}}">
                        <i class="nav-icon icon-home"></i>
                        Dashboards
                    </a>

                </li>


                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($secsuburi == 'usermanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="{{url('admin/mp/usermanagement/userlist')}}">
                        <i class="nav-icon icon-users"></i>
                        <span class="nav-item">Users</span>
                    </a>

                </li>

            @elseif($userRole==3)

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($uri == 'admin/mla/dashboard') {
                        echo 'active-page';
                    } else {
                        echo '';
                    }?> " href="{{url('admin/mla/dashboard')}}">
                        <i class="nav-icon icon-home"></i>
                        Dashboards
                    </a>

                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($secsuburi == 'usermanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="{{url('admin/mla/usermanagement/userlist')}}">
                        <i class="nav-icon icon-users"></i>
                        <span class="nav-item">Users</span>
                    </a>

                </li>
                <li class="nav-item ">
                    <a class="nav-link dropdown-toggle <?php if ($suburi == 'assemblymanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="{{url('admin/assemblymanagement/assemblylist')}}" id="pagesDropdown" role="button"
                    >
                        <i class="nav-icon icon-business_center"></i>
                        <span class="nav-item">Assembly</span>
                    </a>

                </li>

                @elseif($userRole==4)
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?php if ($uri == 'admin/booth/dashboard') {
                        echo 'active-page';
                    } else {
                        echo '';
                    }?> " href="{{url('admin/booth/dashboard')}}">
                        <i class="nav-icon icon-home"></i>
                        Dashboards
                    </a>

                </li>

            @endif

            <li class="nav-item ">
                <a class="nav-link dropdown-toggle <?php if ($suburi == 'boothmanagement')  {
                    echo 'active-page';
                }

                else {
                    echo '';
                }?>" href="{{url('admin/boothmanagement/boothlist')}}" id="layoutsDropdown" role="button"
                  >
                    <i class="nav-icon icon-web"></i>
                    <span class="nav-item">Booths</span>
                </a>

            </li>



                <li class="nav-item dropdown ">
                    <a class="nav-link dropdown-toggle <?php if ($suburi == 'votermanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <i class="nav-icon icon-users"></i>
                        <span class="nav-item">Voter Management</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
                        <li>
                            <a class="dropdown-item" href="{{url('admin/votermanagement/downloaddata')}}">Download Data</a>
                        </li>
                           @if($userRole==1)
                        <li>
                            <a class="dropdown-item" href="{{url('admin/votermanagement/uploaddata')}}">Upload Data</a>
                        </li>
                        @endif
                        <li>
                            <a class="dropdown-item" href="{{url('admin/votermanagement/voterlist')}}">Voters List</a>
                        </li>

                    </ul>
                </li>

                <li class="nav-item dropdown ">
                    <a class="nav-link dropdown-toggle <?php if ($suburi == 'datamanagement')  {
                        echo 'active-page';
                    }

                    else {
                        echo '';
                    }?>" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
                       aria-haspopup="true" aria-expanded="false">
                        <i class="nav-icon icon-public"></i>
                        <span class="nav-item">Data Management</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
                           @if($userRole==1)
                        <li>
                            <a class="dropdown-item" href="{{url('admin/datamanagement/uploaddata')}}">Upload Data</a>
                        </li>
                        @endif
                        <li>
                            <a class="dropdown-item" href="{{url('admin/datamanagement/datalist')}}">Data List</a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="{{url('admin/datamanagement/downloaddata')}}">Download Data</a>
                        </li>

                    </ul>
                </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle <?php if ($suburi == 'socialmanagement')  {
                    echo 'active-page';
                }

                else {
                    echo '';
                }?>" href="{{url("admin/socialmanagement")}}" id="tablesDropdown" role="button" >
                    <i class="nav-icon icon-volume_up"></i>
                    <span class="nav-item">Social Medias</span>
                </a>
            </li>
@if($userRole==1)
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
       aria-haspopup="true" aria-expanded="false">
        <i class="nav-icon icon-monetization_on"></i>
        <span class="nav-item">Payments</span>
    </a>
    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
        <li>
            <a class="dropdown-item" href="{{url("admin/paymentlist")}}">Payment List</a>
        </li>

    </ul>
</li>
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
       aria-haspopup="true" aria-expanded="false">
        <i class="nav-icon icon-notifications"></i>
        <span class="nav-item">Subscriptions</span>
    </a>
    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
        <li>
            <a class="dropdown-item" href="{{url("admin/paymentlist")}}">Subscriptions List</a>
        </li>

    </ul>
</li>
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="tablesDropdown" role="button" data-toggle="dropdown"
       aria-haspopup="true" aria-expanded="false">
        <i class="nav-icon icon-chart-line"></i>
        <span class="nav-item">Election Results</span>
    </a>
    <ul class="dropdown-menu" aria-labelledby="tablesDropdown">
        <li>
            <a class="dropdown-item" target="_blank" href="{{url("admin/graph")}}">Graph</a>
        </li>

    </ul>
</li>
                @endif
@if($userRole!=1 && $userRole!=4)
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="loginDropdown" role="button" data-toggle="dropdown"
   aria-haspopup="true" aria-expanded="false">
    <i class="nav-icon icon-lock-open"></i>
    <span class="nav-item">Mobile App</span>
</a>
<ul class="dropdown-menu" aria-labelledby="loginDropdown">
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/slidemenuphotos')}}">Slide Menu Photos</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/katchilist')}}">Katchi</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url("admin/mobileapp/gallarylist")}}">Gallary</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/newslist')}}">News</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/eventlist')}}">Event</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/historylist')}}">History</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/policylist')}}">Policy</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/socialservicelist')}}">Social Service</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/achievelist')}}">Achivement</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/videolist')}}">Video</a>
    </li>
    <li>
        <a class="dropdown-item" href="{{url('admin/mobileapp/radiolist')}}">Radio</a>
    </li>
</ul>
</li>
    @endif
</ul>
</div>
</nav>


