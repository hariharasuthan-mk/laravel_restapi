<header class="app-header">
				<div class="container-fluid">

					<!-- Row start -->
					<div class="row gutters">
						<div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4">
							
							<!-- BEGIN .logo -->
							
							
							
							<div style="">
								<a href="{{url('admin/dashboard')}}" class="logo">
									<img src="{{asset('public/admin/img/logos.png')}}" alt="Election Admin Dashboard" />
								</a>
							</div>
							<!-- END .logo -->
<h4 style="color:white;padding: 10px 0px 10px 5px;padding-top: 20px;padding-right: 0px;padding-bottom: 10px;padding-left: 5px;float: left;min-width: 50px;"> IEMS </h4>
						</div>
						
						<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8">

							<!-- Header actions start -->
							<ul class="header-actions">
							
							
								<li class="dropdown">
									<a href="#" id="userSettings" class="user-settings clearfix" data-toggle="dropdown" aria-haspopup="true">
										<span class="avatar">
											<i class="icon-account_circle"></i>
										</span>
										<span class="user-name">{{Request::user()['first_name'] }} <i class="icon-chevron-small-down downarrow"></i></span>
									</a>
									<div class="dropdown-menu md dropdown-menu-right" aria-labelledby="userSettings">
										<div class="admin-settings">
											<ul class="admin-settings-list">
												<!--<li>
													<a href="profile.html">
														<span class="icon icon-face"></span>
														<span class="text-name">My Profile</span>
														<span class="badge badge-success">75% Complete</span>
													</a>
												</li>-->
											
											
											</ul>
											<div class="actions">
												<a href="{{url('admin/logout')}}" class="btn btn-primary">Logout</a>
											</div>
										</div>
									</div>
								</li>
							</ul>
							<!-- Header actions end -->

							<!-- Custom Search start -->
							<div class="custom-search">
								<input type="text" class="search-query" placeholder="Search here ...">
								<i class="icon-search"></i>
							</div>
							<!-- Custom Search end -->

						</div>
					</div>
					<!-- Row start -->

				</div>
			</header>
