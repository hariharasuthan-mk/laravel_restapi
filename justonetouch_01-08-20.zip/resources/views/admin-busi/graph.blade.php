<!doctype html>
<html lang="en">
	
<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="Bluemoon Admin Panel" />
		<meta name="keywords" content="Admin, Dashboard, Bootstrap 4 Admin Dashboard, Bootstrap 4 Admin Template, Bootstrap 4 Admin Template, Sales, Admin Dashboard, Traffic, Tasks, Revenue, Orders, Invoices, Projects, Invoices, Dashboard, Bootstrap4, Sass, CSS3, HTML5, Responsive Dashboard, Responsive Admin Template, Admin Template, Best Admin Template, Bootstrap Template, Themeforest" />
		<meta name="author" content="Bootstrap Gallery" />
		<link rel="shortcut icon" href="{{asset('public/admin/img/favicon.ico')}}" />
		<link rel="manifest" href="app.webmanifest" crossorigin="use-credentials">
		<title>ELECTION Admin Dashboard</title>
		
		
	<link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/bootstrap.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/basic.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/feature.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="http://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css">
  <link rel="stylesheet" type="text/css" media="screen" href="http://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css">
  <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/custom-styles.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/jquery-ui.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/graph/css/multiple-select.css')}}">
  <link rel="stylesheet" type="text/css" media="screen" href="//cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css">
  <link rel="shortcut icon" href="{{asset('public/graph/images/logo.png')}}">
  <script type="text/javascript" src="{{asset('public/graph/js/jquery.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/js/d3.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/js/sankey.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/javascripts/google-analyitcs.js')}}" crossorigin="anonymous"></script>
  <script type="text/javascript" src="{{asset('public/graph/javascripts/angular.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/js/bootstrap.min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/js/underscore-min.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/javascripts/jquery.multiple.select.js')}}"></script>
  <script type="text/javascript" src="{{asset('public/graph/js/jquery-ui-1.10.3.min.js')}}"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
  
  <style>
  .parent {
  position: relative;
}
.right {
    position: absolute;
    right: 0;
}
.example2 a:link { text-decoration: none }
  </style>
	</head>
	<body>
	
		<div class="se-pre-con"></div>
  
    
    <div id="overall_view">
    <div class="container-fluid">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="parent col-md-12 panel-heading1">
       <h2>Assembly Election Results <i class="year_tag"></i>Party Standings</h2>
	  <a href="http://commonman.ind.in/admin/dashboard" title="Election Dashboard" style="float:right"><i style="margin-right: 0.5em; color: #0044cc;" class="icon-home icon-4x"></i></a>
   </div>

           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">

       <div class="dropdown header_year">
           <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Year</button>
  <ul class="dropdown-menu" role="menu">
          
      <li data-year="2016" id="2016_flow"><a href="?year=2016#overall_view">2016 results</a></li>
      <li data-year="2011" id="2011_flow"><a href="?year=2011#overall_view">2011 results</a></li>
      <li data-year="2006" id="2006_flow"><a href="?year=2006#overall_view">2006 results</a></li>
      <li data-year="2001" id="2001_flow"><a href="?year=2001#overall_view">2001 results</a></li>
      <li data-year="1996" id="1996_flow"><a href="?year=1996#overall_view">1996 results</a></li>
      <li data-year="1991" id="1991_flow"><a href="?year=1991#overall_view">1991 results</a></li>
      <li data-year="1989" id="1989_flow"><a href="?year=1989#overall_view">1989 results</a></li>
      <li data-year="1984" id="1984_flow"><a href="?year=1984#overall_view">1984 results</a></li>
      <li data-year="1980" id="1980_flow"><a href="?year=1980#overall_view">1980 results</a></li>
      <li data-year="1977" id="1977_flow"><a href="?year=1977#overall_view">1977 results</a></li>
      <li data-year="1971" id="1971_flow"><a href="?year=1971#overall_view">1971 results</a></li>
      <li data-year="1967" id="1967_flow"><a href="?year=1967#overall_view">1967 results</a></li>
      
  </ul>
         </div>
		 
		 
		 <br/><br/>
       <div class="row">
          <svg data-height="0.54" viewBox="0 0 1200 30" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
<g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
    </g>
  </svg>
       <div class="col-md-2"></div>
       <div class="col-md-8">
        <div class="overall_view_report">
        </div>
       </div>
       <div class="col-md-2"></div>
       </div>


   </div>
            </div>
            </div>
            </div>
    </div>
    </div>
    </div>
        
    <div id="individual_hold" class="map_hider">
    <div class="container-fluid">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Assembly Elections View By Individual Elections <i class="extra_year_tag"></i></h2>
   </div>
           </div>
           
           <div class="row">
   <div class=" col-md-12 panel-body">
            
       <div class="dropdown header_year">
           <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Year</button>
  <ul class="dropdown-menu" role="menu">
      <li data-year="2016" id="extra_2016"><a href="?extra_year=2016#individual_hold">2016 results</a></li>
      <li data-year="2011" id="extra_2011"><a href="?extra_year=2011#individual_hold">2011 results</a></li>
  </ul>
       </div>
         
       <p class="form-inline header_form" >
           <label align="left" >Search:</label>
           <input type="text" class="geo_search" placeholder="eg: chennai">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           <label value="year">based on 2011 : </label>
           <select multiple id="year_2011" class="select_year"></select>&nbsp;&nbsp;
           <label value="year">based on 2016 : </label>
           <select multiple id="year_2016" class="select_year"></select>
            <input type="button" value="submit" class="party_filter"></input>
       </p>
           
          
        <div class="chart">
         
           <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
    
           </svg>
           
           <div class="geo_map">
           <svg data-height="0.54" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"  viewBox="0 0 1750 1000" style="width: 100%;">
           <g class="geomaps" transform="translate(500,0)">
           
  <text class="chennai" x="135" y="80" dy=".35em" font-size="30px" sub_title=".chennai" style="text-anchor: middle; fill: rgb(99, 99, 99);">Chennai</text>
           
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=1><polygon id="Gummidipoondi" points="658,76,657,87,662,87,663,91,664,93,667,93,667,90,675,93,677,89,683,92,685,87,692,89,692,82,696,82,699,82,696,88,702,88,706,90,710,88,714,85,714,82,712,78,710,76,709,76,704,74,706,67,717,73,720,73,718,69,717,65,717,62,726,62,725,54,720,53,722,48,722,45,717,45,717,42,710,42,710,45,705,46,705,39,706,36,706,34,701,36,697,36,695,34,689,35,692,38,696,38,696,40,700,40,700,42,692,44,687,48,687,56,681,56,683,61,685,61,684,64,682,65,680,69,678,67,675,71,671,72,671,73,666,74,659,74,658,78,658,78" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=2><polygon id="Ponneri" points="726,87,724,85,723,83,718,85,714,85,714,82,710,76,709,76,704,73,706,67,717,73,720,73,717,67,716,65,717,62,726,62,725,54,720,53,720,51,722,48,722,45,730,45,733,48,735,39,738,32,742,42,747,53,750,69,751,80,751,84,748,90,745,92,742,96,731,95,731,90,728,90,727,88" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=3><polygon id="Tiruttani" points="574,115,578,117,585,115,589,115,591,111,588,111,591,107,591,103,596,107,597,113,598,113,603,105,616,105,618,109,622,108,622,104,628,104,628,100,633,93,629,91,626,90,626,88,629,85,632,88,632,85,637,87,635,83,639,83,638,80,635,76,635,81,630,78,629,82,624,78,621,81,621,84,617,82,612,82,613,74,613,69,607,69,605,71,605,68,602,70,597,69,594,67,593,71,589,71,586,74,586,75,586,76,593,76,596,75,593,79,589,82,592,85,596,87,598,87,597,90,596,91,593,96,583,96,584,99,581,99,581,106,579,107,579,104,574,108,572,111,571,107,568,106,569,113" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=4><polygon id="Thiruvallur" points="646,100,646,108,641,112,645,113,645,120,649,121,653,119,655,123,654,125,659,128,660,137,667,138,672,140,676,136,672,132,675,130,679,132,680,129,674,127,674,122,676,122,677,125,684,124,687,122,691,120,689,114,687,113,684,115,681,114,680,110,676,104,672,100,672,98,683,97,684,92,677,89,675,93,667,90,667,93,664,93,662,90,662,87,657,87,658,78,654,76,651,73,650,79,645,79,651,84,655,85,655,91,649,93,646,88,643,91,639,90,642,88,641,85,639,88,637,87,632,85,633,88,629,85,626,88,626,91,629,91,634,93,635,95,635,98,638,96,641,96,638,102,641,100" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=5><polygon id="Poonamallee" points="698,124,692,123,689,123,688,125,685,122,687,122,689,120,691,120,689,114,687,113,684,115,681,114,680,111,680,109,674,102,672,100,672,98,683,97,684,92,683,92,685,87,692,89,692,82,699,82,696,88,702,88,706,90,710,88,710,88,710,92,710,94,705,93,701,94,699,95,696,97,698,106,696,108,692,108,692,111,696,110,697,113,700,111,705,111,708,113,709,115,708,117,710,119,712,117,713,122,713,125,710,127,708,124,706,122,705,125,704,123,701,125,698,125" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=6><polygon id="Avadi" points="704,100,697,107,696,108,692,108,692,111,696,110,697,113,700,111,705,111,709,114,709,116,708,117,710,119,713,116,712,112,714,112,717,106,713,104,706,102" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=7><polygon id="Maduravoyal" points="717,116,722,117,725,117,728,121,729,124,733,128,731,133,726,134,725,128,723,125,722,123,717,125,713,122,712,117,713,115,712,113,713,112,716,112" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=8><polygon id="Ambattur" points="724,108,717,106,714,112,716,113,717,115,717,116,723,117,724,117,726,116,728,113,726,110" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=9><polygon id="Madavaram" points="734,103,731,109,725,109,722,107,716,106,713,104,708,103,704,100,697,107,696,97,703,93,709,94,710,92,710,88,716,85,717,85,723,83,728,90,731,90,731,95,742,96,742,99,738,99,735,97,734,97" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=10><polygon id="Thiruvottiyur" points="737,106,742,105,746,98,748,91,748,90,745,92,742,96,742,99,738,99,735,97,734,97,734,104,735,104" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=11><polygon id="Dr. Radhakrishnan Nagar" points="154,112,146,116,143,120,141,129,143,133,141,145,144,144,146,141,148,141,150,140,153,138,155,137,156,134,159,133,165,138,166,135,170,134,172,133,173,128,176,127,176,125,173,124,172,121,168,120,170,115,172,113,165,110,158,110,158,109" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=12><polygon id="Perambur" points="136,113,138,108,140,106,139,105,132,105,122,105,122,109,114,112,114,127,117,129,119,131,117,136,116,141,122,141,122,144,125,145,127,147,135,145,141,145,143,133,141,128,143,120,145,116,143,116,139,114" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=13><polygon id="Kolathur" points="74,135,79,134,79,138,77,140,78,143,85,143,87,140,94,142,103,146,109,146,110,157,114,157,115,151,114,148,116,141,117,135,119,131,114,127,113,125,102,125,98,125,98,123,86,123,78,125,75,127" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=14><polygon id="Villivakkam" points="67,155,67,165,64,171,72,175,77,169,81,168,82,159,82,152,91,158,105,167,111,169,115,170,117,168,113,167,113,158,110,157,109,146,102,146,88,140,87,140,85,143,78,143,77,140,79,138,79,134,75,135,71,141,66,147,69,152" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=15><polygon id="Thiru-Vi-Ka-Nagar" points="130,156,134,160,133,162,127,162,123,164,120,165,117,168,113,167,113,157,114,156,115,151,114,147,116,141,121,141,122,141,122,144,127,147,135,145,141,144,143,150,144,155,144,158,135,157" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=16><polygon id="Egmore" points="125,168,118,169,118,167,121,165,123,164,127,162,133,162,134,160,130,156,144,158,144,161,144,170,146,171,146,175,140,174,136,174,136,179,138,182,135,188,133,186,130,193,128,192,125,186,121,184,117,184,107,185,103,188,101,188,102,181,110,178,118,178,125,177,125,174,125,169" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=17><polygon id="Royapuram" points="165,155,154,152,150,149,148,151,147,155,144,155,143,149,142,145,144,144,145,141,149,141,153,138,155,137,156,134,159,133,165,138,166,135,170,134,173,135,173,138,174,143,176,145,176,149,173,149,173,144,171,144,168,150,168,153,166,155" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=18><polygon id="Harbour" points="146,189,142,186,145,182,143,177,139,173,139,174,146,175,146,171,144,170,144,155,147,155,148,151,150,149,154,152,166,155,166,162,172,164,168,171,163,177,158,189,156,193,149,191" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=19><polygon id="Chepauk" points="132,205,135,201,134,200,128,199,128,197,135,196,135,192,135,191,132,189,133,186,135,188,138,183,136,179,136,175,138,174,140,174,144,178,145,182,142,186,147,190,156,193,156,196,155,201,154,203,153,208,143,207,135,206,138,211,138,214,132,214,126,215,130,209" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=20><polygon id="Thousand Lights" points="110,206,116,209,116,212,111,213,111,217,108,219,104,217,103,220,102,226,107,225,111,221,115,220,117,217,121,214,125,216,126,215,130,208,132,205,135,201,134,200,128,199,128,197,135,196,135,191,132,189,130,193,128,192,122,185,121,184,107,185,103,188,101,188,99,186,94,186,94,191,91,195,89,199,90,201,97,199,103,199,103,205,109,207" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=21><polygon id="Anna Nagar" points="79,180,74,180,73,174,77,169,81,168,82,152,91,158,105,167,115,170,118,168,118,168,125,168,125,177,111,178,110,178,102,181,101,186,97,186,94,186,94,191,91,195,79,194,79,189,81,182,79,181" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=22><polygon id="Virugampakkam" points="58,214,55,203,59,192,59,188,61,182,59,177,64,171,73,175,74,180,79,180,82,182,81,183,79,195,78,201,79,208,83,215,81,224,79,223,71,223,61,226,59,222,58,218" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=23><polygon id="T-Nagar" points="98,217,83,217,83,214,79,208,78,200,79,194,91,195,89,199,90,201,98,199,103,199,103,205,110,207,110,206,116,209,116,212,111,213,111,217,108,219,104,217,102,221,98,221,98,218" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=24><polygon id="Saidapet" points="72,235,74,228,82,225,81,224,83,217,98,217,98,218,98,221,103,221,102,226,106,226,111,221,113,221,111,225,115,226,117,227,121,234,119,240,118,248,121,256,121,259,113,256,110,260,108,260,106,266,101,265,90,263,88,262,87,257,83,257,79,254,81,250,85,246,79,241,73,235" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=25><polygon id="Mylapore" points="147,239,125,238,120,233,117,226,111,225,111,221,115,220,118,216,121,214,125,216,128,215,138,214,138,211,135,206,147,207,152,208,153,208,151,221,149,228,149,235,148,239" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=26><polygon id="Velachery" points="93,285,104,275,114,274,115,269,123,271,122,275,136,276,140,264,142,251,146,248,148,239,128,238,125,238,121,234,119,239,118,248,121,257,121,259,111,256,113,257,110,260,108,260,106,266,88,262,87,257,82,257,79,254,76,263,77,268,82,273,82,276,85,277,88,284,91,285,91,285,91,285,91,285,91,285,91,284,91,285" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=27><polygon id="Shozhinganallur" points="724,137,723,138,718,142,718,146,721,152,720,153,724,157,726,152,728,157,733,156,735,140,735,135,733,134,731,133,726,135,724,136" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=28><polygon id="Alandur" points="717,135,723,137,728,134,726,134,725,128,722,123,717,125,713,122,713,125,710,127,710,132,714,133,717,132" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=30><polygon id="Pallavaram" points="714,142,718,141,721,140,724,138,724,136,721,137,717,135,717,132,714,133,710,132,709,135,708,135,706,140,706,141,712,140,716,142" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=31><polygon id="Tambaram" points="701,148,709,149,713,152,713,155,717,152,720,153,721,151,718,145,721,140,716,142,712,140,706,141,704,145" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=29><polygon id="Sriperumbudur" points="674,153,664,151,663,149,658,147,657,144,653,144,654,138,650,138,650,134,651,132,647,130,654,125,659,128,660,137,672,140,676,136,672,132,675,130,679,132,680,129,674,127,674,122,676,122,677,125,684,124,687,122,688,124,688,125,689,123,698,125,701,125,704,123,705,125,706,122,710,127,710,132,710,132,708,136,706,141,704,145,701,148,700,155,698,160,692,163,684,162,684,166,678,166,674,165,673,162,675,157,674,153" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=32><polygon id="Chengalpattu" points="682,182,680,178,678,174,673,173,667,169,673,169,674,165,683,167,684,166,684,162,692,163,698,160,700,155,701,148,709,149,713,152,713,156,717,152,720,155,717,157,713,157,714,160,714,164,713,169,708,167,701,174,696,177,698,183,697,189,691,188,684,192,681,194,682,189,683,184" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=33><polygon id="Thiruporur" points="697,208,699,210,701,206,706,210,714,210,717,212,718,212,734,168,731,163,733,155,728,157,726,152,724,157,720,153,717,157,713,157,714,163,713,169,709,167,708,167,700,175,696,177,698,183,697,189,691,188,681,194,682,201,684,205,689,205,691,209,695,208" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=34><polygon id="Cheyyur" points="667,263,658,250,654,246,655,242,652,235,659,237,662,233,658,230,658,227,664,226,671,230,673,242,685,246,689,235,688,230,683,227,688,214,691,211,683,208,685,205,688,205,691,209,698,208,699,211,701,206,706,210,716,210,717,212,716,229,710,237,696,251,689,262,682,264,676,264,670,265" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=35><polygon id="Maduranthakam" points="645,211,648,207,651,208,660,205,657,201,657,197,672,196,676,193,677,192,676,184,682,182,683,185,681,195,684,205,684,208,689,211,688,215,683,227,687,230,689,237,685,246,673,242,672,230,664,226,659,227,658,228,658,230,662,233,659,235,658,237,652,235,655,241,654,246,646,248,638,246,634,250,628,245,628,243,631,241,631,237,635,235,635,233,639,232,639,230,646,229,643,226,646,225,645,219,643,218,647,216,646,212" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=36><polygon id="Uthiramerur" points="645,183,635,188,629,186,626,194,629,195,629,199,633,201,637,200,643,201,642,203,639,204,642,207,643,210,645,211,648,207,651,208,660,205,657,201,657,197,673,196,677,192,676,184,682,182,677,174,673,173,667,169,672,169,674,165,673,161,675,157,670,157,664,158,662,157,660,159,653,159,643,163,639,161,635,165,634,167,634,164,628,164,629,170,631,170,635,168,635,167,639,169,639,171,647,174,643,176,641,177,645,180" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=37><polygon id="Kancheepuram" points="626,144,629,142,631,142,633,138,639,134,645,132,647,130,651,132,650,134,650,137,650,138,654,138,653,143,653,144,657,144,659,148,663,149,666,152,674,153,675,157,670,157,666,158,662,157,660,159,652,159,643,163,639,161,634,167,634,164,628,164,628,162,620,159,614,156,614,150,617,147,622,146" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=38><polygon id="Arakkonam" points="613,122,614,119,618,121,618,116,618,113,617,112,614,111,614,105,614,105,616,105,618,109,622,108,622,104,627,104,628,104,628,100,633,93,634,93,635,96,635,98,638,96,641,96,638,102,641,100,646,100,646,108,641,112,645,113,645,120,649,121,653,119,655,123,654,125,647,130,645,132,633,138,631,138,626,134,623,131,622,135,618,132,623,128,621,124,618,125,614,124" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=39><polygon id="Sholingur" points="586,129,586,134,584,135,582,131,580,133,578,129,575,125,575,122,572,122,572,117,574,115,578,117,585,115,589,115,591,111,588,111,591,107,591,103,596,107,597,113,598,113,603,105,614,105,614,111,616,111,618,113,618,121,614,119,613,122,614,125,618,125,621,124,623,128,618,132,622,135,623,131,627,135,631,138,632,138,633,138,631,142,628,142,626,144,621,146,617,147,614,151,614,155,610,153,606,153,604,151,600,151,598,150,596,146,594,141,594,136,591,134,591,131,588,128" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=40><polygon id="Katpadi" points="534,132,534,128,531,125,533,123,539,121,543,122,547,125,551,121,551,114,558,111,559,107,556,100,560,98,561,103,563,102,563,99,565,102,568,100,568,107,569,112,574,115,572,117,572,122,569,125,569,127,568,134,565,136,565,138,558,136,552,137,546,137,540,138,535,140,533,138,530,138,530,135,534,133" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=41><polygon id="Ranipet" points="565,143,555,143,551,144,552,140,554,138,556,137,558,136,565,138,565,135,568,134,569,127,571,124,572,122,575,122,575,125,579,130,580,133,582,131,584,134,586,134,586,129,588,128,591,131,591,134,596,137,594,141,596,146,598,151,589,151,585,152,579,146,574,143,572,145,571,148,573,151,572,153,567,150,565,153,564,156,560,153,560,150,557,148,558,145,565,146" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=42><polygon id="Arcot" points="546,169,547,173,554,173,555,164,559,164,563,160,564,159,564,165,567,166,568,171,576,175,577,178,577,182,579,182,579,178,585,175,585,177,584,181,585,184,579,186,579,193,584,194,589,189,596,186,598,181,599,175,596,175,597,171,599,169,598,167,600,163,598,162,598,156,599,155,599,150,598,151,586,152,588,151,585,152,578,146,574,143,571,146,571,149,573,150,572,153,567,150,564,156,560,153,560,150,557,148,558,145,565,146,565,143,553,143,554,147,551,148,540,148,538,151,540,155,539,160,538,163,534,163,534,171,538,170,540,170,544,171" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=43><polygon id="Vellore" points="534,147,539,145,540,148,552,148,554,147,553,144,551,144,552,140,558,136,544,137,540,138,535,140,533,142,532,145,534,145" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=44><polygon id="Anaicut" points="501,158,500,162,503,164,502,166,495,166,491,170,491,174,497,174,495,178,493,183,495,184,500,181,501,183,514,186,517,179,521,181,521,185,526,177,528,177,529,171,534,171,534,163,538,163,540,155,538,150,540,148,539,145,534,147,534,145,531,145,532,145,534,140,534,138,530,138,526,141,518,140,513,140,503,143,503,148,502,152,497,152,497,153,501,155" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=45><polygon id="Kilvaithinankuppam" points="487,121,486,116,484,114,486,111,489,112,497,112,497,109,500,109,500,121,507,121,507,120,503,119,505,115,506,112,515,114,515,112,521,113,527,117,530,117,532,123,531,127,534,128,534,133,530,135,530,138,526,141,513,140,503,143,503,147,498,146,491,148,489,148,487,141,487,137,491,136,493,132,489,132,489,130,491,125,493,124,488,121" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=46><polygon id="Gudiyattam" points="459,153,458,159,454,159,451,155,451,152,454,141,457,138,460,138,457,132,455,127,460,121,468,124,468,115,472,115,477,117,484,115,484,115,486,116,487,120,491,123,493,124,489,130,489,132,493,132,491,136,487,137,487,143,489,148,489,150,477,156,468,163,465,167,465,162,462,161,463,158,461,153" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=47><polygon id="Vaniyambadi" points="437,194,443,188,445,185,451,185,454,192,458,194,462,192,465,197,465,206,461,206,458,205,456,206,452,207,455,212,460,215,459,222,462,222,465,218,470,218,472,214,476,214,478,209,485,208,488,194,489,190,483,189,477,182,472,183,470,185,464,183,462,182,461,179,459,178,459,180,455,180,455,174,449,178,447,176,443,171,441,171,440,180,437,179,437,175,431,168,430,171,433,176,432,183,426,182,427,186,431,190" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=48><polygon id="Ambur" points="449,164,443,166,441,170,441,171,443,171,447,177,449,178,455,174,455,180,459,180,459,177,462,181,462,182,470,185,473,183,477,182,483,189,489,190,493,183,495,177,497,174,491,174,491,170,495,166,502,166,503,164,501,162,501,157,501,155,497,153,497,152,502,152,503,147,498,146,493,148,489,148,489,150,478,155,472,161,465,167,465,162,462,161,463,158,461,153,459,153,458,159,454,159,451,155,451,155,449,161" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=49><polygon id="Jolarpet" points="417,199,417,217,420,215,424,219,426,214,436,213,441,218,457,213,453,209,452,207,459,205,461,206,465,206,465,197,462,192,458,194,454,192,451,185,445,185,437,194,427,186,426,190,424,190,418,188,416,190,416,193,416,197" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=50><polygon id="Tiruppattur" points="441,233,429,229,428,234,418,233,422,226,420,222,417,217,420,215,424,219,426,214,436,213,441,218,457,213,460,215,459,222,462,222,465,218,470,218,472,214,476,214,478,209,485,208,486,207,481,216,479,216,478,222,476,222,477,228,472,235,470,235,466,248,458,255,456,256,454,253,447,256,449,248,447,247,445,246,449,242,447,239,443,235" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=51><polygon id="Uthangarai" points="408,244,410,243,411,235,413,232,407,228,411,221,414,222,416,225,417,222,420,222,422,226,418,233,429,234,429,229,441,233,443,237,447,239,449,242,445,246,449,248,447,255,454,253,456,257,459,264,457,267,455,266,453,269,449,269,443,272,443,267,437,270,433,270,428,276,424,274,424,269,414,267,408,266,409,264,413,262,410,261,406,261,404,258,404,255,403,251,401,249,401,246,404,244,407,244" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=52><polygon id="Bargur" points="385,244,386,247,389,248,389,254,395,253,401,255,404,256,403,251,401,249,401,245,404,244,408,244,410,243,411,235,413,232,407,228,407,226,408,226,411,221,414,222,416,225,417,222,420,222,417,217,417,199,416,197,416,190,409,191,404,186,399,182,397,183,394,189,394,197,390,205,388,212,390,218,387,219,390,227,385,227,384,231,387,237,388,241,388,244" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=53><polygon id="Krishnagiri" points="352,214,360,200,363,198,363,194,365,188,369,188,369,194,367,198,375,197,376,201,379,200,379,195,379,191,383,193,385,195,390,195,392,191,394,191,394,198,388,212,390,218,387,219,390,227,385,227,384,231,387,238,388,241,388,244,385,244,384,244,385,239,381,241,375,241,372,235,365,232,365,223,360,220,354,216,352,216" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=54><polygon id="Veppanahalli" points="342,165,344,163,346,157,349,152,351,148,356,149,371,162,379,163,386,166,386,171,379,177,381,179,386,179,388,176,394,177,397,183,394,191,392,191,390,195,385,195,379,191,379,200,376,201,375,197,367,198,369,194,369,188,365,188,363,194,363,198,360,200,352,214,352,217,351,220,349,220,346,210,342,209,337,214,333,208,330,208,329,208,327,199,331,196,328,191,329,188,321,186,324,181,330,180,330,176,327,175,331,173,333,164,337,165,340,166" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=55><polygon id="Hosur" points="306,183,307,180,305,176,305,173,306,171,305,168,309,167,310,164,308,161,314,155,313,152,310,150,311,148,314,148,317,145,328,145,331,142,335,142,335,146,332,152,335,153,336,153,337,147,342,152,344,156,346,156,344,163,340,166,333,164,331,174,327,175,330,176,330,180,323,182,319,180,317,180,314,185,309,193,303,196,306,191,304,186,303,185" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=56><polygon id="Thalli" points="314,254,311,259,310,266,308,271,303,267,299,269,296,265,289,264,282,261,271,261,261,260,253,260,251,259,253,255,251,251,253,247,261,247,264,244,266,244,270,242,271,237,279,232,282,213,282,210,276,213,273,212,279,208,278,206,273,206,273,201,271,196,273,192,275,188,278,186,277,184,276,181,278,178,284,177,289,176,291,181,294,181,296,177,301,178,300,175,305,174,305,175,307,180,306,183,303,185,306,191,303,196,309,193,317,180,319,180,323,182,321,186,329,188,328,191,331,196,327,199,328,208,329,208,326,210,326,211,331,212,332,219,337,221,339,228,336,234,335,240,331,241,321,239,321,242,321,250,317,251" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=57><polygon id="Palacodu" points="378,263,387,259,390,254,389,254,389,248,386,247,385,244,384,244,385,239,381,241,375,241,372,235,365,232,365,223,358,219,354,216,352,216,351,220,349,220,346,210,342,209,337,214,333,208,328,208,326,210,327,211,331,212,332,219,337,221,339,228,336,234,335,240,331,241,333,248,341,253,350,250,356,250,356,256,360,255,362,257,365,257,367,260,367,264,361,272,364,277,365,277,367,275,373,273,375,273,375,268,371,266,373,263" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=58><polygon id="Pennagaram" points="301,312,316,316,319,312,329,316,330,314,332,306,336,302,337,297,341,294,344,296,349,289,344,286,338,288,333,283,335,281,335,277,333,277,335,275,344,274,349,269,355,266,361,271,362,271,367,264,367,258,365,257,362,257,358,255,356,256,356,250,349,250,341,253,333,248,331,241,321,239,321,250,316,251,313,255,311,260,310,265,308,272,303,267,299,269,299,273,305,277,300,283,293,289,288,299,286,305,286,307,294,307,296,307" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=59><polygon id="Dharmapuri" points="358,307,351,311,349,310,342,314,336,317,329,316,332,306,336,301,337,297,341,294,344,296,349,289,344,286,337,288,333,283,335,281,335,277,333,276,336,275,344,274,349,269,355,266,361,271,364,276,365,277,367,274,374,273,379,275,377,277,372,277,367,282,372,289,374,289,374,293,369,294,365,297,367,300,363,302,363,306" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=60><polygon id="Pappireddippatti" points="383,304,363,306,363,302,367,300,365,297,369,294,374,293,374,289,372,289,367,282,372,277,378,277,379,275,375,274,375,268,371,266,373,263,378,263,387,259,390,261,390,264,390,268,393,274,394,275,397,275,398,281,406,277,405,285,409,285,410,291,416,288,420,289,417,293,418,296,420,296,418,298,415,300,416,304,420,303,422,306,424,307,422,311,420,311,415,316,413,319,405,320,404,316,397,318,398,313,392,315,392,318,388,317,392,313,388,313,386,315,389,311,385,312,385,309,384,306" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=61><polygon id="Harur" points="418,328,417,322,412,322,401,337,397,339,395,338,401,332,405,320,413,319,420,311,422,311,424,307,422,305,418,303,415,303,415,300,418,298,420,296,417,296,417,293,420,288,415,288,410,291,409,285,405,285,406,277,398,281,397,275,394,275,393,274,390,267,390,261,388,259,387,258,390,254,395,253,404,256,404,258,406,261,413,262,408,264,408,266,424,269,424,274,428,276,433,270,437,270,443,267,443,272,449,269,453,269,455,272,452,277,458,280,457,283,470,277,470,280,464,302,465,306,465,312,466,316,464,320,460,319,451,323,449,325,443,332,437,335,428,333,420,332" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=62><polygon id="Chengam" points="493,297,489,301,480,299,477,301,472,301,468,304,465,304,464,302,470,279,470,277,457,283,458,280,452,277,455,272,453,269,455,266,458,267,459,263,455,255,456,255,457,256,464,249,466,248,470,235,472,235,477,227,476,222,478,222,479,216,482,215,486,207,489,189,493,183,495,183,500,182,495,192,489,200,495,200,498,206,497,213,495,219,498,224,495,228,498,235,491,240,487,247,491,254,495,254,503,254,506,253,510,255,518,253,519,257,515,259,518,267,513,266,513,258,509,260,507,268,511,270,507,273,509,281,513,276,513,285,515,288,515,291,507,291,500,299" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=63><polygon id="Tiruvannamalai" points="538,273,540,275,538,279,535,280,534,283,532,281,532,288,527,292,523,296,519,294,519,292,515,291,515,288,513,284,513,276,509,281,509,273,511,270,507,268,509,260,513,258,513,267,518,267,515,259,519,257,519,251,523,250,525,253,534,251,538,259,539,263,539,268,536,269" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=64><polygon id="Kilpennathur" points="563,282,561,290,557,290,556,293,550,291,549,294,543,298,540,295,539,299,534,300,531,298,529,297,532,293,532,290,532,288,532,281,534,283,535,280,538,279,540,275,536,272,536,268,538,268,539,268,538,261,538,259,534,251,526,253,522,250,522,245,518,235,518,230,522,229,522,233,525,231,529,229,533,232,536,232,539,232,538,226,542,229,542,232,547,232,547,237,553,234,557,233,560,235,555,240,553,243,558,248,565,248,561,254,558,257,557,264,555,266,557,271,553,270,553,274" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=65><polygon id="Kalasapakkam" points="525,208,531,206,534,206,535,200,531,197,543,193,546,193,544,190,540,192,540,186,543,185,540,182,543,179,540,176,538,173,536,171,535,170,529,171,528,177,526,178,526,177,521,185,521,181,517,178,517,179,514,186,500,183,500,182,493,194,489,200,495,200,498,206,497,213,495,219,498,224,495,229,498,235,491,240,487,246,491,254,503,254,506,253,511,255,519,251,523,250,522,245,518,235,518,230,521,229,522,229,522,233,526,230,529,229,533,232,539,232,538,226,542,229,542,232,547,232,549,232,551,230,550,227,546,228,543,225,539,219,535,223,531,219,525,219,528,214,527,210,525,209,523,208" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=66><polygon id="Polur" points="586,229,582,226,576,227,573,224,569,227,557,226,557,233,552,234,547,237,547,232,549,232,551,230,550,227,546,228,539,219,535,223,531,219,525,219,528,214,527,210,525,208,531,206,534,206,535,200,530,197,531,197,543,193,546,193,544,190,540,192,540,186,542,185,543,184,549,186,550,184,554,182,554,186,559,189,560,191,557,193,561,204,568,207,567,211,563,212,561,213,559,213,558,218,559,220,561,216,565,215,568,215,568,218,571,219,573,215,571,214,571,211,568,209,574,201,575,197,578,200,582,196,586,201,586,203,586,207,589,210,588,216,589,223,588,227" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=67><polygon id="Arani" points="596,201,593,201,589,201,589,199,586,201,582,196,578,200,575,198,574,201,568,208,568,209,571,211,571,214,573,215,571,219,568,218,568,215,561,216,559,220,558,218,559,213,561,213,564,212,568,211,568,207,561,204,557,193,560,191,560,191,559,189,558,189,553,186,554,182,550,184,549,186,543,184,543,185,540,182,543,179,539,173,536,171,536,170,540,170,544,171,546,169,547,173,554,173,555,164,559,164,564,158,564,165,567,166,568,171,576,175,577,182,579,182,579,178,585,175,585,177,584,181,585,184,579,186,579,193,584,194,589,189,592,189,594,198,597,200" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=68><polygon id="Cheyyar" points="616,206,607,205,602,201,600,210,597,200,593,197,592,189,589,189,596,186,598,180,599,175,596,175,599,169,598,167,600,163,598,162,598,156,599,155,599,151,604,151,606,153,610,153,614,155,614,156,628,162,629,170,631,170,635,168,635,167,639,169,639,171,647,174,641,177,645,180,645,183,635,188,629,186,626,194,628,195,629,195,628,199,633,201,637,200,642,201,638,204,635,207,631,210,626,206,622,206,617,210,616,208" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=69><polygon id="Vandavasi" points="608,239,603,245,600,243,601,237,598,240,594,239,592,234,589,233,588,232,586,229,588,226,589,222,588,215,589,210,586,207,586,200,589,199,589,201,593,201,597,200,600,210,602,201,605,204,606,204,616,206,617,210,622,206,627,206,631,210,638,204,639,204,643,209,645,211,647,215,643,218,645,219,646,225,643,226,646,229,639,230,639,232,635,233,635,235,631,237,631,242,626,244,624,244,623,239,621,239,620,244" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=70><polygon id="Gingee" points="586,283,573,288,567,289,565,291,561,290,563,282,553,274,553,270,557,271,555,266,557,264,558,256,565,248,558,248,553,243,560,234,557,233,557,226,569,227,573,224,576,227,582,226,586,230,588,232,586,240,588,238,588,242,584,249,591,257,591,261,586,266,591,277,591,281" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=71><polygon id="Mailam" points="607,282,604,279,599,280,598,277,589,281,591,277,586,265,591,261,591,257,584,249,589,241,588,238,586,240,588,232,592,234,593,239,598,240,601,237,600,242,603,245,608,239,620,244,621,239,623,239,625,244,628,243,628,245,635,250,637,251,633,259,626,257,623,266,621,269,622,277,624,279,626,277,631,277,633,275,635,279,631,285,628,285,625,294,618,295,616,295,614,292,612,290,606,289,604,284" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=72><polygon id="Tindivanam" points="664,277,664,284,662,286,662,296,667,299,667,296,689,263,681,264,674,264,670,265,658,250,653,246,646,248,638,246,634,250,637,251,633,259,627,257,626,257,623,266,621,269,622,277,624,279,628,277,630,277,633,275,635,280,639,274,648,273,653,276,658,276,664,276,664,277" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=73><polygon id="Vanur" points="618,300,622,303,624,299,627,300,627,305,625,305,628,314,629,310,632,310,634,313,637,311,639,307,637,307,629,306,630,303,633,300,635,299,638,299,637,304,641,306,645,302,648,305,646,307,642,310,645,314,645,318,646,319,650,312,653,313,655,309,660,313,663,306,663,304,660,302,662,296,662,286,664,284,664,276,653,276,648,273,647,273,639,274,635,280,635,279,631,285,628,285,625,294,616,295,616,298" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=74><polygon id="Villupuram" points="581,319,584,314,589,313,593,312,598,315,600,307,605,310,612,312,614,309,621,310,623,312,622,317,624,320,623,324,618,327,618,329,617,331,613,332,605,329,593,329,593,327,592,326,586,323,583,320" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=75><polygon id="Vikravandi" points="578,301,578,297,572,297,571,296,571,292,568,295,565,292,565,291,567,289,573,288,591,280,598,277,599,280,604,279,607,282,604,284,607,289,613,291,616,295,616,299,622,303,623,306,622,310,613,309,612,312,601,307,598,315,593,312,584,314,581,319,577,319,575,313,578,310,578,304" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=76><polygon id="Tirukkoyilur" points="554,325,552,322,554,312,552,310,550,312,547,312,547,309,544,307,539,309,536,307,536,304,539,301,539,299,540,296,540,295,543,298,543,298,549,294,550,291,556,293,557,290,561,290,565,291,568,295,571,293,571,297,578,297,578,311,575,313,577,319,582,319,586,323,586,326,586,327,586,329,583,326,581,327,582,335,579,335,578,330,574,326,573,331,568,326,560,331,556,330,555,328,557,325" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=77><polygon id="Ulundurpet" points="543,356,535,356,539,347,536,345,535,340,535,338,538,337,538,332,536,330,539,326,540,329,551,329,554,329,553,325,557,325,555,329,560,331,568,326,573,331,574,326,578,330,579,335,582,335,581,327,583,327,583,326,585,329,586,327,586,324,588,324,593,327,593,330,597,332,598,339,593,339,591,338,589,343,591,346,594,345,594,351,589,351,591,363,586,363,583,360,578,361,575,363,571,364,565,368,563,366,557,365,554,369,551,367,549,372,546,374,546,370,547,367,544,364,542,363,542,360,543,358" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=78><polygon id="Rishivandiyam" points="513,328,511,321,510,318,507,322,506,318,505,315,505,310,497,309,489,309,489,306,489,304,487,302,487,301,489,301,493,297,501,299,507,291,515,291,519,292,519,294,523,296,528,291,532,288,532,293,529,297,534,300,539,299,538,301,539,301,536,304,536,309,540,309,544,307,547,309,547,312,550,311,551,313,552,310,554,312,552,321,554,325,554,329,540,329,539,326,536,330,538,333,538,336,534,339,533,339,522,343,518,343,518,339,515,338,511,334" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=79><polygon id="Sankarapuram" points="474,354,465,357,460,356,458,365,454,363,453,360,454,352,452,350,452,342,456,341,457,337,461,337,462,328,455,326,449,325,451,323,460,319,464,321,466,316,465,312,465,304,468,304,472,301,477,301,480,299,488,301,487,302,489,304,489,309,505,310,505,316,507,321,507,321,507,322,510,318,511,322,513,326,511,334,515,339,518,339,515,343,513,346,509,341,507,341,507,343,503,347,497,343,493,348,495,352,491,356,487,355,486,355,486,359,480,359,479,356" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=80><polygon id="Kallakurichi" points="510,378,500,379,496,389,493,390,489,387,487,387,484,383,481,383,483,377,482,374,474,371,477,369,474,365,480,362,480,359,485,359,486,355,491,356,495,352,493,348,497,343,503,347,507,343,507,341,510,341,513,346,517,342,518,340,518,343,522,343,535,338,536,345,539,347,535,356,543,356,543,358,540,361,543,363,547,367,546,371,546,374,540,373,539,374,533,372,527,368,525,370,526,373,522,376,521,373,517,372,515,377,511,379" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=81><polygon id="Gangavalli" points="452,403,458,402,462,397,468,399,476,410,478,410,482,403,482,401,477,398,479,392,481,389,485,389,486,387,487,387,484,383,481,383,483,377,481,373,474,371,477,369,474,365,480,362,480,359,479,356,474,354,464,357,460,356,458,365,454,363,452,371,455,374,447,387,443,385,440,387,443,393,447,390,443,394,441,395,437,396,435,396,435,391,429,394,420,389,416,389,415,394,417,400,416,406,424,404,428,408,428,411,434,412,435,422,439,421,443,418,449,418,456,412,453,411,453,407" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=82><polygon id="Attur" points="418,378,418,371,415,371,414,368,414,358,415,354,415,352,412,352,414,348,422,343,426,341,432,342,431,348,434,347,438,350,441,349,445,343,449,343,452,342,452,350,454,352,453,360,454,364,452,371,455,374,447,387,441,385,440,387,443,393,445,391,443,394,435,396,434,391,429,394,420,389,418,389,422,386,420,383,420,379" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=83><polygon id="Yercaud" points="387,364,392,363,394,368,394,374,395,379,397,383,405,374,410,372,416,372,415,371,414,368,414,356,415,352,413,352,412,352,414,348,422,343,426,341,432,342,431,348,434,347,438,350,441,349,445,342,449,343,452,342,456,341,457,337,461,337,462,329,461,328,449,324,443,332,436,336,429,333,420,332,417,322,412,322,401,337,395,340,395,338,401,332,405,320,404,316,397,318,398,313,392,315,392,318,388,317,392,313,388,313,387,314,389,311,384,312,383,313,377,323,369,317,369,326,365,326,365,331,364,332,367,339,369,343,372,347,377,350,374,356,379,361,379,364,385,364" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=84><polygon id="Omalur" points="341,340,344,338,342,335,342,331,340,328,339,321,339,318,339,316,352,311,363,306,383,304,385,309,385,312,381,312,383,313,377,323,369,317,369,326,365,326,365,331,364,332,367,340,367,345,362,347,358,347,352,346,348,347,344,348,338,347,333,345,330,342,331,338,332,336,335,337,338,340,341,341" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=85><polygon id="Mettur" points="292,334,289,330,284,327,280,330,280,327,284,319,287,319,286,307,294,307,296,307,301,313,316,316,319,312,330,316,337,317,339,316,340,329,342,332,342,336,344,338,341,341,337,340,335,337,331,336,328,334,324,333,323,337,317,333,317,338,309,342,306,337,302,350,299,354,296,358,292,359,288,362,287,357,287,352,289,342,292,336" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=86><polygon id="Edappadi" points="294,367,298,360,301,355,302,350,306,337,309,342,317,338,317,333,323,337,324,334,324,333,331,336,330,342,340,348,336,354,330,355,329,352,326,346,323,353,324,357,330,356,330,364,333,371,330,373,328,372,326,379,321,381,314,380,312,379,314,374,311,374,309,374,305,370,300,370,296,372,296,376,294,370" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=87><polygon id="Sankari" points="331,391,325,395,323,400,315,401,312,398,309,395,310,393,310,390,304,395,303,395,302,389,300,388,299,393,292,395,287,391,290,386,293,383,294,374,296,374,298,371,302,370,305,371,309,374,314,374,312,380,321,381,326,379,328,372,330,373,333,371,330,364,330,356,323,357,323,352,326,346,330,355,336,354,339,349,344,352,346,352,346,358,342,358,342,362,344,365,344,367,338,367,342,371,342,377,342,380,336,382,336,391" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=88><polygon id="Salem West" points="356,357,356,361,352,356,349,356,348,353,346,352,342,351,339,349,336,354,339,349,340,348,340,347,344,348,350,346,355,346,358,348,363,347,363,350,358,351,358,356" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=89><polygon id="Salem North" points="363,360,369,359,371,359,375,359,376,359,374,356,377,350,369,343,369,341,367,345,362,347,363,350,358,351,358,356,358,358,361,360" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=90><polygon id="Salem South" points="358,366,362,363,364,367,367,367,374,367,377,363,379,363,379,361,376,357,376,359,367,359,361,360,358,359,358,356,356,357,356,362,356,361" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=91><polygon id="Veerapandi" points="362,380,358,377,354,379,353,383,350,384,344,381,342,380,342,380,342,377,342,371,338,367,338,367,344,367,344,364,342,361,342,358,346,358,346,352,349,356,352,356,356,362,356,361,358,365,362,363,364,368,375,367,376,363,379,363,381,363,379,364,388,364,393,363,394,368,394,372,386,374,386,378,377,376,375,378" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=92><polygon id="Rasipuram" points="358,393,352,396,349,392,349,389,352,389,354,387,351,384,352,383,353,383,354,379,358,377,362,380,374,378,378,376,386,378,386,374,394,372,394,372,394,374,395,381,397,383,406,373,411,372,416,372,416,371,418,371,418,378,420,380,420,384,422,386,418,389,415,389,415,394,417,400,414,403,409,400,409,397,401,399,398,400,397,403,393,402,390,400,394,397,394,391,385,391,381,394,379,398,381,404,379,407,375,403,372,401,369,401,365,400,363,403,358,402,358,397,358,394" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=93><polygon id="Senthamangalam" points="371,450,372,445,369,441,371,437,375,437,375,434,374,431,376,426,376,419,376,417,381,417,379,411,379,406,379,407,381,403,379,398,385,391,394,391,394,397,390,400,394,403,397,403,398,400,409,397,409,400,414,403,417,400,416,406,424,404,422,408,418,412,418,417,417,417,420,422,413,433,411,440,405,444,404,453,397,452,394,458,401,466,397,471,393,466,387,462,383,463,379,459,377,459,372,452" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=94><polygon id="Namakkal" points="356,463,358,460,358,457,360,452,358,448,362,445,358,445,355,444,349,451,346,448,346,444,349,444,346,434,344,426,351,422,356,426,363,424,361,420,352,412,356,409,356,404,356,402,358,402,362,403,365,400,372,401,377,404,379,407,379,412,381,417,376,417,376,427,374,431,375,437,371,437,369,441,372,447,371,450,378,460,379,463,378,465,372,463,367,465,367,468,371,468,371,471,365,474,361,468" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=95><polygon id="Paramathi-Velur" points="315,435,315,429,319,420,335,421,337,421,337,415,341,409,336,407,339,401,346,403,350,404,353,403,356,408,352,414,361,420,362,424,356,426,350,422,344,426,349,444,346,444,346,448,349,451,355,444,358,445,363,445,358,448,358,453,358,458,358,459,358,463,350,461,348,462,340,457,331,460,327,463,319,460,317,451,317,445,314,442,316,438" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=96><polygon id="Tiruchengodu" points="302,422,306,420,307,415,304,412,304,411,308,408,311,406,313,402,313,399,315,401,323,400,325,395,331,391,336,391,336,382,344,380,350,384,354,387,351,389,348,389,349,392,352,396,358,393,358,397,358,402,356,402,356,408,353,403,350,404,346,403,339,401,336,407,340,409,337,415,337,422,321,420,319,421,315,430,311,427,306,427" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=97><polygon id="Kumarapalayam" points="289,404,284,396,287,391,292,395,299,393,300,388,302,389,303,395,310,390,310,393,309,395,314,400,312,403,311,406,304,411,307,415,306,420,302,422,298,418,296,416,298,412,291,407,288,404" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=98><polygon id="Erode East" points="287,416,292,415,296,415,296,416,298,412,289,404,288,404,287,403,284,406,287,408,286,410,282,412,284,416" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=99><polygon id="Erode West" points="280,426,284,423,289,421,292,421,292,418,296,417,296,415,288,416,284,416,282,412,286,410,287,408,284,406,287,403,288,403,284,396,282,393,278,392,277,400,276,403,273,408,273,411,273,412,271,420,268,429,270,435,275,440,279,435,284,436,284,433,280,431" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=100><polygon id="Modakkurichi" points="299,464,293,458,287,459,280,454,278,453,278,444,275,440,279,435,284,436,284,433,280,431,280,424,286,423,288,421,292,421,292,418,296,417,302,422,306,428,311,427,315,430,316,438,314,442,317,445,319,459,326,463,323,466,315,470,311,467,308,466,306,462" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=101><polygon id="Dharapuram" points="218,525,222,525,224,532,231,532,233,538,240,536,242,534,248,535,250,542,255,542,255,536,265,529,271,531,276,531,278,523,284,519,284,525,284,532,284,535,289,538,292,536,293,531,301,530,302,530,304,525,306,517,298,516,296,514,296,512,300,511,301,507,308,512,314,514,317,514,317,511,314,509,315,502,312,501,308,502,302,497,299,496,294,497,282,492,280,498,271,496,269,496,267,494,265,494,264,488,261,489,261,495,259,497,251,495,246,491,244,489,236,490,236,488,234,487,228,489,228,492,212,497,210,503,210,508,214,510,214,514,216,515,217,526" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=102><polygon id="Kangayam" points="250,465,250,469,247,472,245,478,245,481,236,484,234,487,236,488,236,490,245,489,251,495,259,497,261,495,261,489,264,488,265,494,267,494,269,496,273,496,280,498,282,492,294,497,296,496,300,496,299,494,294,490,296,481,294,478,296,475,302,470,301,467,299,464,292,458,287,459,278,453,278,444,273,439,269,435,265,435,263,438,264,444,257,442,251,446,250,447,251,451,243,451,243,455,245,455,245,463" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=103><polygon id="Perundurai" points="236,416,240,414,246,414,248,409,251,409,253,404,251,400,255,400,257,404,261,406,265,406,267,402,271,402,275,402,275,403,273,408,273,412,273,417,268,429,270,436,265,435,263,438,264,444,257,442,250,447,251,451,243,451,243,455,243,450,240,449,236,449,232,449,233,445,234,442,234,437,231,432,231,429,233,424,229,419,228,415,228,411,234,415,235,416" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=104><polygon id="Bhavani" points="268,392,267,395,259,393,255,388,253,394,255,400,257,406,264,406,267,402,273,402,275,404,277,401,278,392,282,393,284,396,287,391,290,386,293,382,294,374,296,374,294,366,300,356,302,354,302,350,296,358,291,359,288,362,287,351,286,351,284,353,280,353,279,357,282,360,280,364,273,365,273,371,273,373,271,379,270,382,263,387,264,391" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=105><polygon id="Andhiyur" points="243,357,245,365,245,371,241,373,240,378,235,380,231,378,232,383,228,381,228,386,230,388,240,387,243,385,250,383,248,387,246,387,246,391,250,392,245,397,245,400,251,400,255,400,253,394,255,388,261,394,267,395,268,392,264,391,263,387,270,382,273,373,273,365,280,364,282,360,279,357,280,353,284,353,286,351,288,351,287,351,289,342,292,336,292,334,288,329,284,327,280,330,280,327,284,319,286,319,287,319,286,306,286,305,280,305,276,307,271,307,261,307,255,307,255,306,251,315,247,314,247,325,244,334,241,336,240,342,244,345,244,350,244,355" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=106><polygon id="Gobichettipalayam" points="208,401,209,397,214,395,219,392,217,388,215,385,216,383,218,380,220,381,220,381,221,377,226,377,229,372,229,370,230,372,229,376,232,378,231,378,232,383,228,382,228,386,230,388,239,387,244,385,250,383,248,387,246,387,246,390,250,392,245,396,245,400,251,400,253,406,251,409,248,409,246,414,240,414,236,416,236,416,235,416,228,411,228,416,221,416,224,420,223,423,222,426,217,423,218,421,215,419,215,411,210,416,208,412,206,416,205,408,197,410,197,407,200,400,205,401,208,402" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=107><polygon id="Bhavanisagar" points="168,377,168,372,160,370,158,367,152,367,146,367,140,367,139,363,143,363,143,359,138,354,140,349,145,340,148,340,150,333,151,328,159,329,163,333,165,326,172,326,175,332,176,329,180,331,178,335,182,340,188,341,188,333,192,333,193,331,211,330,211,327,220,329,227,335,231,332,236,333,241,336,240,342,244,345,244,355,243,358,245,365,245,371,241,373,240,379,234,380,231,378,229,376,230,372,229,370,229,373,226,377,221,377,220,381,217,380,215,385,219,392,209,397,208,402,200,400,197,407,197,411,197,414,190,410,189,410,188,404,186,402,184,398,182,399,180,401,177,399,173,398,170,403,164,403,159,400,162,398,162,392,168,393,168,389,165,384,166,379,166,378,166,379" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=108><polygon id="Udhagamandalam" points="91,391,94,389,101,388,103,390,105,390,106,384,113,379,116,373,110,369,113,366,118,363,122,359,130,359,140,363,139,367,144,374,141,381,134,384,133,395,123,396,121,400,122,409,119,408,117,403,111,403,111,412,111,421,110,425,102,431,98,431,93,429,84,431,79,428,73,428,72,432,69,431,67,429,70,423,79,418,84,414,86,408,87,404,87,402,81,402,81,399,82,400,86,398,90,395,93,392" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=109><polygon id="Gudalur" points="52,361,58,359,60,357,60,353,69,353,70,350,67,348,73,349,77,343,79,342,85,342,89,346,91,356,98,359,102,358,122,359,119,362,111,366,110,369,116,373,111,380,106,384,105,390,103,390,99,388,94,389,91,392,91,394,83,400,82,400,73,398,66,393,63,391,63,387,61,388,54,383,52,383,49,385,44,381,43,379,36,381,36,377,36,371,35,371,36,369,33,364,36,361,41,358,45,364,49,359,52,362" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=110><polygon id="Coonoor" points="123,417,126,418,129,415,135,417,139,417,140,412,140,408,147,404,150,406,154,404,155,403,158,401,159,400,162,398,162,392,168,393,168,389,165,384,166,378,168,372,159,370,158,367,139,367,144,373,144,374,141,381,134,384,133,395,122,396,121,400,122,409,119,408,117,403,111,403,111,421,114,421,119,424,122,423,125,421" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=111><polygon id="Mettuppalayam" points="145,434,135,437,135,442,121,446,120,442,116,442,111,440,110,440,110,437,116,433,116,427,114,426,111,423,113,421,120,424,123,421,123,417,128,418,130,415,140,416,140,410,139,409,144,404,148,404,149,407,154,404,155,403,159,401,169,403,173,399,178,399,178,401,182,400,182,398,184,399,184,403,188,403,189,410,182,412,179,409,177,412,173,412,173,418,166,424,166,431,165,435,162,433,159,435,159,441,158,442,156,439,154,442,155,446,151,448,148,447,152,441,149,439,149,434" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=112><polygon id="Avanashi" points="202,448,207,446,210,451,215,451,215,445,218,444,219,438,221,434,222,426,218,424,218,421,215,419,215,412,210,416,208,412,206,412,205,409,197,410,196,414,190,411,189,410,182,412,179,410,177,412,173,412,173,418,166,424,166,430,165,435,168,439,171,444,178,450,181,452,187,449,187,448,184,447,184,442,182,440,186,434,190,434,193,441,196,442,195,445,199,445" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=113><polygon id="Tiruppur North" points="221,447,217,451,215,451,215,445,218,444,219,438,221,434,222,426,224,421,224,418,222,416,228,416,231,420,232,427,231,431,234,439,232,448,229,448,220,447,221,448,221,448" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=114><polygon id="Tiruppur South" points="230,455,222,457,219,454,217,451,221,447,232,448,234,450,236,450,238,451,240,456,236,459,232,455,229,455" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=115><polygon id="Palladam" points="211,496,209,495,206,488,196,485,194,481,193,471,190,471,193,469,189,460,192,459,195,461,205,458,206,452,210,451,217,451,220,455,222,457,232,455,236,460,240,456,238,450,236,450,238,448,243,450,243,455,244,457,246,463,250,464,250,470,244,480,236,484,236,488,228,489,228,492,216,495,212,497" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=116><polygon id="Sulur" points="170,490,175,483,174,480,170,475,170,472,173,470,172,464,174,460,174,455,181,453,181,452,187,449,184,447,184,442,182,440,186,434,190,434,193,441,196,442,195,445,199,445,202,448,207,446,210,451,206,452,205,458,195,461,192,459,189,460,193,469,190,471,194,472,193,480,196,484,196,485,206,488,209,495,212,497,212,501,209,507,207,509,199,509,197,503,190,503,189,496,186,492,182,492,182,489,174,490" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=117><polygon id="Kavundampalayam" points="135,458,127,458,125,460,118,456,121,453,118,448,121,446,135,442,135,437,145,434,149,434,149,439,152,441,149,447,151,448,155,446,154,442,156,439,158,442,159,439,159,435,162,433,166,435,171,444,180,451,181,451,181,453,174,455,174,460,172,465,168,461,166,461,163,459,154,460,151,461,141,461,138,458" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=118><polygon id="Coimbatore North" points="147,468,140,467,140,461,141,461,152,461,155,460,156,466,151,468,148,468" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=119><polygon id="Thondamuthur" points="133,483,133,489,127,489,120,486,113,484,102,478,109,466,113,459,122,463,125,461,127,458,138,458,141,461,140,461,140,466,148,468,152,468,156,466,156,471,158,475,156,481,148,481,148,472,136,472,136,480,136,482" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=120><polygon id="Coimbatore South" points="159,471,166,475,168,477,171,476,171,471,166,471,160,464,158,463,155,464,156,471,158,472" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=121><polygon id="Singanallur" points="160,464,166,471,170,471,173,470,172,465,168,461,166,461,163,459,156,460,155,460,155,464,158,463" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=122><polygon id="Kinathukkadavu" points="155,508,151,507,145,506,144,501,139,501,135,499,136,496,132,491,132,489,133,483,136,482,136,472,148,472,148,481,156,481,158,476,157,472,159,471,166,475,168,477,170,477,171,476,174,481,174,483,170,490,166,494,169,505,164,506,160,505" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=123><polygon id="Pollachi" points="155,526,153,533,149,531,147,529,140,529,140,525,136,523,142,517,145,510,145,506,155,508,160,505,163,506,169,505,166,493,170,490,182,489,182,492,186,492,189,496,189,503,189,508,189,509,184,513,183,517,175,517,173,529,170,531,166,528,165,532,158,531,158,526" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=124><polygon id="Valparai" points="166,570,174,579,174,591,166,595,166,599,155,607,151,604,142,603,141,600,136,596,136,592,132,594,128,590,132,579,128,574,130,572,127,568,129,564,132,549,130,547,130,545,132,539,128,537,127,532,138,532,141,532,140,529,147,529,149,531,154,533,155,533,157,536,159,536,159,543,166,543,166,540,173,543,174,546,173,558,170,561,172,565,168,569" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=125><polygon id="Udumalpet" points="199,534,192,534,189,543,181,543,173,543,166,540,166,543,159,543,159,536,157,536,154,533,153,533,154,526,158,526,158,532,164,532,166,528,170,531,173,529,175,517,183,517,184,513,189,508,189,502,197,503,199,509,208,509,210,506,211,506,215,514,216,516,216,527,215,531,214,536,209,544,205,547,204,553,200,550,200,545,197,544,198,543,199,537,199,535" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=126><polygon id="Madathukulam" points="216,567,214,585,217,584,217,591,220,598,219,602,216,601,212,604,210,603,208,606,204,606,204,599,198,591,200,584,188,583,179,591,174,591,174,579,166,570,172,565,170,561,173,558,174,547,174,546,173,543,189,543,192,534,199,534,198,544,200,546,200,550,204,553,205,547,210,543,214,536,216,528,217,525,222,525,223,533,230,533,233,537,227,546,224,553,230,555,230,559,227,561,227,568,221,569,220,568" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=127><polygon id="Palani" points="228,619,223,623,220,621,216,624,209,624,205,627,205,625,207,612,210,608,208,606,210,603,212,604,216,601,219,602,220,598,217,591,217,584,214,585,216,567,222,569,228,568,227,561,230,559,230,555,239,555,244,555,251,557,253,555,265,557,266,575,270,574,273,573,277,574,277,578,284,585,288,593,280,601,273,601,275,604,280,607,282,609,280,614,273,615,267,611,257,615,255,613,246,620,238,624,233,625,229,622" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=128><polygon id="Oddamchatram" points="288,538,282,533,284,526,282,520,277,524,276,530,263,529,255,538,255,541,250,541,247,534,236,537,233,537,226,548,224,553,231,557,231,555,247,555,251,557,253,555,265,557,266,576,273,573,278,574,277,578,284,585,287,581,287,574,294,569,299,562,301,562,306,565,307,565,307,559,309,557,315,559,317,555,321,557,321,551,313,549,314,538,304,537,303,530,294,530,292,532,292,537" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=129><polygon id="Athoor" points="299,606,300,611,296,615,292,612,289,614,282,609,279,605,275,604,273,601,280,601,288,593,284,585,287,581,287,573,288,573,294,569,299,562,301,562,306,565,307,565,307,559,310,557,315,559,317,558,317,561,325,561,332,565,333,577,327,574,326,581,323,581,323,587,324,594,323,599,325,602,319,608,315,606,315,602,311,600,310,606,307,607" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=130><polygon id="Nilakkottai" points="300,637,296,640,291,641,282,647,280,635,280,631,273,628,277,623,280,627,284,627,284,622,280,616,280,614,282,609,289,614,292,612,296,615,300,611,299,606,307,607,310,606,311,600,315,602,315,605,315,606,319,608,319,613,323,618,323,623,324,628,321,633,321,636,319,636,317,638,310,638,301,638" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=131><polygon id="Natham" points="354,618,338,620,336,623,333,623,329,627,324,627,323,622,323,618,319,612,319,608,325,602,323,599,324,594,327,590,342,589,346,587,344,584,348,584,354,585,355,584,356,580,358,580,360,577,364,579,364,586,365,581,372,577,374,578,378,576,373,572,373,570,379,571,389,574,388,579,383,585,384,587,393,595,392,600,390,612,385,619,377,623,383,624,381,630,378,636,369,640,360,633,362,628,360,622,358,619" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=132><polygon id="Dindigul" points="338,579,342,576,344,578,344,584,346,587,342,589,327,590,325,594,324,593,323,581,326,581,328,574,333,577,336,577" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=133><polygon id="Vedasandur" points="331,538,317,535,313,538,313,549,321,551,319,557,317,555,317,559,319,561,325,561,331,565,332,565,333,577,337,577,338,579,342,576,344,579,344,584,354,585,356,581,356,580,358,580,360,577,364,579,364,585,365,581,372,577,374,578,378,576,373,572,373,570,367,564,365,563,367,558,367,554,358,552,358,547,364,543,363,537,361,537,361,528,363,528,363,519,365,510,369,507,365,503,363,507,362,509,354,510,353,515,344,515,336,514,336,516,330,516,326,515,324,520,335,519,335,521,338,522,337,532,331,532" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=134><polygon id="Aravakurichi" points="336,495,340,501,340,503,344,506,344,515,336,514,336,516,330,516,326,515,324,520,335,519,335,521,338,522,337,532,331,532,331,538,317,535,313,538,304,537,303,530,302,527,305,522,306,516,298,516,296,513,298,510,300,510,302,507,313,513,317,514,317,511,314,509,314,501,312,501,309,501,305,499,300,495,298,495,294,490,296,480,292,478,299,472,301,468,299,462,308,462,308,465,311,466,312,469,317,470,321,467,326,462,330,462,336,458,342,458,348,461,348,464,344,469,340,470,339,475,338,477,340,483,340,486,337,486,333,491" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=135><polygon id="Karur" points="358,465,365,472,369,481,365,484,361,479,355,481,356,493,348,493,344,488,346,484,340,483,338,476,340,472,340,470,342,469,344,468,348,464,348,461,352,461,358,463" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=136><polygon id="Krishnarajapuram" points="384,507,385,495,390,495,393,487,390,483,384,482,373,483,369,481,365,484,361,479,355,481,356,493,348,493,344,488,346,484,340,483,340,486,336,486,333,492,333,491,341,502,340,503,344,506,344,515,353,515,354,510,362,509,365,503,369,507,365,510,363,519,363,528,361,528,361,537,363,537,364,543,358,547,358,552,367,554,367,554,367,558,373,558,373,557,378,557,378,559,381,554,381,551,379,545,384,534,385,524,386,520,389,519,389,514,390,512,390,509,387,511,387,509" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=137><polygon id="Kulithalai" points="401,524,394,528,386,528,386,524,385,523,386,520,389,519,389,514,390,512,390,509,387,511,387,509,384,508,385,495,390,495,393,487,390,483,407,483,418,492,418,497,424,496,435,501,437,503,436,506,439,506,438,511,430,511,432,514,435,516,435,524,424,530,416,529,415,532,408,534,404,530" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=138><polygon id="Manapparai" points="415,550,410,546,411,538,409,537,406,541,404,540,404,530,401,524,394,528,386,528,386,524,385,523,384,535,379,545,381,552,381,553,378,559,378,557,374,557,374,558,367,558,365,563,369,565,373,570,379,571,389,574,388,579,383,585,385,588,393,595,393,596,392,600,397,600,403,596,405,594,403,590,412,589,411,583,413,580,422,584,422,588,426,587,427,584,424,581,424,577,432,577,434,575,436,575,438,571,437,569,435,567,436,564,436,562,431,563,430,560,428,561,429,565,424,568,420,567,420,558,416,557,416,551" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=139><polygon id="Srirangam" points="439,537,435,537,435,533,426,535,428,542,418,542,412,548,410,546,411,538,409,537,406,541,404,539,404,530,408,534,415,532,417,529,424,530,435,524,435,516,431,513,430,511,438,511,439,506,436,505,437,503,435,501,422,496,418,497,418,492,422,491,443,499,452,498,461,501,462,501,459,506,456,503,455,507,452,503,449,507,456,512,455,518,458,521,457,525,458,530,452,537,449,530,445,529,445,533,441,533" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=140><polygon id="Tiruchirappalli West" points="461,518,461,523,459,525,457,525,458,521,455,518,456,514,459,515" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=141><polygon id="Tiruchirappalli East" points="472,509,468,516,461,518,459,515,456,514,456,511,449,507,452,503,455,507,456,503,459,506,461,505,462,501,478,505,472,508,472,510" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=142><polygon id="Thiruverumbur" points="488,509,472,509,468,516,461,518,461,523,459,525,462,528,465,529,465,534,466,540,466,541,470,539,474,540,476,535,480,532,488,532,489,530,487,527,489,517,488,513" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=143><polygon id="Lalgudi" points="478,472,470,492,462,498,461,501,478,505,478,506,487,505,497,501,503,498,511,497,511,497,510,492,506,489,502,486,507,484,510,480,514,478,513,468,507,462,491,461,489,462,484,464,478,465,478,471" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=144><polygon id="Manachanallur" points="453,467,457,471,463,471,462,467,466,464,466,459,470,456,479,459,478,465,478,472,470,492,461,499,461,502,452,498,443,499,422,491,420,491,422,485,424,481,432,482,433,478,431,476,424,480,418,476,420,470,427,467,436,468,438,464,441,464,447,462,453,462,452,467" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=145><polygon id="Musiri" points="397,471,399,467,401,464,394,458,397,456,398,452,404,452,405,442,411,440,413,441,414,446,418,442,422,445,422,453,422,464,427,467,420,470,418,476,422,479,424,479,431,476,433,478,432,482,424,481,422,487,420,491,418,492,407,483,390,483,383,482,373,483,369,481,367,474,372,471,371,469,365,467,371,463,374,463,378,465,378,461,379,458,381,460,383,463,387,462,393,465,394,470" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=146><polygon id="Thuraiyur" points="435,421,435,412,427,409,427,406,424,404,418,412,417,417,420,422,416,428,411,440,413,441,414,446,418,442,422,445,422,454,422,464,427,467,436,468,438,464,441,464,445,462,453,462,452,467,453,467,457,471,463,471,463,467,459,466,458,459,455,449,452,448,456,442,461,442,462,438,463,433,468,429,468,425,465,422,455,420,449,419,445,417,439,421" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=147><polygon id="Perambalur" points="478,409,476,409,472,403,468,398,461,398,457,403,453,403,453,409,457,412,449,419,465,422,468,425,468,429,463,433,461,442,456,442,452,448,455,449,458,458,459,466,462,467,466,464,466,459,470,456,479,459,478,465,484,464,489,462,486,461,485,457,485,449,487,447,495,449,496,451,503,446,498,437,502,435,502,430,497,428,507,418,511,418,511,414,509,408,507,407,491,388,489,386,485,386,485,388,481,388,480,393,476,398,482,401,481,404" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=148><polygon id="Kunnam" points="536,432,529,439,528,442,523,442,521,447,523,460,522,464,518,463,517,467,514,468,507,462,491,461,489,462,486,460,485,448,488,446,495,449,495,451,503,446,498,436,503,435,502,430,497,428,507,418,511,418,511,414,509,407,513,407,515,410,522,408,533,409,540,412,546,412,553,410,555,414,558,411,563,414,563,418,558,420,555,426,561,436,563,444,558,450,543,451,540,444,543,439,540,436" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=149><polygon id="Ariyalur" points="529,491,525,492,519,498,513,498,511,497,510,492,502,486,507,484,510,480,514,478,513,468,517,467,518,463,522,464,523,459,521,447,523,442,528,442,529,439,536,432,540,437,543,439,540,444,543,451,559,450,563,444,563,451,565,452,567,455,564,458,572,471,565,476,558,481,549,489,542,489,535,491" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=150><polygon id="Jayankondam" points="600,440,594,450,592,450,592,455,586,460,584,466,578,471,572,471,564,458,567,455,565,452,563,451,563,444,561,435,555,426,559,420,563,418,563,414,560,412,564,412,563,408,567,406,579,407,581,412,581,418,583,418,583,417,589,417,589,421,596,425,600,425,600,434,599,436" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=151><polygon id="Tittakudi" points="536,394,540,396,543,394,543,391,552,390,556,394,558,389,561,395,563,399,568,403,567,406,563,408,564,412,560,412,558,411,555,414,552,410,546,412,540,412,533,409,521,408,515,410,513,407,509,407,507,407,493,389,496,389,500,379,510,378,514,378,517,374,517,372,523,374,527,372,528,374,522,385,527,386,532,385,533,390,536,391" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=152><polygon id="Vridhachalam" points="551,367,549,372,544,376,542,373,538,376,534,372,527,367,525,370,527,372,527,374,528,374,522,385,528,386,532,385,533,390,536,391,536,394,540,396,543,394,543,391,552,390,556,394,558,389,561,395,565,393,569,394,569,391,577,391,578,386,584,388,585,384,589,382,589,377,589,372,594,371,591,367,589,362,581,361,575,363,569,365,565,368,563,365,557,366,554,368" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=153><polygon id="Neyveli" points="589,351,589,360,589,363,591,368,594,371,589,372,591,378,594,377,597,380,605,382,608,382,610,378,618,376,623,372,622,368,628,368,631,362,626,359,623,356,618,356,617,352,611,348,604,347,603,345,596,343,593,345,594,350" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=154><polygon id="Panruti" points="633,341,633,348,632,350,627,351,618,349,617,352,610,348,604,347,602,343,593,343,593,346,589,345,589,338,597,340,597,334,592,330,593,326,599,329,609,330,610,332,617,332,623,338,627,340,630,338" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=155><polygon id="Cuddalore" points="642,352,637,346,633,346,633,341,634,338,635,329,639,331,643,329,643,333,639,335,639,339,638,341,639,343,646,342,652,342,652,347,649,358,646,357" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=156><polygon id="Kurinjipadi" points="635,383,630,386,627,392,624,392,622,389,614,392,608,393,604,395,604,390,606,386,604,383,608,382,610,378,618,376,623,372,622,368,627,368,627,368,631,362,626,359,623,356,618,356,616,351,620,349,628,351,633,349,634,346,635,346,638,346,646,357,649,358,647,370,645,382,639,381,637,380" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=157><polygon id="Bhuvanagiri" points="604,403,593,406,589,406,584,403,579,400,573,400,571,398,568,402,573,402,577,403,579,407,567,406,568,403,563,399,561,395,565,393,569,394,569,391,577,391,578,386,585,388,585,384,589,382,589,377,591,378,594,377,598,380,605,382,606,386,604,390,604,395,608,393,614,392,622,389,624,392,627,392,628,395,626,399,629,403,629,412,628,416,624,414,620,418,610,418,606,415,605,410,605,403" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=158><polygon id="Chidambaram" points="633,424,633,419,627,421,622,421,624,418,625,414,628,416,629,412,629,403,626,399,628,394,627,392,630,386,635,383,637,380,645,382,646,389,649,394,654,404,654,411,652,415,645,414,645,419,637,421,634,425,633,423" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=159><polygon id="Kattumannarkoil" points="617,442,605,448,593,453,592,453,592,450,594,450,600,440,599,436,600,434,600,425,596,425,589,421,589,417,584,417,582,417,582,418,581,418,581,412,579,407,577,403,568,402,571,398,572,399,579,400,585,404,589,406,596,406,605,403,606,415,611,419,621,418,625,414,623,419,621,421,627,421,633,419,633,424,633,425,626,427,625,431,625,438,618,435" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=160><polygon id="Sirkazhi" points="629,451,628,445,630,442,625,438,626,427,633,425,634,425,637,421,645,419,645,414,652,415,655,409,657,415,659,421,658,428,660,442,660,460,660,448,652,454,635,455,632,459,633,454,637,453,637,450" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=161><polygon id="Mayuram" points="607,469,631,470,632,465,635,466,635,464,632,464,632,459,633,454,637,453,637,450,629,451,628,445,630,442,625,438,618,435,617,442,605,448,605,450,610,454,611,456,606,462,607,468" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=162><polygon id="Poompuhar" points="601,486,608,487,612,484,616,486,621,484,623,480,630,478,639,482,642,481,649,482,650,485,653,481,659,482,660,483,660,466,660,449,660,449,652,454,635,455,632,459,632,463,632,464,635,464,635,466,632,465,631,470,607,469,606,468,601,472,603,477,604,478,605,481,601,483,601,485" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=163><polygon id="Nagapattinam" points="624,515,625,509,622,506,625,503,629,495,635,495,642,497,646,499,649,499,654,501,652,507,659,512,660,524,650,526,643,521,643,518,649,520,650,515,645,509,641,511,638,516,637,511,631,511,629,513" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=164><polygon id="Kilvelur" points="628,536,625,544,627,553,635,553,642,554,643,555,649,554,651,562,660,560,659,524,650,526,643,521,643,518,649,520,649,514,645,509,639,511,638,516,637,517,633,521,632,526,630,530,627,532,624,532" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=165><polygon id="Vedaranyam" points="621,578,630,578,629,572,632,571,630,568,633,567,635,563,634,560,629,560,628,555,627,553,641,554,643,555,649,554,651,562,659,560,660,574,660,585,662,596,663,605,660,608,639,610,632,608,632,604,620,595,620,579" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=166><polygon id="Thiruthuraipoondi" points="593,569,597,560,598,551,599,544,599,541,608,539,612,542,620,542,625,544,629,560,634,560,635,563,633,567,630,568,632,571,629,572,630,578,621,578,620,579,620,595,632,604,632,608,606,604,593,602,591,602,592,595,597,595,597,591,591,591,589,588,593,587,588,580,592,581,592,576,593,573" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=167><polygon id="Mannargudi" points="575,509,571,520,574,523,568,526,565,526,565,534,565,539,572,543,571,554,579,555,579,559,589,558,584,562,593,569,597,559,598,550,599,541,597,535,598,531,601,529,602,525,593,525,589,518,586,512,582,512"/></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=168><polygon id="Thiruvarur" points="606,509,611,509,612,511,614,513,618,517,621,514,624,515,630,513,631,511,637,511,638,516,633,521,632,527,629,531,624,532,628,537,625,544,618,542,613,542,608,539,600,541,597,535,598,531,601,529,602,525,592,525,589,517,589,512,591,509,597,510,599,511,603,509"/></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=169><polygon id="Nannilam" points="597,494,602,490,601,486,608,487,612,484,616,486,621,484,623,480,630,478,639,482,642,481,643,488,639,489,639,487,637,487,637,490,639,490,637,493,639,496,634,494,629,495,625,503,622,506,625,510,624,514,620,515,618,517,614,512,612,511,611,509,606,509,602,508,598,512,592,509,588,506,589,502,594,502,595,498" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=170><polygon id="Thiruvidaimarudur" points="582,498,586,487,582,483,584,476,584,471,580,469,584,466,586,459,592,455,593,453,605,448,605,450,610,454,611,456,606,462,608,469,606,468,601,472,604,479,605,481,601,483,601,488,602,490,597,494,599,498,594,501,594,502,589,502,588,506,588,502,581,499" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=171><polygon id="Kumbakonam" points="568,494,572,490,572,484,568,482,565,476,572,471,578,471,581,469,584,471,584,475,582,483,586,487,586,512,574,512" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=172><polygon id="Papanasam" points="569,497,569,494,569,491,568,495,572,488,568,482,568,479,565,476,561,478,553,486,547,490,543,489,535,490,536,498,540,498,542,501,546,506,542,508,543,512,542,514,543,514,543,517,544,520,550,526,553,529,556,528,557,523,559,524,560,527,564,526,564,525,569,526,574,523,569,520,572,517,575,516,575,514,572,513,571,510,571,502,568,501"/></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=173><polygon id="Thiruvaiyaru" points="509,528,511,529,517,529,519,528,521,521,527,520,532,517,533,510,539,513,542,514,543,512,542,508,546,506,540,501,540,498,536,498,535,490,530,492,525,492,521,499,511,497,502,498,498,501,493,502,484,506,472,507,473,509,480,509,487,509,489,517,486,525,489,532,495,536,498,533,500,538,505,539,507,534" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=174><polygon id="Thanjavur" points="521,531,514,532,511,531,511,529,517,529,519,528,521,521,526,520,526,520,532,517,533,510,540,514,543,513,544,520,543,521,536,520,536,522,536,527,534,528,532,525,528,529,523,528,523,531" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=175><polygon id="Orathanadu" points="536,562,533,570,540,572,540,572,544,566,552,565,558,568,561,566,567,570,572,565,578,562,580,559,579,554,571,554,572,543,565,539,564,526,560,527,559,523,557,523,556,528,552,529,544,520,542,521,536,520,536,522,536,527,534,528,532,525,528,529,523,528,523,531,515,531,514,533,513,536,522,536,522,542,529,546,532,544,535,545,535,552,542,553,543,557,540,562" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=176><polygon id="Pattukkottai" points="559,585,560,582,556,575,557,568,561,566,567,570,572,564,576,563,579,561,579,559,580,559,586,559,585,562,589,564,589,570,593,570,592,580,588,581,592,586,591,590,598,593,597,596,591,596,591,601,576,600,571,605,568,600,561,599,565,595,561,588" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=177><polygon id="Peravurani" points="531,612,531,606,529,603,532,599,531,597,535,594,535,587,536,585,532,580,534,577,539,577,543,574,540,572,544,566,551,565,557,567,556,575,560,582,559,585,565,595,561,599,568,600,571,605,565,606,555,614,557,616,553,623,550,624,547,632,544,632,543,628,535,628,536,620,542,620,539,616,534,615,529,615,529,611" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=178><polygon id="Gandharvakottai" points="466,565,472,557,476,555,476,554,468,552,472,547,474,549,480,547,480,543,473,539,474,536,478,536,479,533,488,533,489,532,495,536,498,533,500,538,505,539,509,528,511,529,511,531,515,532,513,534,513,536,522,536,523,542,529,546,532,544,535,545,535,552,542,553,543,558,540,562,536,562,533,570,540,572,543,574,539,577,534,577,532,579,529,577,528,573,522,574,519,579,517,578,517,575,519,570,517,565,513,559,509,555,506,560,503,555,498,555,497,562,491,565,491,572,485,577,483,574,486,568,483,565,480,568,479,572,480,575,476,577,472,581,470,577,468,575,464,574,462,572,460,570,466,570,466,564,466,564,466,564,466,564,466,564,466,564,466,564,466,564,466,564,466,563,466,564,466,564,466,564,466,564" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=179><polygon id="Viralimalai" points="436,576,438,570,435,567,437,562,432,562,429,560,429,564,426,568,420,567,420,559,417,558,415,549,415,545,420,541,427,542,428,539,427,535,433,532,435,533,435,537,439,537,441,534,443,534,445,530,449,529,449,537,451,538,454,535,457,532,457,525,460,526,465,529,466,533,465,535,466,541,468,539,472,540,473,539,480,543,480,546,474,549,472,547,468,552,476,554,476,555,472,557,466,565,466,570,460,570,464,574,468,575,472,581,476,577,474,580,482,591,480,595,473,595,468,590,458,592,454,589,449,582,441,580,437,579" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=180><polygon id="Pudukkottai" points="503,585,496,583,488,585,481,591,480,595,473,595,468,590,457,592,453,588,456,586,462,586,466,585,470,585,472,581,476,577,480,575,479,572,480,568,483,565,486,568,483,574,485,577,491,572,491,565,497,562,498,555,503,555,506,560,509,555,513,559,519,570,517,575,517,578,519,579,522,574,528,573,529,577,532,579,536,586,533,590,525,590,519,590,513,587,511,583" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=181><polygon id="Thirumaiyam" points="451,618,447,613,447,607,435,604,435,607,426,609,422,615,422,621,416,618,418,612,417,610,412,610,414,606,424,606,424,596,420,590,424,587,427,584,424,580,426,577,432,578,434,576,436,576,438,580,449,582,454,589,458,593,468,590,474,595,481,595,481,598,489,602,493,613,495,620,495,624,501,632,495,634,493,628,486,629,482,633,477,626,476,619,468,618,468,621,468,624,461,627,457,624,453,629,449,624,449,621" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=182><polygon id="Alangudi" points="517,622,507,618,507,618,506,623,495,621,495,619,491,606,489,602,481,598,481,595,480,595,482,590,488,585,496,583,503,585,511,583,513,587,519,590,533,590,535,587,535,594,531,597,531,599,532,599,529,603,531,606,531,612,529,611,529,615,536,615,540,619,540,620,535,620,531,621,521,623,519,625" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=183><polygon id="Aranthangi" points="503,657,502,654,495,652,496,645,497,642,501,638,503,641,505,640,503,637,503,633,501,632,495,624,495,621,506,623,507,618,510,619,517,622,519,625,521,623,528,622,535,620,536,620,535,628,543,628,544,632,547,632,547,640,552,644,553,650,550,653,534,669,534,671,529,676,529,682,515,680,511,674,506,666,509,659,509,658" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=184><polygon id="Karaikudi" points="461,699,465,694,468,694,468,689,470,693,478,694,473,701,476,704,482,699,487,699,489,692,487,689,485,677,489,676,491,671,495,669,500,669,503,665,506,666,509,658,503,657,501,654,495,652,497,642,501,638,503,641,505,640,503,633,501,632,495,634,493,628,486,629,483,633,479,630,478,632,479,633,479,636,478,640,473,640,466,647,463,642,460,644,461,651,466,654,465,659,460,663,456,663,458,669,455,668,456,675,455,678,458,677,457,682,459,684,455,689,460,692,460,698" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=185><polygon id="Tirupathur" points="433,647,424,652,422,648,417,649,416,646,410,648,407,644,412,642,413,641,414,635,416,634,414,631,407,630,405,628,404,624,401,622,405,615,401,609,408,607,407,605,401,605,401,597,404,595,404,591,412,588,411,584,412,580,422,585,422,588,420,590,424,597,424,606,414,606,412,610,417,610,418,612,416,618,422,621,422,615,426,609,435,607,435,604,447,607,447,613,451,618,449,621,453,629,457,624,461,627,468,624,468,618,476,619,477,626,480,631,478,632,479,634,478,640,472,640,466,648,463,642,460,645,457,645,452,649,453,653,441,651,441,647,437,649" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=186><polygon id="Sivaganga" points="416,693,418,702,426,702,420,709,424,715,434,709,437,704,441,707,443,703,449,709,451,712,455,708,457,706,463,706,462,703,462,698,461,699,460,698,460,692,455,689,459,684,457,682,458,677,455,678,457,674,455,668,458,669,456,664,460,663,464,660,466,654,461,651,460,645,457,645,452,649,453,653,441,651,441,647,436,650,433,647,424,652,422,648,417,649,416,646,410,648,412,649,413,653,411,659,401,661,397,660,395,665,393,664,387,668,387,675,385,677,379,676,376,675,378,678,381,680,383,684,387,683,388,680,392,680,395,687,393,690,395,691,398,694,401,696,407,696,410,696,414,692" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=187><polygon id="Manamadurai" points="383,694,381,703,386,704,390,706,390,713,399,715,398,720,403,720,403,726,407,721,415,722,417,722,420,727,431,730,440,738,445,739,445,735,449,732,451,725,460,727,460,730,472,728,474,723,470,721,468,715,472,708,466,704,463,706,457,706,451,712,443,703,441,707,437,704,434,709,424,715,420,709,426,702,418,702,416,693,414,692,410,696,406,696,398,694,395,691,393,690,395,687,395,687,392,680,388,680,387,683,383,684,381,680,379,678,378,678,376,680,375,680,374,678,369,676,367,674,365,676,358,674,358,677,353,678,355,685,360,682,363,683,365,685,362,690,360,691,360,687,356,685,356,687,358,692,361,696,365,694,367,694,367,691,374,696,377,694,378,696" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=188><polygon id="Melur" points="377,637,381,630,383,630,383,624,377,624,383,618,386,618,390,613,390,604,392,600,397,601,399,598,401,598,401,605,407,605,408,607,401,609,405,615,401,622,404,624,405,628,407,630,414,631,416,634,414,635,413,641,407,644,410,648,412,649,413,653,411,659,401,661,397,660,395,664,393,664,387,668,387,675,385,677,379,676,379,670,383,667,384,661,379,664,379,660,379,658,375,656,372,651,377,650,379,646,374,643,369,641,369,639" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=189><polygon id="Madurai East" points="354,647,355,646,355,642,363,635,369,639,369,641,379,646,377,651,372,651,375,656,379,657,379,664,383,661,383,667,379,670,379,675,376,675,378,678,375,680,374,678,374,678,367,674,365,676,365,673,361,670,360,664,364,659,355,660,350,661,348,655,350,653,350,648" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=190><polygon id="Sholavandan" points="310,640,321,651,326,657,330,656,332,654,339,656,344,657,344,656,348,655,350,653,350,648,354,647,355,646,355,642,363,635,361,633,362,628,360,626,356,619,348,618,338,620,336,623,328,628,324,626,321,633,323,635,316,637,309,639" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=191><polygon id="Madurai North" points="350,662,352,665,355,666,358,665,360,664,364,660,356,660,350,661" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=192><polygon id="Madurai South" points="352,668,354,672,358,672,358,674,365,676,365,673,360,669,360,664,355,666,351,665" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=193><polygon id="Madurai Central" points="340,664,338,666,342,669,342,671,349,671,353,671,351,666" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=194><polygon id="Madurai West" points="333,663,337,666,340,664,351,666,350,661,346,655,344,657,333,654,328,657,332,657,333,661" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=195><polygon id="Thirupparankundram" points="338,678,331,671,331,665,333,663,338,666,342,669,342,671,353,671,354,672,358,672,358,673,358,674,358,677,354,678,355,684,356,684,360,680,364,684,365,685,361,691,360,691,360,687,356,685,356,689,355,693,349,690,348,692,344,692,341,687,338,687" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=196><polygon id="Thirumangalam" points="280,703,290,707,290,714,294,713,302,714,304,712,310,714,312,717,317,714,323,714,327,717,330,714,333,715,339,709,342,712,344,711,346,708,342,696,348,694,349,692,348,692,344,692,339,687,338,678,331,671,331,665,333,663,333,663,332,657,327,657,325,659,324,662,326,665,321,667,313,666,311,672,305,678,307,683,303,687,299,684,293,690,290,691,292,692,287,696,282,694,279,700,277,703" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=197><polygon id="Usilampatti" points="253,696,250,704,244,711,238,721,236,724,238,727,241,724,244,718,246,712,248,709,251,712,257,708,261,704,268,701,271,706,273,706,277,706,277,703,277,703,282,694,286,696,292,692,290,691,293,690,299,684,303,685,307,683,305,678,311,672,313,666,321,667,326,665,324,662,327,656,326,657,309,639,309,638,301,638,290,641,282,646,280,647,279,654,275,656,275,663,271,665,265,675,266,680,259,687" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=198><polygon id="Andipatti" points="217,699,212,694,207,696,197,694,195,693,190,696,188,703,183,712,183,716,190,715,196,722,202,723,209,718,211,718,212,722,214,723,217,717,216,725,219,727,219,731,222,733,226,731,229,728,236,728,238,727,236,724,243,712,250,704,253,694,259,687,266,680,265,675,271,665,275,663,275,656,279,654,280,647,282,645,280,634,279,635,269,642,257,639,250,645,245,649,245,667,242,671,233,669,219,676,218,680,219,691,219,696,218,699" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=199><polygon id="Periyakulam" points="253,614,245,620,239,625,244,627,244,631,239,638,238,634,232,632,230,637,235,643,242,648,245,649,251,643,259,639,268,642,269,642,280,634,280,631,275,627,277,623,282,627,284,627,286,621,282,618,280,613,273,615,267,611,263,613,261,615,257,615,255,613" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=200><polygon id="Bodinayakkanur" points="203,658,212,664,217,668,215,670,214,670,213,674,217,676,219,676,232,669,243,671,245,666,245,649,241,648,234,642,230,637,232,632,236,633,236,634,239,638,244,631,244,627,238,625,232,624,229,620,228,620,223,622,220,622,215,624,211,623,206,626,204,625,198,624,193,627,193,631,203,641,203,646,204,651,204,654,200,656" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=201><polygon id="Cumbum" points="197,671,197,674,195,674,196,678,199,680,197,683,194,685,196,689,195,693,207,696,212,694,217,699,219,696,219,690,218,683,219,677,213,674,214,670,217,668,200,656,197,656,199,657,194,665,194,670" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=202><polygon id="Rajapalayam" points="220,754,227,754,231,759,231,763,234,764,234,767,236,766,245,766,246,759,248,761,250,756,253,756,251,751,257,749,259,745,261,745,259,741,251,739,246,736,239,735,235,735,224,735,222,742,221,745,217,744,213,749,216,752" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=203><polygon id="Srivilliputhur" points="282,734,277,743,270,753,257,749,257,749,259,745,261,745,259,741,251,739,245,735,224,735,223,732,229,728,236,728,240,725,241,724,244,718,246,712,248,709,251,712,257,708,261,704,268,700,271,706,276,706,277,706,277,703,280,703,290,707,290,715,291,719,290,723,284,721,282,724,284,728,280,728" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=204><polygon id="Sattur" points="276,775,269,776,255,771,255,765,251,763,248,761,250,756,253,756,251,751,259,749,271,753,276,745,278,745,277,752,278,760,282,754,290,756,291,752,296,754,296,751,298,749,304,749,309,752,313,756,314,761,316,756,321,760,324,769,321,772,312,776,303,780,301,778,302,785,296,784,292,779,289,778,291,783,289,786,284,780,280,778" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=205><polygon id="Sivakasi" points="292,733,298,737,298,743,302,742,304,745,303,749,298,749,296,751,296,754,291,752,289,756,280,754,278,760,277,752,278,745,276,745,282,734,282,733,288,733" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=206><polygon id="Virudhunagar" points="319,731,323,738,323,742,316,747,309,752,303,749,304,744,302,742,298,743,298,737,292,733,282,733,280,728,284,728,284,728,282,723,282,724,284,721,290,723,291,719,290,714,294,713,302,714,304,712,310,714,312,716,312,717,317,714,323,714,326,716,327,717,330,714,333,715,328,720,328,723,327,725,323,730" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=207><polygon id="Aruppukkottai" points="335,770,337,774,331,774,330,779,326,781,326,784,321,784,319,788,316,790,315,792,306,791,307,785,302,785,301,778,303,780,321,772,324,768,321,760,316,756,314,761,313,756,308,752,323,742,323,737,319,731,323,730,328,723,328,720,333,715,330,722,332,723,331,729,341,730,342,727,349,725,355,727,355,738,353,745,351,747,353,753,358,753,358,760,358,764,339,764" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=208><polygon id="Tiruchuli" points="373,763,381,761,384,768,381,773,387,770,388,768,393,767,393,774,387,781,377,779,367,777,365,771,360,770,358,767,358,764,358,753,353,753,351,747,354,742,355,739,355,727,349,725,342,727,341,730,331,729,332,723,330,722,333,715,339,709,342,712,344,711,346,708,342,696,348,694,349,692,348,692,349,690,355,693,356,689,361,696,365,694,367,694,367,691,374,696,377,694,378,696,383,694,381,703,386,704,390,706,390,713,399,715,398,720,401,720,403,720,403,725,399,726,394,729,397,737,397,739,387,738,388,745,385,747,383,747,383,752,367,749,367,756,372,758" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=209><polygon id="Paramakudi" points="420,742,410,744,409,754,404,756,394,749,390,754,383,752,383,747,388,745,387,738,397,739,397,737,394,729,403,725,403,726,407,721,417,721,418,722,417,722,420,727,431,730,440,738,445,739,445,735,449,732,451,725,460,727,460,730,473,728,473,730,477,733,480,739,474,745,479,747,477,753,472,754,465,759,463,765,449,771,443,762,443,756,439,749,434,747,430,752,427,749,424,749,424,745" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=210><polygon id="Tiruvadanai" points="478,767,478,763,470,765,470,768,466,773,456,773,454,769,463,765,465,759,476,753,477,753,479,747,474,745,480,739,477,733,472,728,474,722,470,721,468,714,472,708,466,704,462,706,462,703,462,698,464,696,468,694,468,689,470,693,478,694,473,701,476,704,482,699,487,699,489,692,486,689,487,689,485,677,489,676,491,671,495,669,500,669,503,665,506,666,513,676,515,680,528,682,522,687,519,690,517,696,513,696,503,711,501,717,496,723,495,725,491,736,489,745,488,745,489,752,500,767,503,770,498,772,487,767,485,768,484,775,478,775,474,771" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=211><polygon id="Ramanathapuram" points="451,787,445,781,449,771,454,769,456,773,466,773,470,768,470,764,478,763,478,767,474,771,478,775,484,775,485,768,487,767,498,772,503,770,513,778,515,780,528,781,531,782,542,783,544,782,550,782,559,776,564,776,564,780,560,785,581,805,581,806,563,793,550,788,546,788,540,792,538,794,535,790,543,787,540,784,530,785,513,786,495,785,489,788,479,787,458,794,457,791,455,791,455,787,451,788" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=212><polygon id="Mudhukulathur" points="379,794,375,793,378,779,387,781,393,774,393,767,388,768,387,770,381,773,384,768,381,761,374,763,371,758,367,756,367,749,383,752,390,756,394,749,404,756,409,754,410,744,415,743,420,742,424,745,424,749,428,749,430,753,434,747,440,749,443,756,443,763,449,771,445,781,452,788,455,787,455,791,457,791,458,795,454,799,447,795,441,800,441,804,430,807,416,807,399,809,395,813,390,812,390,809,377,804,379,797" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=213><polygon id="Vilathikulam" points="315,811,319,813,321,819,321,824,315,825,314,829,310,831,311,833,301,833,301,835,312,835,313,840,317,837,324,839,328,842,332,836,340,837,342,841,358,844,360,844,363,838,369,832,383,823,395,814,395,812,390,812,389,809,377,804,379,797,379,794,375,793,374,793,375,793,378,779,367,777,369,776,367,777,365,771,360,770,358,766,358,764,340,764,339,764,335,770,337,774,331,774,330,779,326,781,326,784,321,784,319,787,316,790,315,792,314,794,319,795,319,797,316,798,313,796,313,799,314,804,314,809" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=214><polygon id="Thoothukkudi" points="342,881,344,883,352,880,356,878,361,874,360,871,356,871,355,859,352,860,348,862,342,859,339,863,342,866,344,869,349,873,346,874,346,878,342,876,342,881" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=215><polygon id="Tiruchendur" points="317,922,325,940,325,943,336,940,335,935,339,928,350,918,348,908,351,902,350,896,350,889,341,893,338,897,324,897,319,904,317,909,319,914,319,918" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=216><polygon id="Srivaikuntam" points="292,911,293,908,290,903,286,900,288,896,291,896,294,892,291,889,293,887,308,888,307,881,316,884,316,885,319,884,321,885,319,888,325,889,324,884,325,881,328,884,330,887,333,883,336,880,342,881,344,883,354,878,353,884,350,885,350,889,340,894,338,897,324,897,317,909,319,915,319,921,317,922,324,940,325,938,325,942,321,945,316,945,304,948,304,943,299,943,296,938,299,936,296,931,294,927,296,920,294,917,294,914" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=217><polygon id="Ottapidaram" points="294,854,300,863,294,868,294,874,293,883,293,887,308,888,307,881,316,884,316,887,319,884,321,885,319,888,326,889,324,884,325,881,328,884,330,887,336,880,341,881,342,876,346,878,346,876,349,872,344,869,342,866,338,863,342,859,348,862,356,859,356,853,358,849,360,844,342,841,339,837,332,836,328,842,323,839,317,837,313,840,312,835,301,835,300,833,298,833,296,835,298,837,296,841,290,843,288,846,289,848,292,848" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=218><polygon id="Kovilpatti" points="280,807,282,813,275,814,276,819,273,823,273,825,279,827,278,832,271,831,271,834,271,838,271,840,280,840,284,840,284,848,289,848,288,846,290,843,294,841,298,837,296,835,299,833,303,833,311,833,310,831,314,829,315,825,321,824,319,812,314,809,314,803,313,796,316,798,319,797,319,795,314,794,314,791,314,793,306,791,307,785,302,785,303,791,303,792,299,798,293,796,290,799,284,798,280,793,277,793,276,797,273,798,273,803,270,803,271,807,271,809,275,807" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=219><polygon id="Sankarankovil" points="251,789,251,786,259,784,259,780,253,779,251,775,248,774,250,772,255,771,269,776,276,775,280,778,284,780,289,786,291,782,289,778,292,779,296,784,302,785,303,792,299,798,293,796,290,799,284,798,279,793,277,793,276,797,273,798,273,803,270,803,271,809,275,807,280,807,282,813,275,814,276,819,273,823,273,825,279,827,278,832,271,831,271,840,270,841,266,838,266,835,259,837,257,833,253,832,255,828,257,824,261,824,261,821,255,820,253,816,250,814,246,811,243,812,244,816,236,819,233,822,224,821,224,816,221,814,221,809,226,809,229,812,233,807,235,806,236,800,243,796,243,792,245,789" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=220><polygon id="Vasudevanallur" points="207,793,198,789,200,784,203,770,206,770,206,765,210,765,213,754,213,749,213,749,220,754,228,754,231,759,231,763,234,764,234,767,238,766,245,766,246,759,250,762,251,764,255,765,255,771,250,772,248,774,251,775,253,779,259,780,259,784,251,786,251,789,245,789,243,792,243,796,236,800,235,806,229,812,227,809,221,809,220,809,220,806,227,803,228,801,227,798,220,797,215,794,209,791" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=221><polygon id="Kadayanallur" points="196,825,198,824,207,827,219,829,224,820,224,816,221,813,221,809,220,809,220,806,227,803,227,801,228,801,227,798,220,797,209,791,207,794,207,793,198,789,196,790,198,791,198,798,189,806,186,816,180,816,179,819,176,820,180,825,182,825,181,829,183,830,184,834,184,837,189,840,189,834,196,832,203,830" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=222><polygon id="Tenkasi" points="220,848,221,846,219,844,219,838,222,837,235,840,238,842,241,839,243,838,245,836,253,837,255,837,255,840,259,837,257,834,253,832,257,824,261,824,259,821,255,820,253,816,248,813,245,811,243,812,243,816,235,819,233,822,223,821,219,829,206,827,198,824,196,825,203,830,189,834,189,840,190,841,194,845,206,847,216,849,220,850" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=223><polygon id="Alangulam" points="251,858,247,864,250,872,247,878,241,872,221,871,211,871,205,865,202,865,205,857,200,857,204,852,203,846,220,850,221,846,219,844,219,838,223,837,236,840,238,842,242,838,245,836,255,837,255,839,255,841,248,843,251,847,255,849,253,855" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=224><polygon id="Tirunelveli" points="264,882,251,881,247,878,250,872,247,864,253,855,255,849,250,846,250,843,253,841,255,840,259,837,266,835,266,839,270,840,273,840,284,840,284,848,292,848,294,855,294,857,292,857,292,861,292,864,289,866,284,867,278,872,275,876,269,876,266,880,263,883" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=225><polygon id="Ambasamudram" points="211,907,197,901,190,892,186,885,183,882,184,880,179,870,183,869,184,865,187,865,189,861,192,858,195,853,196,849,194,845,203,847,205,851,200,857,205,857,202,865,206,865,212,872,241,872,248,878,251,881,263,882,266,885,264,890,259,890,255,898,255,902,245,897,231,900,226,898,220,905,216,905" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=226><polygon id="Palayamkottai" points="276,885,284,885,287,882,290,878,289,874,286,873,284,873,280,869,276,874,275,876,269,876,269,880,273,885,275,885" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=227><polygon id="Nanguneri" points="242,935,248,931,255,929,261,936,264,935,265,932,261,926,267,928,271,926,276,934,280,933,282,938,284,940,294,938,296,938,299,936,294,927,296,920,294,917,294,914,292,911,293,908,290,903,284,900,288,896,290,896,294,892,291,889,293,887,293,882,294,874,294,868,300,863,294,855,294,857,293,857,292,857,292,864,288,867,284,867,280,870,284,873,288,874,289,874,290,878,284,885,275,885,269,880,269,876,263,883,266,885,264,890,257,890,255,898,255,901,245,897,231,900,226,898,220,906,216,905,212,907,212,910,222,912,226,914,226,919,231,921,230,925,230,928,231,933,236,936,240,934" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=228><polygon id="Radhapuram" points="241,975,248,978,248,979,257,977,269,977,277,977,280,980,288,976,289,969,294,964,296,960,303,959,311,954,321,945,304,948,304,943,299,943,296,938,294,940,284,940,280,933,276,934,271,926,266,928,261,926,265,932,263,935,261,936,255,929,242,935,242,938,240,945,245,954,247,961,243,961,242,968,242,974" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=229><polygon id="Kanniyakumari" points="228,967,227,974,219,981,218,984,226,987,241,991,244,991,245,987,245,983,248,979,241,975,243,961,247,961,244,954,240,945,242,935,240,934,236,936,231,933,230,924,231,921,226,919,224,925,222,928,219,928,218,934,215,941,215,953,215,960,216,964,222,963,224,966,224,969" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=230><polygon id="Nagercoil" points="214,970,207,974,207,977,203,978,206,980,219,985,219,980,227,974,228,967,224,969,224,966,221,963,216,964,215,963,215,965,216,968,216,971" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=231><polygon id="Kollachal" points="189,965,197,964,205,961,208,961,208,963,215,958,216,963,215,964,216,968,215,970,214,970,207,974,207,977,204,977,204,980,202,980,197,977,194,973,186,971,184,968" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=232><polygon id="Padmanabhapuram" points="197,928,192,934,192,940,190,947,197,954,197,960,193,961,193,964,198,964,205,960,208,961,208,963,215,958,215,948,215,941,218,933,219,928,223,928,226,919,226,913,221,912,212,910,212,907,207,906,203,907,200,913,203,921,202,924" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=233><polygon id="Vilavancode" points="179,947,178,953,182,952,189,954,189,954,189,960,193,962,197,960,197,954,190,947,192,933,198,927,202,924,204,921,199,913,203,907,209,906,208,906,196,901,197,904,193,912,189,913,184,910,183,913,187,921,187,923,183,923,180,929,179,932,174,933,175,938,178,938,177,942,177,945" /></a>
  <a xmlns:xlink="http://www.w3.org/1999/xlink" acct_no=234><polygon id="Killiyoor" points="166,950,165,951,171,956,179,964,186,969,189,966,194,964,193,961,188,960,189,960,189,954,182,952,178,954,178,947,176,943,176,943,171,943,166,945,163,947,163,950,165,951,165,950,165,951,165,951,165,950,165,950" /></a>
           </g>
           </svg>
           </div>
           </div>
        </div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>
    
    <div id="individual">
    <div class="container-fluid">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Assembly Elections View By Individual Elections for <i class="year_tag"></i></h2>
   </div>
           </div>
           
           <div class="row">
   <div class=" col-md-12 panel-body">
            
         <div class="dropdown header_year">
           <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Year</button>
  <ul class="dropdown-menu" role="menu">
          
          <li data-year="2016" id="2016"><a href="?year=2016#individual">2016 results</a></li>
          <li data-year="2011" id="2011"><a href="?year=2011#individual">2011 results</a></li>
          <li data-year="2006" id="2006"><a href="?year=2006#individual">2006 results</a></li>
          <li data-year="2001" id="2001"><a href="?year=2001#individual">2001 results</a></li>
          <li data-year="1996" id="1996"><a href="?year=1996#individual">1996 results</a></li>
          <li data-year="1991" id="1991"><a href="?year=1991#individual">1991 results</a></li>
          <li data-year="1989" id="1989"><a href="?year=1989#individual">1989 results</a></li>
          <li data-year="1984" id="1984"><a href="?year=1984#individual">1984 results</a></li>
          <li data-year="1980" id="1980"><a href="?year=1980#individual">1980 results</a></li>
          <li data-year="1977" id="1977"><a href="?year=1977#individual">1977 results</a></li>
          <li data-year="1971" id="1971"><a href="?year=1971#individual">1971 results</a></li>
          <li data-year="1967" id="1967"><a href="?year=1967#individual">1967 results</a></li>
          
    </ul>
         </div>
<p class="form-inline header_form" >
           <label align="left" >Search:</label>
           <input type="text" class="search" placeholder="eg: chennai">
          </p>
          
        <div class="chart">
        
            <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
<g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight"  x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
</g>
    
  </svg>
           <div class="tree_map"></div>
           </div>
        </div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>
    
    <div id="perConstituency">
    
    <div class="container-fluid detail_display">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2 class="headers_constituency">Assembly Elections year <i class="year_tag"></i>for Constituency<i class="constituency_tag"></i></h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">
        <div class="chart">
           <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>

           <div class="col-md-4 panel-body">
           <div class="progress_bar"></div>
           </div>
<div class="col-md-8 panel-body">
           <div class="horizontal_bar"></div>
           </div>
           </div>
        </div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>
    
        <div id="party_Trend">
        <div class="container-fluid">
        <div class="container">
          
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>party wise performance trend <i class="year_tag"></i></h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">

<div class="dropdown header_year">
           <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Year</button>
  <ul class="dropdown-menu" role="menu">
          
          <li data-year="2016" id="2016_flow"><a href="?year=2016#party_Trend">2016 results</a></li>
          <li data-year="2011" id="2011_flow"><a href="?year=2011#party_Trend">2011 results</a></li>
          <li data-year="2006" id="2006_flow"><a href="?year=2006#party_Trend">2006 results</a></li>
          <li data-year="2001" id="2001_flow"><a href="?year=2001#party_Trend">2001 results</a></li>
          <li data-year="1996" id="1996_flow"><a href="?year=1996#party_Trend">1996 results</a></li>
          <li data-year="1991" id="1991_flow"><a href="?year=1991#party_Trend">1991 results</a></li>
          <li data-year="1989" id="1989_flow"><a href="?year=1989#party_Trend">1989 results</a></li>
          <li data-year="1984" id="1984_flow"><a href="?year=1984#party_Trend">1984 results</a></li>
          <li data-year="1980" id="1980_flow"><a href="?year=1980#party_Trend">1980 results</a></li>
          <li data-year="1977" id="1977_flow"><a href="?year=1977#party_Trend">1977 results</a></li>
          <li data-year="1971" id="1971_flow"><a href="?year=1971#party_Trend">1971 results</a></li>
          <li data-year="1967" id="1967_flow"><a href="?year=1967#party_Trend">1967 results</a></li>
          
    </ul>
         </div>
         
           <svg data-height="0.54" viewBox="0 0 1200 40" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,15)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>
       
<div class="party_performance_trend_svg">
            </div>

   </div>
          </div>
            
            </div>
            </div>
            
    
    </div>
    </div>
    </div>
    

    <div id="sankeyFlow">
    <div class="container-fluid">
    <div class="container">
          
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Party Transitions Trend across successive elections<i class="successive_year_tag"></i></h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">
       <div class="dropdown header_year">
           <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Year</button>
           <ul class="dropdown-menu" role="menu">
           
           <li data-year="2011_2016" id="2011_2016"><a href="?flowyear=2011_2016#sankeyFlow">2016 results</a></li>
           <li data-year="2001_2006" id="2001_2006"><a href="?flowyear=2001_2006#sankeyFlow">2006 results</a></li>
           <li data-year="1996_2001" id="1996_2001"><a href="?flowyear=1996_2001#sankeyFlow">2001 results</a></li>
           <li data-year="1991_1996" id="1991_1996"><a href="?flowyear=1991_1996#sankeyFlow">1996 results</a></li>
           <li data-year="1989_1991" id="1989_1991"><a href="?flowyear=1989_1991#sankeyFlow">1991 results</a></li>
           <li data-year="1984_1989" id="1984_1989"><a href="?flowyear=1984_1989#sankeyFlow">1989 results</a></li>
           <li data-year="1980_1984" id="1980_1984"><a href="?flowyear=1980_1984#sankeyFlow">1984 results</a></li>
           <li data-year="1977_1980" id="1977_1980"><a href="?flowyear=1977_1980#sankeyFlow">1980 results</a></li>
           <li data-year="1967_1971" id="1967_1971"><a href="?flowyear=1967_1971#sankeyFlow">1971 results</a></li>
  
           </ul>
       </div>
       
       <div  class="sankey_chart">
            <svg data-height="0.54" viewBox="0 0 1200 40" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,15)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>
       </div>
   </div>
          </div>
            
            </div>
            </div>
            
    
    </div>
    </div>
    </div>

    <div class="container-fluid">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Assembly Elections 1967 - 2016 (Tamil Nadu)</h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">
        <div class="stacked_bar">
          <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>
         </div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>

    <div class="container-fluid">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Assembly Elections 1967 - 2016 (Vote Comparison)</h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">
        <div class="multi_sparkline">
        
         <div class="nytg-navBar" align="right">
           <ul align="center" class="nytg-navigation clearfix" style="list-style-type:none">
  <li id="count_votes" class="selected" selected>votes count</li>
  <li id="percent_votes">votes percent </li>
           </ul>
         </div>
         
          <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>
</div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>

    <div id="Constituency_partyTrend">
        <div class="container-fluid">
    <div class="container">
          
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2>Constituency wise party trend 1967 - 2016 (Tamil Nadu)</h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">

           <svg data-height="0.54" viewBox="0 0 1200 40" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
  <g class="headers" transform="translate(80,15)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </g>
           </svg>
           <div class="party_trend"></div>
   </div>
          </div>
            
            </div>
            </div>
            
    
    </div>
    </div>
    </div>
    
    <div id="detailConstituency">
    
    <div class="container-fluid detail_percent_display">
    <div class="container">
            <div class="row">
            <div class="col-md-12 panel panel-default">
            <div class="row">
   <div class="col-md-12 panel-heading1">
       <h2 class="details_constituency">Assembly Elections 1967 - 2016 for Constituency<i class="constituency_tag_percent"></i></h2>
   </div>
           </div>
           <div class="row">
   <div class=" col-md-12 panel-body">
        <div class="chart">
            <svg data-height="0.54" viewBox="0 0 1200 25" style="width: 100%;" xmlns="http://www.w3.org/2000/svg" xlink:xlink="http://www.w3.org/1999/xlink" version="1.1">
<g class="headers" transform="translate(80,0)">
    <rect class="party-legend" data-party="DMK" data-highlight="[data-party=DMK]" data-toggle="highlight" x="0.0" width="67.1428571429" height="20" fill="#c0392b"></rect>
    <text x="33.5714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">DMK</text>
    <rect class="party-legend" data-party="ADMK" data-highlight="[data-party=ADMK]" data-toggle="highlight" x="67.1428571429" width="67.1428571429" height="20" fill="#b2d33c"></rect>
    <text x="100.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">ADMK</text>
    <rect class="party-legend" data-party="INC" data-highlight="[data-party=INC]" data-toggle="highlight" x="134.285714286" width="67.1428571429" height="20" fill="#3498DB"></rect>
    <text x="167.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">INC</text>
    <rect class="party-legend" data-party="CPM" data-highlight="[data-party=CPM]" data-toggle="highlight" x="201.428571429" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="235.0" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPM</text>
    <rect class="party-legend" data-party="TMC" data-highlight="[data-party=TMC]" data-toggle="highlight" x="268.571428571" width="67.1428571429" height="20" fill="#4747ff"></rect>
    <text x="302.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">TMC</text>
    <rect class="party-legend" data-party="OTH" data-highlight="[data-party=OTH]" data-toggle="highlight" x="335.714285714" width="67.1428571429" height="20" fill="#222"></rect>
    <text x="369.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">Others</text>
    <rect class="party-legend" data-party="CPI" data-highlight="[data-party=CPI]" data-toggle="highlight" x="402.857142857" width="67.1428571429" height="20" fill="#ff5757"></rect>
    <text x="436.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">CPI</text>
    <rect class="party-legend" data-party="PMK" data-highlight="[data-party=PMK]" data-toggle="highlight" x="470.0" width="67.1428571429" height="20" fill="#d35400"></rect>
    <text x="503.571428571" y="10.0" text-anchor="middle" dy=".35em" fill="#fff">PMK</text>
    <rect class="party-legend" data-party="DMDK" data-highlight="[data-party=DMDK]" data-toggle="highlight" x="537.142857143" width="67.1428571429" height="20" fill="#f1c40f"></rect>
    <text x="570.714285714" y="10.0" text-anchor="middle" dy=".35em" fill="#000">DMDK</text>
    <rect class="party-legend" data-party="NCO" data-highlight="[data-party=NCO]" data-toggle="highlight" x="604.285714286" width="67.1428571429" height="20" fill="#1f77b4"></rect>
    <text x="637.857142857" y="10.0" text-anchor="middle" dy=".35em" fill="#000">NCO</text>
    <rect class="party-legend" data-party="JNP" data-highlight="[data-party=JNP]" data-toggle="highlight" x="671.428571429" width="67.1428571429" height="20" fill="#9A9E56"></rect>
    <text x="705.0" y="10.0" text-anchor="middle" dy=".35em" fill="#000">JNP</text>
    <rect class="party-legend" data-party="MDMK" data-highlight="[data-party=MDMK]" data-toggle="highlight" x="738.571428571" width="67.1428571429" height="20" fill="#9b59b6"></rect>
    <text x="772.142857143" y="10.0" text-anchor="middle" dy=".35em" fill="#000">MDMK</text>
    <rect class="party-legend" data-party="IND" data-highlight="[data-party=IND]" data-toggle="highlight" x="805.714285714" width="67.1428571429" height="20" fill="#bdc3c7"></rect>
    <text x="839.285714286" y="10.0" text-anchor="middle" dy=".35em" fill="#000">IND</text>
    <rect class="party-legend" data-party="BJP" data-highlight="[data-party=BJP]" data-toggle="highlight" x="872.857142857" width="67.1428571429" height="20" fill="#ff7f0e"></rect>
    <text x="906.428571429" y="10.0" text-anchor="middle" dy=".35em" fill="#000">BJP</text>
  </svg>
</g>
           <div class="col-md-12 panel-body">
  <div class="percent_stackedbar"></div>
           </div>
           </div>
        </div>
   </div>
            </div>
            </div>
            </div>
    </div>
    </div>
    
<a href="javascript:" id="return-to-top"><i class="icon-chevron-up"></i></a>
<script type="text/javascript">
    $(window).load(function() {
        $(".se-pre-con").fadeOut("slow");;
    });

    $(window).scroll(function() {
        if ($(this).scrollTop() >= 50) {        
            $('#return-to-top').fadeIn(200);    
        } else {
            $('#return-to-top').fadeOut(200);   
        }
    });

    $('#return-to-top').click(function() {     
        $('body,html').animate({
            scrollTop : 0
        }, 500);
    });

color_map = {"ADK(JL)":"#363636","ADK(JR)":"#363636","ADMK":"#b2d33c","AIFB":"#FFAD01","AINRC":"#B78332","AITC":"#4A9F88","AKD":"#363636","BAC":"#A99888","BBC":"#363636","BJP":"#ff7f0e","BJS":"#363636","BLD":"#363636","C(S)":"#363636","CMPKSC":"#363636","CON":"#ff7f0e","CON(S)":"#363636","CPI":"#F27A67","CPI(M)":"#363636","CPM":"#ff5757","CPM(K)":"#363636","DIC":"#363636","DMDK":"#f1c40f","DMK":"#c0392b","DSP(P)":"#363636","DSP(PC)":"#363636","FB":"#363636","FB(S)":"#363636","FBL":"#014BC6","FBL(MG)":"#363636","FBL(RG)":"#363636","FBM":"#363636","GKC":"#363636","GL":"#363636","GNLF":"#363636","GOJAM":"#363636","HMS":"#363636","IC(S)":"#363636","ICS":"#363636","ICS(SCS)":"#363636","IGL":"#363636","IML":"#363636","INC":"#3498DB","INC(U)":"#4A9F88","IND":"#bdc3c7","INL":"#363636","ISP":"#363636","IUML":"#014BC6","JD":"#363636","JD(S)":"#363636","JKP":"#363636","JKP(N)":"#363636","JNP":"#9A9E56","JP":"#363636","JPSS":"#363636","KC":"#363636","KCJ":"#363636","KCM":"#363636","KCP":"#363636","KCS":"#363636","KEC":"#FFAD01","KEC(B)":"#363636","KEC(J)":"#363636","KEC(M)":"#FFAD01","KMPP":"#363636","KRSP":"#363636","KSP":"#363636","LKD":"#363636","LSS":"#363636","MDMK":"#981D97","MFB":"#363636","ML":"#363636","MLO":"#363636","MNMK":"#363636","MUL":"#014BC6","NA":"#363636","NCO":"#1F77B4","NCP":"#363636","NDF":"#363636","NDP":"#363636","NSC":"#363637","Others":"#363636","PF":"#363636","PMC":"#363636","PMK":"#d35400","PML":"#363636","PSP":"#FFD380","PT":"#363636","RCI":"#363636","RCPI(RB)":"#363636","RJD":"#363636","RSP":"#F8F907","RSPK(B)":"#363636","SBP":"#363636","SJD":"#363636","SOP":"#363636","SP":"#363636","SSP":"#1F77B4","SUC":"#363636","SUCI":"#363636","SWA":"#363636","TMC":"#4747ff","TMC(M)":"#4747ff","TMK":"#363636","VCK":"#363636","WBSP":"#363636","WPI":"#363636"};

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

var countButton = d3.select(document.getElementById('count_votes'));
var percentButton = d3.select(document.getElementById('percent_votes'));

   
function toggleButton(button) {
    button['attr']('class', 'selected');
    if (button == countButton) {
        percentButton['attr']('class', 'unselected');
    } else {
        countButton['attr']('class', 'unselected');
    };
};

flowyear_detail = getParameterByName('flowyear');
year_detail = getParameterByName('year');
extra_year_detail = getParameterByName('extra_year');
extra_year_detail_sub = getParameterByName('extra_year');

acct_no = getParameterByName('acct_no');
cons_id = getParameterByName('cons_id');

if (acct_no == undefined){ $(".detail_display").hide(); }
else{ $(".detail_display").show();}

if (cons_id == undefined){ $(".detail_percent_display").hide(); }
else{ $(".detail_percent_display").show();}
        
if ((extra_year_detail == undefined) && (year_detail >= 2009)){ extra_year_detail= year_detail; }
if ((extra_year_detail == undefined) && (year_detail <= 2009)){ extra_year_detail= 2016; }

if (year_detail == undefined){ year_detail= extra_year_detail; }
if (flowyear_detail != undefined){ year_detail= flowyear_detail.split("_")[1] }
if (flowyear_detail == undefined){ flowyear_detail = '2011_2016'}

if ([1967,1971,1977,1980,1984,1989,1991,1996,2001,2006,2011,2016].indexOf(parseInt(year_detail))<0)
{ year_detail =2016,extra_year_detail=2016; }

if (year_detail <2009){ $('#individual_hold').hide() }

sankey_flow_year = ["2011_2016","2001_2006","1996_2001","1991_1996","1989_1991","1984_1989","1980_1984","1977_1980","1967_1971"];

sankey_flow_value = ''
sankey_flow_year.forEach(function(entry) {
    if (entry.indexOf('_'+year_detail)>0){
        sankey_flow_value = entry;
    };
});

if (sankey_flow_value!='')
{
    flowyear_detail = sankey_flow_value
}
else{
    $('#sankeyFlow').hide()
}

$('#'+year_detail+'').addClass('active');
$(".year_tag").append("("+year_detail+")");

$('#extra_'+extra_year_detail+'').addClass('active');
$(".extra_year_tag").append("("+extra_year_detail+")");

$('#'+year_detail+'_flow').addClass('active');
$('#'+flowyear_detail+'').addClass('active');
$(".successive_year_tag").append(" ("+flowyear_detail.replace('_', ' to ')+") ");

d3.json("{{asset('public/graph/overall_tn.json')}}", function(data) { 
    
var margin = {top: 20, right: 20, bottom: 35, left: 20},
    width = 1200 - margin.left - margin.right,
    height = 400 - margin.top - margin.bottom;

var x = d3.scale.ordinal()
    .rangeRoundBands([0, width], .2);

var y = d3.scale.linear()
    .range([height, 0]);

var xAxis = d3.svg.axis()
    .scale(x)
    .orient("bottom");

var yAxis = d3.svg.axis()
    .scale(y)
    .orient("left");

var svg = d3.select(".stacked_bar").append("svg")
            .style("width", "100%")
            .attr("data-height","0.54")
            .attr("viewBox","0 0 "+(width + margin.left + margin.right)+" "+(height + margin.top + margin.bottom))
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

var party_names = ['DMK','ADMK','INC','CPM','TMC','CPI','PMK','DMDK','NCO','JNP','MDMK','IND','BJP','Others'];
  
 data.forEach(function(d) {
        var y0 = 0;
        d.party = party_names.map(function(name) { return {name: name, y0: y0, y1: y0 += +d[name],value: +d[name],YEAR:d['YEAR']}; });
        d.party.forEach(function(d) { d.y0 /= y0; d.y1 /= y0; d.y0= d.y0*100,d.y1=d.y1*100 });
        d.total = d.party[d.party.length - 1].y1;
  });
    
  x.domain(data.map(function(d) { return d['YEAR']; }));
  y.domain([0, d3.max(data, function(d) { return d.total; })]);

  svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis);

  var party = svg.selectAll(".party")
      .data(data)
      .enter().append("g")
      .attr("class", "party")
      .attr("transform", function(d) { return "translate(" + x(d['YEAR']) + ",0)"; });

  party.selectAll("rect")
      .data(function(d) { return d.party; })
      .enter().append("rect")
      .attr('class',function (d) { return 'party_filters '+d.name+'s' })
      .attr("width", x.rangeBand())
      .attr("y", function(d) { return y(d.y1); })
      .attr("height", function(d) { return y(d.y0) - y(d.y1); })
      .style("fill", function(d) { return color_map[d.name] })
      .style("stroke", function(d) { return d3.rgb(color_map[d.name]).darker(); })
      .attr("data-title", function(d) { return d['YEAR']+', '+d.name+' : '+d.value+' seats'; })
      .on("mouseover", function() { d3.select(this).attr("stroke-width", 5);})
      .on("mouseout", function() { d3.select(this).attr("stroke-width", 1);});
      
  party.selectAll(".value")
    .data(function(d) { return d.party; })
    .enter().append("text")
    .attr('class',function (d) { return 'value party_filters '+d.name+'s' })
    .attr("y", function(d) { return ((y(d.y1)+y(d.y0))/2)-1; })
    .attr("x", x.rangeBand()/2)
    .attr("text-anchor", "middle")
    .style("font-size", "15px")
    .attr("data-title", function(d) { return d['YEAR']+', '+d.name+' : '+d.value+' seats'; })
    .style("fill", function(d) { return (parseInt(color_map[d.name].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
    .text(function(d) { return (y(d.y0) - y(d.y1))>29 ?d.value:' '; });

  party.selectAll(".name")
    .data(function(d) { return d.party; })
    .enter().append("text")
    .attr('class',function (d) { return 'name party_filters '+d.name+'s' })
    .attr("y", function(d) { return ((y(d.y1)+y(d.y0))/2)+12; })
    .attr("x", x.rangeBand()/2)
    .attr("text-anchor", "middle")
    .style("font-size", "12px")
    .attr("data-title", function(d) { return d['YEAR']+', '+d.name+' : '+d.value+' seats'; })
    .style("fill", function(d) { return (parseInt(color_map[d.name].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
    .text(function(d) { return (y(d.y0) - y(d.y1))>29 ?d.name:' '; });

      $("rect").tooltip({container: '.stacked_bar', html: true, placement:'top'});
      $("text").tooltip({container: '.stacked_bar', html: true, placement:'top'});
    
      year_data_set = data.filter(function(d){return (d.YEAR==year_detail) })
      year_data_sets = year_data_set[0].party.filter(function(d){return (d.value>0) })      
      year_data_sets.sort(function(a, b) { return b.value - a.value; })
      
      heading_colors = []
      year_data_sets.forEach(function(o) {
        heading_colors.push(color_map[o.name])
      })

      max_seats = d3.max(year_data_sets, function(d) { return d.value; });
      
      lowresult_data  = d3.select('.overall_view_report')
  .selectAll('div')
 .data([year_data_sets])
 .enter()
 .append("div")
 .append("table")
 .attr("class","table table-condensed party-summary")
    
     lowresult_data.append('thead')
      .selectAll("tr")
      .data([['Party','Seats','Seat Share']]).enter()
      .append("tr")
      .selectAll("th")
          .data(function(d,l) { return d }).enter()
          .append('th')
          .style("max-width",'10px')
          .style("font-size",'15px')
          .append("font")
          .attr("color","#636363")
          .text(function(o,i) { return o });

           lowresult_data.append('tbody')
      .selectAll("tr")
      .data(function(o) { return o }).enter()
      .append("tr")
      .selectAll("td")
          .data(function(d,l) { return [d.name,d.value,l+':'+(d.value*100/max_seats).toFixed(2)] }).enter()
          .append('td')
          .attr('class',function(d) { return d+'s'})
          .style("max-width",'10px')
          .style("font-size",'15px')
          .text(function(o,i) { return i<2? o:'' })
          .append('div')
          .attr('class',function(d,i) { return i<2? '':'progress'; })
          .append('div')
          .attr('class','progress-bar progress-bar-striped')
          .attr('role','progressbar')
          .attr('aria-valuenow','70')
          .attr('aria-valuemin','0')
          .attr('aria-valuemax','100')
          .style('background-color',function(d,i) { return i<2? '':heading_colors[parseInt(d.split(':')[0])]; })
          .style('width',function(d,i) { return i<2? '0%':d.split(':')[1]+'%'; });
         
            d3.selectAll('.removed_data').remove();
  });
  

function addThousandsSeparator(t){var a=t;if(parseFloat(t)){t=new String(t);var e=t.split(".");e[0]=e[0].split("").reverse().join("").replace(/(\d{3})(?!$)/g,"$1,").split("").reverse().join(""),a=e.join(".")}return a}
    
d3.csv("{{asset('public/graph/assembly_tn_detail.csv')}}", function(data_csv) {
 
var stay_data_csv = data_csv;

function data_scatter(type_votes){
    
  var data_value_total = d3.nest()
  .key(function(d) { return parseInt(d.YEAR); })
  .rollup(function(d) { 
   return d3.sum(d, function(g) {return g.polled_votes; });
  }).entries(stay_data_csv.filter(function(d){return (d.rank==1) }));

  
   mapper_party = ['DMK','ADMK','INC','CPM','TMC','CPI','PMK','DMDK','NCO','JNP','MDMK','BJP','IND'];

   data_mapper_data = stay_data_csv.filter(function(d) { return mapper_party.indexOf(d.PARTY) >-1 })
  
  var data_value = d3.nest()
  .key(function(d) { return parseInt(d.YEAR); })
  .key(function(d) { return d.PARTY;})
  .rollup(function(d) { 
   return d3.sum(d, function(g) {return g.VOTES; });
  }).entries(data_mapper_data);

    percent_mapper = {}
    data_value_total.forEach(function(d) {    
        percent_mapper[d.key]=d.values;
    });
    
    dataset_spark  = [];
    mapper_party.forEach(function(k) {
        year_sub_mapper=[]
        data_value.forEach(function(o) {
            o.values.forEach(function(l) {
   if(k==l.key){
       data_dict ={x:parseInt(o.key),party:k,votes_count:l.values,votes_percent:l.values*100/(percent_mapper[parseInt(o.key)]) }       
       data_dict['y'] = data_dict[type_votes]
       year_sub_mapper.push(data_dict)
   } 
   });
        });
    dataset_spark.push(year_sub_mapper)    
    });
    
    //Width and height
    var width_data = 1050;
    var height_data = 400;
    var padding = 50;
      
    // Define axis ranges & scales  
    var yExtents = d3.extent(d3.merge(dataset_spark), function (d) { return d.y; });
    var xExtents = d3.extent(d3.merge(dataset_spark), function (d) { return d.x; });
         
    var xScale = d3.scale.linear()
           .domain([xExtents[0], xExtents[1]])
           .range([padding, width_data - padding * .5]);

    var yScale = d3.scale.linear()
           .domain([0, yExtents[1]])
           .range([height_data - padding, padding]);

    // Create SVG element
    var multi_svg = d3.select(".multi_sparkline")
        .append("svg")
        .attr("class", "multi_sparkline_svg")
        .attr("width", "100%")
            .attr("data-height","0.54")
            .attr("viewBox","0 0 "+(width_data)+" "+(height_data))
            .attr("xmlns", 'http://www.w3.org/2000/svg')
            .attr("xlink", 'http://www.w3.org/1999/xlink')
            .attr("version", '1.1');

    // Define lines
    var line = d3.svg.line()
           .x(function(d) { return x(d.x); })
           .y(function(d) { return y(d.y1, d.y2, d.y3); });

    var pathContainers = multi_svg.selectAll('g.line')
    .data(dataset_spark);

    pathContainers.enter().append('g')
    .attr('class', 'line');

    pathContainers.selectAll('path')
    .data(function (d) { return [d]; })// continues the data from the pathContainer
    .enter().append('path')
      .attr('cla',function (d) { return d })
      .attr('class',function (d) { return 'party_filters '+d[0]['party']+'s' })
      .attr('stroke',function (d) { return color_map[d[0]['party']]; })
      .attr('d', d3.svg.line()
        .x(function (d) { return xScale(d.x); })
        .y(function (d) { return yScale(d.y); })
      );

    // what to do when we mouse over a bubble
    var mouseOn = function() { 
        var circle = d3.select(this);

    // transition to increase size/opacity of bubble
        circle.transition()
        .duration(800).style("opacity", 1)
        .attr("r", 12).ease("elastic");

        // append lines to bubbles that will be used to show the precise data points.
        // translate their location based on margins
        multi_svg.append("g")
            .attr("class", "guide")
        .append("line")
            .attr('stroke-width','1')
            .attr("x1", circle.attr("cx"))
            .attr("x2", circle.attr("cx"))
            .attr("y1", circle.attr("cy"))
            .attr("y2", height_data - padding)
            .style("stroke", circle.style("fill"))
            .transition().delay(200).duration(400).styleTween("opacity", 
           function() { return d3.interpolate(0, 1); })

        multi_svg.append("g")
            .attr("class", "guide")
        .append("line")
            .attr('stroke-width','1')
            .attr("x1", circle.attr("cx"))
            .attr("x2", padding)
            .attr("y1", circle.attr("cy"))
            .attr("y2", circle.attr("cy"))
            .style("stroke", circle.style("fill"))
            .transition().delay(200).duration(400).styleTween("opacity", 
           function() { return d3.interpolate(0, 1); });

    // function to move mouseover item to front of SVG stage, in case
    // another bubble overlaps it
        d3.selection.prototype.moveToFront = function() { 
          return this.each(function() { 
            this.parentNode.appendChild(this); 
          });
        };

    // skip this functionality for IE9, which doesn't like it
        if (!$.browser.msie) {
            circle.moveToFront();    
            }
    };
    // what happens when we leave a bubble?
    var mouseOff = function() {
        var circle = d3.select(this);

        // go back to original size and opacity
        circle.transition()
        .duration(800).style("opacity", 1)
        .attr("r", 4).ease("elastic");

        // fade out guide lines, then remove them
        d3.selectAll(".guide").transition().duration(100).styleTween("opacity", 
           function() { return d3.interpolate(1, 0); })
            .remove()
    }; 
    
    // add circles
    pathContainers.selectAll('circle')
    .data(function (d) { return d; })
    .enter().append('circle')
    .attr('class',function (d) { return 'party_filters '+d.party+'s' })
    .attr('stroke',function (d) { return d3.rgb(color_map[d.party]).darker(); })
    .attr('stroke-width','.5')
    .attr('fill',function (d) { return color_map[d.party]; })
    .attr('data-title',function (d) { return 'Party: '+d.party+'<br/>Year: '+d.x+'<br/>Votes: '+addThousandsSeparator(d.votes_count)+'<br/>Vote percent: '+d.votes_percent.toFixed(2)+'%' })
    .attr('cx', function (d) { return xScale(d.x); })
    .attr('cy', function (d) { return yScale(d.y); })
    .attr('r', 4) 
    .on("mouseover", mouseOn)
    .on("mouseout", mouseOff);
    
    //Define X axis
    var xAxis = d3.svg.axis()
            .scale(xScale)
            .orient("bottom")
            .tickFormat(d3.format("d"))
            .ticks(5);

    //Define Y axis
    var yAxis = d3.svg.axis()
            .scale(yScale)
            .orient("left")
            .tickPadding(12)
            .tickFormat( d3.format(".2s"))
            .ticks(6);

    //Add X axis
    multi_svg.append("g")
    .attr("class", "axis")
    .attr("vector-effect","non-scaling-stroke")
    .attr("transform", "translate(0," + (height_data - padding) + ")")
    .call(xAxis);

    //Add Y axis
    multi_svg.append("g")
    .attr("class", "axis")
    .attr("vector-effect","non-scaling-stroke")    
    .attr("transform", "translate(" + padding + ",0)")
    .call(yAxis);
    
    multi_svg.append("text")
        .attr("class", "x labels")
        .attr("text-anchor", "end")
        .attr("x", width_data - padding/2)
        .attr("y", height_data - padding/1.5)
        .style("font-size", "15px")
        .text("year*");

    multi_svg.append("text")
        .attr("class", "y labels")
        .attr("text-anchor", "end")
        .attr("x", -55)
        .attr("y", 58)
        .style("font-size", "15px")
        .attr("dy", ".75em")
        .attr("transform", "rotate(-90)")
        .text(type_votes.replace("_", " ")+'*');
        
      $("circle").tooltip({container: '.multi_sparkline', html: true, placement:'top'});
      
}

data_scatter('votes_count')

$('#count_votes').click( function(n) {
        d3.select('.multi_sparkline').select('.multi_sparkline_svg').remove();
        data_scatter('votes_count')
        countButton['attr']('class', 'selected');
        percentButton['attr']('class', null);
    });
    
    $('#percent_votes').click( function(n) {
        d3.select('.multi_sparkline').select('.multi_sparkline_svg').remove();
        data_scatter('votes_percent')
        percentButton['attr']('class', 'selected');
        countButton['attr']('class', null);
    });
    
var margin = {top: 20, right: 20, bottom: 35, left: 20},
    width = 1200 - margin.left - margin.right,
    height = 500 - margin.top - margin.bottom;
    
    var svg = d3.select(".tree_map").append("svg")
            .attr("width", "100%")
            .attr("data-height","0.54")
            .attr("viewBox","0 0 "+(width + margin.left + margin.right)+" "+(height + margin.top + margin.bottom))
            .attr("xmlns", 'http://www.w3.org/2000/svg')
            .attr("xlink", 'http://www.w3.org/1999/xlink')
            .attr("version", '1.1')
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
        
    var treemap = d3.layout.treemap()
        .padding(0.5)
        .size([width, height])
        .sticky(true)
        .value(function(d) {return d.polled_votes;})
        .children(function(d) {return d.values;});
        
        data_root = {"key":"treemap"};
        
         data_csv.forEach(function(o) {
          o.votes = parseInt(o.VOTES);
          o.rank = parseInt(o.rank);
          o.year = parseInt(o.YEAR);
          o.polled_votes = parseInt(o.polled_votes);
          });
         
         
        filter_data_csv = data_csv.filter(function(d){return (d.year==year_detail) & (d.rank==1) });
         
        constituency_list = []
        filter_data_csv.forEach(function (d) {
            d.constituency = d.AC_NAME
            constituency_list.push(d.constituency);
        });
       
        var nest = d3.nest()
        .key(function(d) { return  d.PARTY; })
        .entries(filter_data_csv);
        
    data_root["values"] = nest
    
  var cell = svg.data([data_root]).selectAll("g")
      .data(treemap.nodes)
    .enter().append("a")
      .attr("xlink:href",function(d) { return '?year='+d.year+'&acct_no='+d.AC_NO+"#perConstituency" })
      .append("rect")
      .attr('class',function (d) { return 'party_filters '+d.PARTY+'s' })
      .attr("x", function(d) { return d.x; })
      .attr("y", function(d) { return d.y; })
      .attr("width", function(d) { return d.dx; })
      .attr("height", function(d) { return d.dy; })
      .attr("data-title",function(d) { return 'Constituency : '+d.constituency+' <br/>Candidate : '+d.NAME+' <br/>party : '+d.PARTY+' <br/>percentage : '+(parseFloat((d.votes/d.polled_votes))*100).toFixed(2)+'%  <br/>votes : '+addThousandsSeparator(d.votes)+'<br/>polled votes : '+addThousandsSeparator(d.polled_votes)+'' ;})
      .attr("sub_link",function(d) { return d.constituency+' '+d.PARTY+' '+d.NAME ;})
      .style("fill", function(d) { return color_map[d.PARTY];})
      .style("stroke", '#fff' )
      .style("stroke-width", 0.5);        

      $("rect").tooltip({container: '.tree_map', html: true, placement:'top'});
      
    var lastsearch = '';
    var $box = {};
    
    function add_search_tree(search, chart) {
      var $chart = $(chart);
      $(search).on('keypress, change, keyup', function() {
        var search = $(this).val();
        if (lastsearch != search) {
          lastsearch = search;
          var re = new RegExp( "^" + search, "i" );
          $('rect', $chart).each(function(){
 $(this).css('fill-opacity', re.test($(this).attr("sub_link")) ? '1.0': '0.1');
          });
        }
      });
    }

 add_search_tree('.search', '.tree_map');
 var Industry = constituency_list;
    
    $( ".search" ).autocomplete({
    source: function(req, responseFn) {
        var re = $.ui.autocomplete.escapeRegex(req.term);
        var matcher = new RegExp( "^" + re, "i" );
        var a = $.grep(Industry, function(item,index){
            return matcher.test(item);
        });
        responseFn( a );
    }
    
    });
    
    if (acct_no != undefined){
    
    if(extra_year_detail_sub != undefined){
        data_set = data_csv.filter(function(d){return (d.year==extra_year_detail)& (d.AC_NO==acct_no)& (d.rank<12) })
        }
    else {
        data_set = data_csv.filter(function(d){return (d.year==year_detail)& (d.AC_NO==acct_no)& (d.rank<12) })
        }
            
    deposit_data_set = data_set.filter(function(d){return (d.VOTES>=d.polled_votes/6) })
            
    var margin = {top: 10, right: 30, bottom: 15, left: 60},
   width = 960 - margin.left - margin.right,
   height = 320 - margin.top - margin.bottom;
    
    var horizontal_bar_svg = d3.select(".horizontal_bar").append("svg")
   .attr("width", "100%")
   .attr("data-height","0.54")
   .attr("viewBox","0 0 "+(width)+" "+(height))
   .attr("xmlns", 'http://www.w3.org/2000/svg')
   .attr("xlink", 'http://www.w3.org/1999/xlink')
   .attr("version", '1.1')
   .append("g")
   .attr("transform", "translate(" + margin.left + "," + margin.top/4 + ")");
    
    var constituency_name = '';
    
    data_set.forEach(function(o) {    
        constituency_name = o.AC_NAME;
      });
          
    var layers = d3.layout.stack()(['VOTES'].map(function(period) {
        return data_set.map(function(d) {
          return {x: d['rank']+': '+d.PARTY, y: parseFloat(d[period]), votes: parseFloat(d[period]), color : color_map[d.PARTY], party:d.PARTY,constituency:d.AC_NAME,name:d.NAME,polled_votes:d.polled_votes,rank:d.rank };
        });
    }));
   
   layers[0] = layers[0].sort(function(a, b){ return d3.ascending(a.rank, b.rank); })
   
   var yGroupMax = d3.max(layers, function(layer) { return d3.max(layer, function(d) { return d.y; });});

    var yScale = d3.scale.ordinal()
        .domain(layers[0].map(function(d) { return d.x; }))
        .rangeRoundBands([0, height- margin.top - margin.bottom], .2);

    var x = d3.scale.linear()
        .domain([0, yGroupMax])
        .range([0, width-(margin.left*5/2)]);
    
    var color = d3.scale.ordinal()
        .range(["#7aa1c2","#72d8f2","#f3daa4","#66ca9b","#f7f7f7","#f7f7f7"]);
    
    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom")        
        .tickPadding(12)
        .ticks(4);
        
    var yAxis = d3.svg.axis()
        .scale(yScale)
        .tickSize(0)
        .tickPadding(9)
        .orient("left");
    
    var layer = horizontal_bar_svg.selectAll(".layer")
        .data(layers)
        .enter().append("g")
        .attr("class", "layer");
        
        d3.selectAll(".tick >text")
            .style("font-size", "13px")    
  
    var rect = layer.selectAll("rect")
        .data(function(d) { return  d; })
        .enter().append("rect")
        .attr("y", function(d) { return yScale(d.x); })
        .attr("height", yScale.rangeBand())
        .attr("x", function(d) { return  x(d.y0); })
        .style("fill", function(d,i) { return d.color; })
        .style("stroke", function(d,i) { return d3.rgb(d.color).darker(); })
        .attr("data-title",function(d) { return 'Constituency : '+d.constituency+' <br/>Candidate : '+d.name+' <br/>party : '+d.party+' <br/>percentage : '+(parseFloat((d.votes/d.polled_votes))*100).toFixed(2)+'%  <br/>votes : '+addThousandsSeparator(d.votes)+'<br/>polled votes : '+addThousandsSeparator(d.polled_votes)+'' ;})
        .attr("width", function(d) { return x(d.y); });
        
    var rect = layer.selectAll("text")
        .data(function(d) { return  d; })
        .enter().append("text")
        .attr("y", function(d) { return yScale(d.x)+(yScale.rangeBand()*4/5); })
        .style("text-anchor", "start")
        .attr("fill", "#444")
        .style("font-size","13px")
        .text(function(d) { return addThousandsSeparator(d.votes)+' votes'; })
        .attr("x", function(d) { return  x(d.y)+3; });
        
        $(".constituency_tag").append("("+constituency_name+")");
    
    layer.append("g")
            .attr("class", "guide_deposit")
        .append("line")
            .attr('stroke-width',1)
            .style("stroke", "rgb(99, 99, 99)")
            .attr("x1", x(0))
            .attr("x2", x(yGroupMax))
            .attr("y1", yScale(layers[0][parseInt(deposit_data_set.length)]['x']) - yScale.rangeBand()*.1)
            .attr("y2", yScale(layers[0][parseInt(deposit_data_set.length)]['x']) - yScale.rangeBand()*.1);
            
    horizontal_bar_svg.append("text")
        .attr("x",width-margin.left-margin.left-margin.right)
        .attr("y", yScale(layers[0][parseInt(deposit_data_set.length)]['x']) +13)
        .style("fill", "rgb(99, 99, 99)")
        .style("font-size","13px")
        .style("text-anchor", "end")
        .attr("data-title","Guide line: 1/6 of polled votes<br/>(16.66 % approx)")
        .text("Deposit Threshold");
   
    horizontal_bar_svg.append("g")
        .attr("class", "x axis")
        .attr("transform", "translate(0," + (height -margin.bottom - margin.top) + ")")
        .call(xAxis)
        .selectAll("text").style("text-anchor", "middle")
            .attr("dx", "-.18em")
            .attr("dy", ".15em")
            .style("fill", "rgb(99, 99, 99)")
            .style("font-size","13px")

    horizontal_bar_svg.append("text")
        .attr("x", width-margin.left-margin.left-margin.right)
        .attr("y", height-(margin.top/2)-30)
        .style("fill", "rgb(99, 99, 99)")
        .style("font-size","13px")
        .style("text-anchor", "end")
        .text("Votes");
 
    horizontal_bar_svg.append("g")
        .attr("class", "y axis")
        .attr("transform", "translate(0,0)")
        .call(yAxis)
        .selectAll("text")
            .style("fill", "rgb(99, 99, 99)")
            .style("font-size","13px");
        
      $("text").tooltip({container: '.horizontal_bar', html: true, placement:'top'});
      $("rect").tooltip({container: '.horizontal_bar', html: true, placement:'top'});
    
        var twoPi = 2 * Math.PI;
        
        var sub_width = parseInt(d3.select('.progress_bar').style('width'), 10);
    
        var margin = {top: 20, right: 20, bottom: 20, left: 20},
   width = sub_width - margin.left - margin.right,
   height = 250 - margin.top - margin.bottom;
    
        var progress_bar_svg = d3.select(".progress_bar").append("svg")
   .attr("width", "100%")
   .attr("data-height","0.54")
   .attr("viewBox","0 0 "+(width)+" "+(height))
   .attr("xmlns", 'http://www.w3.org/2000/svg')
   .attr("xlink", 'http://www.w3.org/1999/xlink')
   .attr("version", '1.1')
   .append("g")
   .attr("transform", "translate(" + width/2 + "," + height*7/12+ ")");
    
        value_data = data_set.filter(function(d){return (d.rank==1) })
        
        value = value_data[0]['VOTES']/parseFloat(value_data[0]['polled_votes']);
        
        fontSize = 16;
        
        var arcs = d3.svg.arc()
       .innerRadius(d3.min([width,height])*.27)
       .outerRadius(d3.min([width,height])*.4)
       .startAngle(0);

        var background = progress_bar_svg
           .append("path")
           .datum({ endAngle : twoPi})
           .style("fill", "#ddd")
           .attr("d", arcs);

        var foreground = progress_bar_svg
  .append("path")
  .datum({ endAngle : 0})
  .style("fill", color_map[value_data[0]['PARTY']])
  .attr("class", "foreground")
  .attr("d", arcs);

            foreground
   .transition()
   .delay(1000)
   .duration(500)
   .ease("linear")
   .attrTween("d", function(d) {
   var interpolate = d3.interpolate(d.endAngle, twoPi * value)
   return function(t) {
   d.endAngle = interpolate(t);
   return arcs(d);
            }
            });

        var text = progress_bar_svg.append("text")
       .attr("text-anchor", "middle")
       .attr("dy", ".35em")
       .style("fill", "rgb(99, 99, 99)")
       .attr("font-size", fontSize)
       .text((value*100).toFixed(2) + "%");
       
        var text = progress_bar_svg.append("text")
       .attr("text-anchor", "middle")
       .attr("y", -100)
       .attr("dy", ".35em")
       .style("fill", "rgb(99, 99, 99)")
       .attr("font-size", fontSize)
       .text('Winning Party ('+value_data[0]['PARTY']+')');

        }
        if (cons_id != undefined){
        

            cons_set = data_csv.filter(function(d){ return (d.AC_NAME==cons_id) })
            
            year_list = [];
            cons_set.forEach(function (d) {
    
   year_list.push(parseInt(d['YEAR']))
   
            });
            
            year_list = _.uniq(year_list);
   
            var cons_layers =[]    
            year_list.forEach(function (period) {
   cons_layers.push(cons_set.filter(function(d){ return (parseInt(d.YEAR)==period) }))
            });
            
        var party_names = ['DMK','ADMK','INC','CPM','TMC','CPI','PMK','DMDK','NCO','JNP','MDMK','IND','BJP','Others'];
    
            year_stack=[];
            cons_layers.forEach(function (year) {    
   party_view = {'year': parseInt(year[0]['YEAR'])};            
   
   sub_party ={}
   ind_party = []
   year.forEach(function (d) {
       sub_party[d.PARTY] = parseInt(d.VOTES)
       if (d.PARTY=='IND'){
           ind_party.push(parseInt(d.VOTES)
           );
       }
       else{
           sub_party[d.PARTY] = parseInt(d.VOTES)
       }
   });
   
   if (ind_party.length>0){
       sub_party['IND'] = _.reduce(_.values(ind_party), function(a, b){ return a + b; }, 0)    
   }
   
   party_names.forEach(function (o) {
      if (sub_party[o]!=undefined){
           party_view[o] = sub_party[o];
           sub_party = _.omit(sub_party,o)
       }
      else{ party_view[o] = 0 }    
   });
   
   var other_party = _.reduce(_.values(sub_party), function(a, b){ return a + b; }, 0)
   party_view['Others'] = other_party   
   year_stack.push(party_view)
            });
            
            var cons_margin = {top: 20, right: 20, bottom: 35, left: 20},
   cons_width = 1200 - cons_margin.left - cons_margin.right,
   cons_height = 400 - cons_margin.top - cons_margin.bottom;

            var cons_x = d3.scale.ordinal()
   .rangeRoundBands([0, cons_width], .2);

            var cons_y = d3.scale.linear()
   .range([cons_height, 0]);

            var cons_xAxis = d3.svg.axis()
   .scale(cons_x)
   .orient("bottom");

            var cons_yAxis = d3.svg.axis()
   .scale(cons_y)
   .orient("left");

            var percent_svg = d3.select(".percent_stackedbar").append("svg")
           .style("width", "100%")
           .attr("data-height","0.54")
           .attr("viewBox","0 0 "+(cons_width + cons_margin.left + cons_margin.right)+" "+(cons_height + cons_margin.top + cons_margin.bottom))
           .append("g")
           .attr("transform", "translate(" + cons_margin.left + "," + cons_margin.top + ")");

            year_stack.forEach(function(d) {
       var y0 = 0;
       d.party = party_names.map(function(name) { return {name: name, y0: y0, y1: y0 += +d[name],value: +d[name],YEAR:d['year']}; });
       d.count_total = d.party[d.party.length - 1].y1;
       d.party.forEach(function(o) { o.y0 /= y0; o.y1 /= y0; o.y0= o.y0*100,o.y1=o.y1*100 });
       d.total = d.party[d.party.length - 1].y1;
 });
 
            year_stack.forEach(function(sub_stack) {
   sub_stack.party.forEach(function(l) {
           l.percent = parseFloat((l.value*100/sub_stack.count_total).toFixed(2));
           l.polled_votes = sub_stack.count_total;    
       });     
            });
   
 cons_x.domain([1967,1971,1977,1980,1984,1989,1991,1996,2001,2006,2011,2016]);
 cons_y.domain([0, d3.max(year_stack, function(d) { return d.total; })]);

 percent_svg.append("g")
       .attr("class", "x axis")
       .attr("transform", "translate(0," + cons_height + ")")
       .call(cons_xAxis);

 var percent_party = percent_svg.selectAll(".party")
     .data(year_stack)
     .enter().append("g")
     .attr("class", "party")
     .attr("transform", function(d) { return "translate(" + cons_x(d['year']) + ",0)"; });

 percent_party.selectAll("rect")
     .data(function(d) { return d.party; })
     .enter().append("rect")
     .attr('class',function (d) { return 'party_filters '+d.name+'s' })
     .attr("width", cons_x.rangeBand())
     .attr("y", function(d) { return cons_y(d.y1); })
     .attr("height", function(d) { return cons_y(d.y0) - cons_y(d.y1); })
     .style("fill", function(d) { return color_map[d.name] })
     .style("stroke", function(d) { return d3.rgb(color_map[d.name]).darker(); })
     .attr("data-title",function(d) { return 'Year : '+d.YEAR+'<br/>Constituency : '+cons_id+' <br/>party : '+d.name+' <br/>percentage : '+d.percent.toFixed(2)+'%  <br/>votes : '+addThousandsSeparator(d.value)+'<br/>polled votes : '+addThousandsSeparator(d.polled_votes)+'' ;})
     .on("mouseover", function() { d3.select(this).attr("stroke-width", 5);})
     .on("mouseout", function() { d3.select(this).attr("stroke-width", 1);});
     
 percent_party.selectAll(".value")
   .data(function(d) { return d.party; })
   .enter().append("text")
   .attr('class',function (d) { return 'value party_filters '+d.name+'s' })
   .attr("y", function(d) { return ((cons_y(d.y1)+cons_y(d.y0))/2)-1; })
   .attr("x", cons_x.rangeBand()/2)
   .attr("text-anchor", "middle")
   .style("font-size", "15px")
     .attr("data-title",function(d) { return 'Year : '+d.YEAR+'<br/>Constituency : '+cons_id+' <br/>party : '+d.name+' <br/>percentage : '+d.percent.toFixed(2)+'%  <br/>votes : '+addThousandsSeparator(d.value)+'<br/>polled votes : '+addThousandsSeparator(d.polled_votes)+'' ;})
   .style("fill", function(d) { return (parseInt(color_map[d.name].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
   .text(function(d) { return (cons_y(d.y0) - cons_y(d.y1))>29 ?d.percent.toFixed(0)+'%':' '; });

 percent_party.selectAll(".name")
   .data(function(d) { return d.party; })
   .enter().append("text")
   .attr('class',function (d) { return 'name party_filters '+d.name+'s' })
   .attr("y", function(d) { return ((cons_y(d.y1)+cons_y(d.y0))/2)+12; })
   .attr("x", cons_x.rangeBand()/2)
   .attr("text-anchor", "middle")
   .style("font-size", "12px")
     .attr("data-title",function(d) { return 'Year : '+d.YEAR+'<br/>Constituency : '+cons_id+' <br/>party : '+d.name+' <br/>percentage : '+d.percent.toFixed(2)+'%  <br/>votes : '+addThousandsSeparator(d.value)+'<br/>polled votes : '+addThousandsSeparator(d.polled_votes)+'' ;})
   .style("fill", function(d) { return (parseInt(color_map[d.name].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
   .text(function(d) { return (cons_y(d.y0) - cons_y(d.y1))>29 ?d.name:' '; });

            $("rect").tooltip({container: '.percent_stackedbar', html: true, placement:'top'});
            $("text").tooltip({container: '.percent_stackedbar', html: true, placement:'top'});
            
            $(".constituency_tag_percent").append("("+cons_id+")");
        
        }    
            
    var sub_width = parseInt(d3.select('.party_performance_trend_svg').style('width'), 10)
        
    var margin = {top: 20, right: 20, bottom: 20, left: 20},
        width = sub_width - margin.left - margin.right,
        height = 460 - margin.top - margin.bottom;
    
    var party_performance_trend_svg = d3.select(".party_performance_trend_svg").append("svg")
            .attr("width", "100%")
            .attr("data-height","0.54")
            .attr("viewBox","0 0 "+(width + margin.left + margin.right)+" "+(height + margin.top + margin.bottom))
            .attr("xmlns", 'http://www.w3.org/2000/svg')
            .attr("xlink", 'http://www.w3.org/1999/xlink')
            .attr("version", '1.1')
            .append("g")
            .attr("transform", "translate(" + (margin.left+(width/2))+ "," + (margin.top+(height/2)) + ")");
        
    contest_data_csv = data_csv.filter(function(d){return (d.year==year_detail)});
        
    var contest_data_count = d3.nest()
 .key(function(d) { return d.PARTY; })
 .rollup(function(v) { return v.length; })
 .entries(contest_data_csv);
 
    winning_data_csv = contest_data_csv.filter(function(d){return (d.rank==1)});
    
        var winning_data_count = d3.nest()
 .key(function(d) { return d.PARTY; })
 .rollup(function(v) { return v.length; })
 .entries(winning_data_csv);
         
        winning_data_count.forEach(function(o) {
            o.weight = o.values
            o.width  = +o.weight;
            contest_data_count.forEach(function(d) {
   if(d.key==o.key){
       o.contest = d.values
   } 

            });
            o.score  = (o.values*100/o.contest).toFixed(2);            
        });
        
        radius = Math.min(width, height) / 2,
        innerRadius = 0.3 * radius;

    var pie = d3.layout.pie()
        .sort(null)
        .value(function(d) { return d.width; });

        var arc = d3.svg.arc()
          .innerRadius(innerRadius)
          .outerRadius(function (d) { 
            return (radius - innerRadius) * (d.data.score / 100.0) + innerRadius; 
          });

        var outlineArc = d3.svg.arc()
   .innerRadius(innerRadius)
   .outerRadius(radius);


  var path = party_performance_trend_svg.selectAll(".solidArc")
      .data(pie(winning_data_count))
    .enter().append("path")
      .attr("fill", function(d) { return color_map[d.data.key]!=undefined? color_map[d.data.key] : '#363636'; })
      .attr("class", "solidArc")
      .attr("stroke", function(d) { return color_map[d.data.key]!=undefined? d3.rgb(color_map[d.data.key]).darker() : d3.rgb('#363636').darker() })
      .attr("d", arc)
      .attr('class',function (d) { return 'party_filters '+d.data.key+'s' })
      .attr("data-title",function(d) { return  'party : '+d.data.key+' <br/>contested seats : '+d.data.contest+' <br/>seats won : '+d.data.values+' <br/>convertion percentage : '+d.data.score ;});

  var outerPath = party_performance_trend_svg.selectAll(".outlineArc")
      .data(pie(winning_data_count))
    .enter().append("path")
      .attr("fill", "none")
      .attr("stroke", "gray")
      .attr("class", "outlineArc")
      .attr("d", outlineArc);  
    
  var max_value = d3.max(winning_data_count, function(d) { return d.values; });
  winning_party = winning_data_count.filter(function(d){return (d.values==max_value)});
  
  party_performance_trend_svg.append("text")
    .attr("class", "aster-score")
    .attr("dy", ".35em")
    .attr("text-anchor", "middle")
    .style("fill", "rgb(99, 99, 99)")
    .attr("font-size", 22)    // text-align: right
    .text(winning_party[0]['key']);
    
    $("path").tooltip({container: '.party_performance_trend_svg', html: true, placement:'top'});

    function map_filter(year_2011,year_2016){

    data_csv = data_csv.filter(function(d){return ((d.YEAR==2011) |(d.YEAR==2016)) & (d.rank==1) })

    sub_click = _.pluck(party_2011.filter(function(d) { return d[2011]!='' }),2011)

     data_csv.forEach(function(o) {
           if (o.YEAR==2011){
           o.PARTY = sub_click.indexOf(o.PARTY) >-1? o.PARTY:'Others'            
           }
      });

    var data_csv_2011 = []
       _.each(data_csv, function(d) { if(_.contains(year_2011, d.PARTY)) { data_csv_2011.push(d);}});

    data_csv_2011 = data_csv_2011.filter(function(d){return (d.YEAR==2011) & (d.rank==1) })

   
    var data_csv_2016 = []
       _.each(data_csv, function(d) { if(_.contains(year_2016, d.PARTY)) { data_csv_2016.push(d);}});

    data_csv_2016 = data_csv_2016.filter(function(d){return (d.YEAR==2016) & (d.rank==1) })

    
    cons_2011 = _.pluck(_.uniq(data_csv_2011, function(item, key, a) { return item['AC_NAME']; }), 'AC_NAME');
    cons_2016 = _.pluck(_.uniq(data_csv_2016, function(item, key, a) { return item['AC_NAME']; }), 'AC_NAME');
  
  Array.prototype.extend = function (other_array) {
      /* you should include a test to check whether other_array really is an array */
      other_array.forEach(function(v) {this.push(v)}, this);    

   }

    data_set = data_csv.filter(function(d){return (d.YEAR==extra_year_detail) & (d.rank==1) })
    var data_set_sub = []
       _.each(data_set, function(d) { if(_.contains(cons_2011, d.AC_NAME)) { data_set_sub.push(d);}});
    var data_set = []
       _.each(data_set_sub, function(d) { if(_.contains(cons_2016, d.AC_NAME)) { data_set.push(d);}});

    constituency_color = {}
    Candidate = {}
    PARTY ={}
    percent_votes = {}
    votes = {}
    polled_votes = {}
    constituency_list =[]
     data_set.forEach(function(o) {
      o.rank = parseInt(o.rank);
      o.year = parseInt(o.YEAR);
      o.votes = parseInt(o.VOTES);
      o.polled_votes = parseInt(o.polled_votes);
      constituency_list.push(o.AC_NAME)
      votes[o.AC_NAME] = o.VOTES;
      polled_votes[o.AC_NAME]  = o.polled_votes;
      constituency_color[o.AC_NAME] = color_map[o.PARTY]
      Candidate[o.AC_NAME] = o.NAME
      PARTY[o.AC_NAME] = o.PARTY
      percent_votes[o.AC_NAME] = (parseFloat((o.votes/o.polled_votes))*100).toFixed(2)
          
      });
    
    d3.selectAll("a").each( function(d, i){
        if (d3.select(this).attr("acct_no")!=undefined)
        {    
            d3.select(this).attr("xlink:href",'?extra_year='+extra_year_detail+'&acct_no='+d3.select(this).attr("acct_no")+'#perConstituency')
        }
     });
 
    d3.selectAll("polygon").each( function(d, i){
    
    
    if (PARTY[d3.select(this).attr("id")] !=undefined)
    {    
    d3.select(this).attr("data-title",'Constituency : '+d3.select(this).attr("id")+' <br/>Candidate : '+Candidate[d3.select(this).attr("id")]+' <br/>party : '+PARTY[d3.select(this).attr("id")]+' <br/>percentage : '+percent_votes[d3.select(this).attr("id")]+'%  <br/>votes : '+addThousandsSeparator(votes[d3.select(this).attr("id")])+'<br/>polled votes : '+addThousandsSeparator(polled_votes[d3.select(this).attr("id")]))
    d3.select(this).attr("sub_link",function(d) { return d3.select(this).attr("id")+' '+PARTY[d3.select(this).attr("id")]+' '+Candidate[d3.select(this).attr("id")] ;})
    d3.select(this).style("fill", constituency_color[d3.select(this).attr("id")] )
    d3.select(this).style("stroke","#ddd")
    d3.select(this).style("stroke-width", 2)
    d3.select(this).attr("class", PARTY[d3.select(this).attr("id")])
    
    }
    else{
    d3.select(this).style("fill", '#fff' )
    d3.select(this).style("stroke","#ddd")
    d3.select(this).style("stroke-width", 2)
    d3.select(this).attr("data-title",'Constituency : '+d3.select(this).attr("id")+'<br/>Election Canceled ')
    }
    });
    
    var lastsearch = '';
    var $box = {};
    
    function add_search(search, chart) {
      var $chart = $(chart);
      $(search).on('keypress, change, keyup', function() {
        var search = $(this).val();
        if (lastsearch != search) {
          lastsearch = search;
          var re = new RegExp( "^" + search, "i" );
          $('polygon', $chart).each(function(){
 $(this).css('fill-opacity', re.test($(this).attr("sub_link")) ? '1.0': '0.1');
          });
        }
      });
    }

   //add_search('.geo_search', '.geo_map');

   var Industry = constituency_list;
    
    $( ".geo_search" ).autocomplete({
    source: function(req, responseFn) {
        var re = $.ui.autocomplete.escapeRegex(req.term);
        var matcher = new RegExp( "^" + re, "i" );
        var a = $.grep( Industry, function(item,index){
            return matcher.test(item);
        });
        responseFn( a );
    }
    });
    
/*    $(".party-legend").mouseover(function(){
    
        d3.selectAll('.party_filters').style("opacity",'0.1');
        d3.selectAll('polygon').style("fill-opacity",'0.1');
        d3.selectAll('.'+$(this).attr("data-party")).style("fill-opacity",'1');
        d3.selectAll('.'+$(this).attr("data-party")+'s').style("opacity",'1');
    })

    $(".party-legend").mouseout(function(){
    
        d3.selectAll('.party_filters').style("opacity",'1');
        d3.selectAll('polygon').style("fill-opacity",'1');
    })*/
        
    $("polygon").tooltip({container: 'body', html: true, placement:'top'});
      
  }

$('.party_filter').click( function(n) {

 var year_2016 = [];
      $('#year_2016 :selected').each(function(i, selected){
          year_2016[i] = $(selected).val();
      });

 var year_2011 = [];
        $('#year_2011 :selected').each(function(i, selected){
            year_2011[i] = $(selected).val();
        });

  map_filter(year_2011,year_2016);

});

 var year_2016 = [];
      $('#year_2016 :selected').each(function(i, selected){
          year_2016[i] = $(selected).val();
      });

 var year_2011 = [];
        $('#year_2011 :selected').each(function(i, selected){
            year_2011[i] = $(selected).val();
        });
  map_filter(year_2011,year_2016);
  
  });

var margin = {top: 50, right: 20, bottom: 20, left: 20},
    width = 1200 - margin.left - margin.right,
    height = 600 - margin.top - margin.bottom;

var formatNumber = d3.format(",.0f"), 
    format = function(d) { return formatNumber(d); },
    color = d3.scale.category20b();
    
// append the svg canvas to the page
var svg = d3.select(".sankey_chart").append("svg")
    .attr("width", '100%')
    .attr("data-height", '0.5678')
    .attr("viewBox",'0 0 1200 600')
  .append("g")
    .attr("transform", 
          "translate(" + margin.left + "," + margin.top + ")");

// Set the sankey diagram properties
var sankey = d3.sankey()
    .nodeWidth(100)
    .nodePadding(3)
    .size([width, height]);

var path = sankey.link();

// load the data (using the timelyportfolio csv method)
d3.csv("{{asset('public/graph/tn_data.csv')}}", function(error, data) {

  party_2011 = _.uniq(data, function(item, key, a) {  return item[2011]; });
  party_2016 = _.uniq(data, function(item, key, a) {  return item[2016]; });

 var select_box = d3.select('#year_2011')     
   .selectAll("option")
       .data(party_2011.filter(function(d) { return d[2011]!='' })) 
       .enter().append("option")
       .attr("value", function (d) { return d[2011]; })
       .attr("class","name")
       .attr("selected","")
       .text(function (d) { return d[2011]; });

 var select_box = d3.select('#year_2016')     
   .selectAll("option")
       .data(party_2016.filter(function(d) { return d[2016]!='' }))
       .enter().append("option")
       .attr("value", function (d) { return d[2016]; })
       .attr("class","name")
       .attr("selected","")
       .text(function (d) { return d[2016]; });

$(".select_year").multipleSelect({ placeholder: "Here is the placeholder" });

data.forEach(function (d) {
        d.source_year =d[flowyear_detail.substring(0, 4)]
        d.target_year =d[flowyear_detail.substring(5, 9)] 
        d.combined_year =d[flowyear_detail.substring(0, 4)]+'_'+d[flowyear_detail.substring(5, 9)] 
        });

        data = data.filter(function(d){return (d.source_year!='') & (d.target_year!='') })
        
        var data_Count = d3.nest()
 .key(function(d) { return d.combined_year; })
 .rollup(function(v) { return v.length; })
 .entries(data);
        
  graph = {"nodes" : [], "links" : []};
    
    name_list = []
    data_Count.forEach(function (d) {

      graph.nodes.push({ "name": d.key.split("_")[0], "color": color_map[d.key.split("_")[0]] });
      graph.nodes.push({ "name": '_'+d.key.split("_")[1], "color": color_map[d.key.split("_")[1]] });

      graph.links.push({ "source": d.key.split("_")[0],
            "target": '_'+d.key.split("_")[1],
            "source_color": color_map[d.key.split("_")[0]],
            "target_color": color_map[d.key.split("_")[1]],
            "value": d.values });
     });
     
     // return only the distinct / unique nodes
     graph.nodes = d3.keys(d3.nest()
       .key(function (d) { return d.name; })
       .map(graph.nodes));
     
     // loop through each link replacing the text with its index from node
     graph.links.forEach(function (d, i) {
       graph.links[i].source = graph.nodes.indexOf(graph.links[i].source);
       graph.links[i].target = graph.nodes.indexOf(graph.links[i].target);
     });

     //now loop through each nodes to make nodes an array of objects
     // rather than an array of strings
     graph.nodes.forEach(function (d, i) {       
       graph.nodes[i] = { "name": d };
     });

  sankey
    .nodes(graph.nodes)
    .links(graph.links)
    .layout(32);

 svg.selectAll(".head")
      .data([flowyear_detail.substring(0, 4),flowyear_detail.substring(5, 9)])
    .enter().append("text")
      .attr("y", -4)
      .attr("font-size",21)
      .attr("x", function(d,p) { return p < 1 ?  50 : 1110 ; })
      .attr("fill", function(d,p) { return p >0 ? "rgb(99, 99, 99)" : "rgb(99, 99, 99)"; })
      .attr("text-anchor", function(d,p) { return p <  1 ? 'middle' : 'middle'; })
      .text(function(d) { return 'year('+d+')'; });

      
// add in the links
  var link = svg.append("g").selectAll(".link")
      .data(graph.links)
    .enter().append("path")
      .attr("class", "link")
      .attr("d", path)
      .style("stroke-width", function(d) { return Math.max(1, d.dy); })
      .style("fill", function(d) { return d.target_color; })
      .style("stroke", function(d) { return d.target_color; })
      .sort(function(a, b) { return b.dy - a.dy; })
      .attr("data-title",function(d) { return d.source.name == d.target.name.replace('_','') ?  d.source.name+' has retained '+format(d.value)+' seats'  : d.target.name.replace('_','') + " has got "+ format(d.value)+" seats from "+ d.source.name; });

// add in the nodes
  var node = svg.append("g").selectAll(".node")
      .data(graph.nodes)
    .enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { 
          return "translate(" + d.x + "," + d.y + ")"; })
    .call(d3.behavior.drag()
      .origin(function(d) { return d; })
      .on("dragstart", function() { 
          this.parentNode.appendChild(this); })
      .on("drag", dragmove));
      
// add the rectangles for the nodes
  node.append("rect")
      .attr("height", function(d) { return d.dy; })
      .attr("width", sankey.nodeWidth())
     .style("fill", function(d) { return color_map[d.name.replace('_','')]; })
      .style("stroke", function(d) { return d3.rgb(color_map[d.name.replace('_','')]).darker(2); })
       .attr('data-title',function(d) { return d.name.replace('_','') + "\n" + format(d.value)+' Seats'; });
    
  node
    .append("text")
    .attr("y", function(d) { return (d.dy/2)-1; })
    .attr("x", sankey.nodeWidth()/2)
    .attr("text-anchor", "middle")
    .style("font-size", "15px")
    .attr("data-title", function(d) { return d.name.replace('_','')+' : '+format(d.value)+' seats'; })
    .style("fill", function(d) { return (parseInt(color_map[d.name.replace('_','')].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
    .text(function(d) { return d.dy>29 ?d.value:' '; });

  node
    .append("text")
    .attr("y", function(d) { return (d.dy/2)+12; })
    .attr("x", sankey.nodeWidth()/2)
    .attr("text-anchor", "middle")
    .style("font-size", "12px")
    .attr("data-title", function(d) { return d.name.replace('_','')+' : '+format(d.value)+' seats'; })
    .style("fill", function(d) { return (parseInt(color_map[d.name.replace('_','')].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff';})
    .text(function(d) { return d.dy>29 ?d.name.replace('_',''):' '; });

  $("text").tooltip({container: '.sankey_chart', html: true, placement:'top'});
  $("rect").tooltip({container: '.sankey_chart', html: true, placement:'top'});
  $("path").tooltip({container: '.sankey_chart', html: true, placement:'top'});

// add in the title for the nodes
  node.append("text")
      .attr("x", -6)
      .attr("y", function(d) { return d.dy / 2; })
      .attr("dy", ".35em")
      .attr("text-anchor", "end")
      .attr("transform", null)
      .text(function(d) { return d.name.replace('_',''); })
    .filter(function(d) { return d.x < width / 2; })
      .attr("x", 6 + sankey.nodeWidth())
      .attr("text-anchor", "start");

// the function for moving the nodes
  function dragmove(d) {
    d3.select(this).attr("transform", 
        "translate(" + d.x + "," + (
   d.y = Math.max(0, Math.min(height - d.dy, d3.event.y))
            ) + ")");
    sankey.relayout();
    link.attr("d", path);
  }
  
});
 
// load the data (using the timelyportfolio csv method)
d3.text("{{asset('public/graph/tn_data.csv')}}", function(error, data) {

   var parsedCSV = d3.csv.parseRows(data); 
   var container = d3.select(".party_trend")
         .append("table")
          .attr("id","myTable")
          .attr("class","table table-bordered");
          
            container.selectAll("thead")
   .data([parsedCSV[0]]).enter()
   .append("thead")
   .attr("class","data_head")
   .append("tr")
            .selectAll("th")
   .data(function(d) { return d; }).enter()
   .append("th")
    .attr("class","dynatable-head")
    .append("font")
       .attr("color","#636363")
   .text(function(d) { return d; })

            if (0 >-1) { parsedCSV.splice(0, 1);}
       
   container
       .append("tbody")
        .selectAll("tr")
           .data(parsedCSV).enter()
           .append("tr")
       .selectAll("td")
           .data(function(d) { return d; }).enter()
           .append("td")
           .attr("bgcolor",function(d) { return color_map[d] })
           .append("font")
           .append('a')
           .style("color",function(d) { return color_map[d] == undefined ? "#636363" : ((parseInt(color_map[d].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff') })
           .attr("href",function(d,i) { return  i==0? '?cons_id='+d+'#detailConstituency' : '#Constituency_partyTrend' })
           .attr("color",function(d) { return color_map[d] == undefined ? "#636363" : ((parseInt(color_map[d].replace('#', ''), 16) >0xffffff / 2) ? '#000' : '#fff') })
           .text(function(d) { return d; });

    $('#myTable').DataTable({ "sScrollX": "100%", "sScrollXInner": "150%" });
   
});
        
</script>

</div>
</body>

	</body>

</html>
