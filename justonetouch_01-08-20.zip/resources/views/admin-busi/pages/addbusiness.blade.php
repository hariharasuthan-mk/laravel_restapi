<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
  <link rel="stylesheet" type="text/css" href="{{asset('public/css/jquery.timepicker.css')}}" />
  <script src="{{asset('public/js/jquery.timepicker.js')}}"></script>
<script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
	
</head>

<body>

<div class="text-center">
  <h3>Add Business</h3>
</div>

<div class="container">
  <div class="row">
    {!! Form::open(['url' => url('admin/postbusiness'), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'businessform']) !!}
      <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail">Category</label>
            <select name="parent_id" id="parent_id" class="form-control">
				<option value="0">Select Category</option>
				@if($getall)
					@foreach($getall as $val)
					<option value="{{ $val->id}}">{{ $val->category_name }}</option>
					@endforeach
				@endif
			</select>
          </div>
          <div class="form-group" id="subcatdiv" style="display:none">
            <label for="exampleInputPassword">Sub Category</label>
            <select name="subcat_id" id="subcat_id" class="form-control">
															
			</select>
          </div>
		  <div class="form-group" id="subsubcatdiv" style="display:none">
            <label for="exampleInputPassword">Sub Category</label>
            <select name="subsubcat_id" id="subsubcat_id" class="form-control">
															
			</select>
          </div>
		  <div class="form-group">
            <label for="exampleInputDesc">First Name</label>
            {!! Form::text('business_firstname','',array('class'=>'form-control','placeholder'=>'Enter Your First Name')) !!}
          </div>
          <div class="form-group">
            <label for="exampleInputDesc">Last Name</label>
            {!! Form::text('business_lastname','',array('class'=>'form-control','placeholder'=>'Enter Your Last Name')) !!}
          </div>
          
          <div class="form-group">
            <label for="exampleInputDesc">Business Title</label>
            {!! Form::text('business_title','',array('class'=>'form-control','placeholder'=>'Enter Your Business Title')) !!}
          </div>
          
          <div class="form-group">
            <label for="exampleInputDesc">Business Email</label>
            {!! Form::text('business_email','',array('class'=>'form-control','placeholder'=>'Enter Your Business Email')) !!}
          </div>
          
          <div class="form-group">
            <label for="exampleInputDesc">Business Contact No</label>
            {!! Form::text('business_contactno','',array('class'=>'form-control','placeholder'=>'Enter Your Contact No')) !!}
          </div>
          
          <div class="form-group">
            <label for="exampleInputDesc">Business Website</label>
            {!! Form::text('business_website','',array('class'=>'form-control','placeholder'=>'Enter Your Business Website')) !!}
          </div>
          
          <div class="form-group">
            <label for="exampleInputFile">Business Logo</label>
            <input type="file" id="exampleInputFile" name="business_image" class="form-control">
            <p class="help-block">Example block-level help text here.</p>
          </div>
		   <div class="form-group">
            <label for="exampleInputFile">Business Banner</label>
            <input type="file" id="exampleInputFile" name="business_banner" class="form-control">
            <p class="help-block">Example block-level help text here.</p>
          </div>
		  <div class="form-group">
		      
		      <div class="table-responsive">          
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Day</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $i = 0;
                            for($i=0;$i<7;$i++){
                        ?>
                      <tr>
                        <td>
                            <select name="week_days[]" class="form-control">
                				<option value="0">Select Days</option>
                				<option value="Monday">Monday</option>
                				<option value="Tuesday">Tuesday</option>
                				<option value="Wednesday">Wednesday</option>
                				<option value="Thursday">Thursday</option>
                				<option value="Friday">Friday</option>
                				<option value="Saturday">Saturday</option>
                				<option value="Sunday">Sunday</option>
                			</select>
                        </td>
                        <td>
                            {!! Form::text('starttime[]','',array('class'=>'form-control starttime','id'=>'starttime','placeholder'=>'Start Time')) !!}
                        </td>
                        <td>
                            {!! Form::text('endtime[]','',array('class'=>'form-control endtime','id'=>'endtime','placeholder'=>'End Time')) !!}
                        </td>
                      </tr>
                      <?php 
                        }
                    ?>
                    </tbody>
                  </table>
            </div>
		      
		  
		  </div>
		
      </div>
      <div class="col-md-6">
         <div class="form-group">
            <label for="exampleInputDesc">Business Description</label>
            <textarea name="business_desc" placeholder="Enter Your Business Desc"></textarea>
                <script>
                    CKEDITOR.replace( 'business_desc' );
                </script>
                                
          </div>
          <div class="form-group">
            <label for="exampleInputDesc">Business Address</label>
            <textarea name="business_address" class="form-control" rows="6" placeholder="Enter Your Business Address"></textarea>
                
                
          </div>
          <div class="form-group">
            <label for="exampleInputFile">City</label>
            <select name="city_id" class="form-control">
				<option value="0">Select City</option>
				@if($getallcity)
				@foreach($getallcity as $valcity)
				<option value="{{ $valcity->id }}">{{ $valcity->city }}</option>
				@endforeach
				@endif
			</select>
            <p class="help-block">Example block-level help text here.</p>
          </div>
          <div class="form-group">
            <label for="exampleInputFile">Pincode</label>
            {!! Form::text('pincode','',array('class'=>'form-control pincode','id'=>'pincode','placeholder'=>'Enter your pincode')) !!}
            <p class="help-block">Example block-level help text here.</p>
          </div>
          <div class="form-group">
            <label for="exampleInputDesc">Business Tags</label>
            {!! Form::textarea('business_tags','',array('class'=>'form-control','rows' => 6,'placeholder'=>'Enter Your Category Desc')) !!}
          </div>
          <div class="form-group">
              <label for="exampleInputDesc">Gallery</label>
                <div class="input-group control-group increment" >
                  <input type="file" name="filename[]" class="form-control">
                  <div class="input-group-btn"> 
                    <button class="btn btn-success addnew" type="button"><i class="glyphicon glyphicon-plus"></i>Add</button>
                  </div>
                </div>  
            </div>
            <div class="clone" style="display:none">
              <div class="control-group input-group" style="margin-top:10px">
                <input type="file" name="filename[]" class="form-control">
                <div class="input-group-btn"> 
                  <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                </div>
              </div>
            </div>
                            
           <div class="form-group">
			<select name="business_status" class="form-control">
				<option value="0">Select Status</option>
				<option value="1">Active</option>
				<option value="2">Non-Active</option>
			</select>
		  </div>
      </div>
      
    <button type="submit" class="btn btn-primary">Submit</button>  
    {!! Form::close() !!}
  </div>
  
  
</div>


	<!--SCRIPT FILES-->
	
	
	<script>
	$('#parent_id').change(function(){
		$("#subcatdiv").show();
        var cid = $(this).val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
		}			
		var url="{{ url('/admin/getSubcategory')}}/"+cid;
        if(cid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                console.log(res);
				if(res)
                {
                    $("#subcat_id").empty();
                    //$("#city").empty();
                    $("#subcat_id").append('<option value="0">Select Sub Category</option>');
                    $.each(res,function(key,value){
                        $("#subcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                }
           }

        });
        }
    });
	/*$('#subcat_id').change(function(){
		$("#subsubcatdiv").show();
        var sid = $(this).val();
		var cid = $('#parent_id').val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
			$("#subsubcat_id").val("");
			$("#subsubcatdiv").hide();
		}	
		if(sid==0)
		{
			$("#subsubcat_id").val("");
			$("#subsubcatdiv").hide();
		}	
		var url="{{ url('/admin/getSubcategory')}}/"+sid;
        if(sid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                if(res)
                {
                    $("#subsubcat_id").empty();
                    $("#subsubcat_id").append('<option>Select Sub Category </option>');
                    $.each(res,function(key,value){
                        $("#subsubcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                }
           }

        });
        }
    }); */
    
	</script>
	<script>
			$(function() {
				$('.starttime').timepicker();
			});
			$(function() {
				$('.endtime').timepicker();
			});
			
			</script>
			 <script type="text/javascript">

    $(document).ready(function() {

      $(".addnew").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });
    </script>
</body>
</html>
