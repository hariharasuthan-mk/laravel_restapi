<!DOCTYPE html>
<html lang="en">
<head>
	<title>One Touch</title>
	<!-- META TAGS -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	
	
</head>

<body>

<div class="text-center">
  <h3>Add Category</h3>
</div>

<div class="container">
  <div class="row">
    {!! Form::open(['url' => url('admin/postcategory'), 'method' => 'POST' ,'enctype'=> 'multipart/form-data', 'class'=> '','id'=>'categoryform']) !!}
      <div class="col-md-6">
          <div class="form-group">
            <label for="exampleInputEmail">Category</label>
            <select name="parent_id" id="parent_id" class="form-control">
				<option value="0">Select Category</option>
				@if($getall)
					@foreach($getall as $val)
					<option value="{{ $val->id}}">{{ $val->category_name }}</option>
					@endforeach
				@endif
			</select>
          </div>
          <div class="form-group" id="subcatdiv" style="display:none">
            <label for="exampleInputPassword">Sub Category</label>
            <select name="subcat_id" id="subcat_id" class="form-control">
															
			</select>
          </div>
		  <div class="form-group" id="subsubcatdiv" style="display:none">
            <label for="exampleInputPassword">Sub Category</label>
            <select name="subsubcat_id" id="subsubcat_id" class="form-control">
															
			</select>
          </div>
		  <div class="form-group">
            <label for="exampleInputDesc">Category Name</label>
            {!! Form::text('cat_name','',array('class'=>'form-control','placeholder'=>'Enter Your Category')) !!}
          </div>
		   <div class="form-group">
            <label for="exampleInputDesc">Description</label>
            {!! Form::textarea('cat_desc','',array('class'=>'form-control','placeholder'=>'Enter Your Category Desc')) !!}
          </div>
          <div class="form-group">
            <label for="exampleInputFile">File input</label>
            <input type="file" id="exampleInputFile" name="image" class="form-control">
            <p class="help-block">Example block-level help text here.</p>
          </div>
		  
		 
          <div class="form-group">
			<select name="status" class="form-control">
				<option value="0">Select Status</option>
				<option value="1">Active</option>
				<option value="2">Non-Active</option>
			</select>
		  </div>
		  
          <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      <div class="col-md-6">
        
      </div>
    {!! Form::close() !!}
  </div>
  
  
</div>


	<!--SCRIPT FILES-->
	
	
	<script>
	$('#parent_id').change(function(){
		$("#subcatdiv").show();
        var cid = $(this).val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
		}			
		var url="{{ url('/admin/getSubcategory')}}/"+cid;
        if(cid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                console.log(res);
				if(res)
                {
                    $("#subcat_id").empty();
                    //$("#city").empty();
                    $("#subcat_id").append('<option value="0">Select Sub Category</option>');
                    $.each(res,function(key,value){
                        $("#subcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                }
           }

        });
        }
    });
	/*$('#subcat_id').change(function(){
		$("#subsubcatdiv").show();
        var sid = $(this).val();
		var cid = $('#parent_id').val();
		if(cid==0)
		{
			$("#subcat_id").val("");
			$("#subcatdiv").hide();
			$("#subsubcat_id").val("");
			$("#subsubcatdiv").hide();
		}	
		if(sid==0)
		{
			$("#subsubcat_id").val("");
			$("#subsubcatdiv").hide();
		}	
		var url="{{ url('/admin/getSubcategory')}}/"+sid;
        if(sid){
        $.ajax({
           type:"get",
           url:url,
           success:function(res)
           {       
                if(res)
                {
                    $("#subsubcat_id").empty();
                    $("#subsubcat_id").append('<option>Select Sub Category </option>');
                    $.each(res,function(key,value){
                        $("#subsubcat_id").append('<option value="'+key+'">'+value+'</option>');
                    });
                }
           }

        });
        }
    }); */
	</script>
</body>
</html>
