var routefirst = "{{ url('cityautocomplete') }}";
    $('#top-select-city').typeahead({
        source:  function (term, process) {
        return $.get(routefirst, { term: term }, function (data) {
                return process(data);
            });
        }
    });

    var routesec = "{{ url('businessautocomplete') }}";
    $('#top-select-search').typeahead({
        source:  function (term, process) {
        return $.get(routesec, { term: term }, function (data) {
                return process(data);
            });
        }
    });

/*$("input#select-search").keypress(function (event) {
        if (event.which == 13) {
            $("#search-form").submit();
        }
});*/

$('.typeahead').on('keydown', function(e) {
  if (e.keyCode == 13) {
    var ta = $(this).data('typeahead');
    var val = ta.$menu.find('.active').data('value');
    if (!val)
      $('#search-form').submit();
  }
});